#ifndef INC_AnisoGAJointConfLexer_hpp_
#define INC_AnisoGAJointConfLexer_hpp_

#include <antlr/config.hpp>
/* $ANTLR 2.7.7 (20100319): "AnisoGAJointConf.g" -> "AnisoGAJointConfLexer.hpp"$ */
#include <antlr/CommonToken.hpp>
#include <antlr/InputBuffer.hpp>
#include <antlr/BitSet.hpp>
#include "AnisoGAJointConfParserTokenTypes.hpp"
#include <antlr/CharScanner.hpp>
#line 1 "AnisoGAJointConf.g"

	#include <string>
	#include <vector>
	#include <iostream>
	#include <cstdlib>

#line 19 "AnisoGAJointConfLexer.hpp"
class CUSTOM_API AnisoGAJointConfLexer : public antlr::CharScanner, public AnisoGAJointConfParserTokenTypes
{
#line 1 "AnisoGAJointConf.g"
#line 23 "AnisoGAJointConfLexer.hpp"
private:
	void initLiterals();
public:
	bool getCaseSensitiveLiterals() const
	{
		return true;
	}
public:
	AnisoGAJointConfLexer(std::istream& in);
	AnisoGAJointConfLexer(antlr::InputBuffer& ib);
	AnisoGAJointConfLexer(const antlr::LexerSharedInputState& state);
	antlr::RefToken nextToken();
	public: void mEQUAL(bool _createToken);
	public: void mTRUE(bool _createToken);
	public: void mFALSE(bool _createToken);
	public: void mWS(bool _createToken);
	protected: void mNEWLINE(bool _createToken);
	public: void mSTRING(bool _createToken);
	protected: void mCHAR(bool _createToken);
	protected: void mDIGIT(bool _createToken);
	protected: void mOTHER(bool _createToken);
	public: void mNUMBER(bool _createToken);
	protected: void mREAL(bool _createToken);
	protected: void mINT(bool _createToken);
	public: void mCOMMENT(bool _createToken);
	public: void mVERBOSET(bool _createToken);
	public: void mMTFITEXPONENTT(bool _createToken);
	public: void mPOPSIZET(bool _createToken);
	public: void mINITTEMPT(bool _createToken);
	public: void mCOOLINGRATIOT(bool _createToken);
	public: void mGENERATIONST(bool _createToken);
	public: void mMUTATIONPROBT(bool _createToken);
	public: void mCROSSOVERPROBT(bool _createToken);
	public: void mTHREADST(bool _createToken);
	public: void mSTARTTIMET(bool _createToken);
	public: void mENDTIMET(bool _createToken);
	public: void mTENSORERRORT(bool _createToken);
	public: void mRESERRORT(bool _createToken);
	public: void mPHASEERRORT(bool _createToken);
	public: void mGATYPET(bool _createToken);
	public: void mOUTPUTBASET(bool _createToken);
	public: void mMODET(bool _createToken);
	public: void mMTFITT(bool _createToken);
	public: void mMTINPUTDATAT(bool _createToken);
	public: void mPTENSORDATAT(bool _createToken);
	public: void mANNEALINGGENERATIONT(bool _createToken);
	public: void mELITISTT(bool _createToken);
	public: void mTHICKBASET(bool _createToken);
	public: void mTHICKSTEPT(bool _createToken);
	public: void mTHICKSIZEST(bool _createToken);
	public: void mRESBASET(bool _createToken);
	public: void mRESSTEPT(bool _createToken);
	public: void mRESSIZEST(bool _createToken);
	public: void mVELBASET(bool _createToken);
	public: void mVELSTEPT(bool _createToken);
	public: void mVELSIZEST(bool _createToken);
	public: void mARESBASET(bool _createToken);
	public: void mARESSTEPT(bool _createToken);
	public: void mARESSIZEST(bool _createToken);
	public: void mAVELBASET(bool _createToken);
	public: void mAVELSTEPT(bool _createToken);
	public: void mAVELSIZEST(bool _createToken);
	public: void mSTRIKEBASET(bool _createToken);
	public: void mSTRIKESTEPT(bool _createToken);
	public: void mSTRIKESIZEST(bool _createToken);
	public: void mDSTRIKEBASET(bool _createToken);
	public: void mDSTRIKESTEPT(bool _createToken);
	public: void mDSTRIKESIZEST(bool _createToken);
	public: void mWEIGHTST(bool _createToken);
	public: void mCONDDIFFWEIGHTT(bool _createToken);
	public: void mANISOTROPYWEIGHTT(bool _createToken);
	public: void mSTRIKEDIFFWEIGHTT(bool _createToken);
	public: void mVELDIFFWEIGHTT(bool _createToken);
	public: void mANISOVELWEIGHTT(bool _createToken);
	public: void mDELTASTRIKEDIFFWEIGHTT(bool _createToken);
	public: void mAVELRATIOT(bool _createToken);
private:
	
	static const unsigned long _tokenSet_0_data_[];
	static const antlr::BitSet _tokenSet_0;
	static const unsigned long _tokenSet_1_data_[];
	static const antlr::BitSet _tokenSet_1;
};

#endif /*INC_AnisoGAJointConfLexer_hpp_*/
