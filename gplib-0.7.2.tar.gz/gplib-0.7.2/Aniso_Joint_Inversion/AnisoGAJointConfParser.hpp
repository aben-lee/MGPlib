#ifndef INC_AnisoGAJointConfParser_hpp_
#define INC_AnisoGAJointConfParser_hpp_

#include <antlr/config.hpp>
/* $ANTLR 2.7.7 (20100319): "AnisoGAJointConf.g" -> "AnisoGAJointConfParser.hpp"$ */
#include <antlr/TokenStream.hpp>
#include <antlr/TokenBuffer.hpp>
#include "AnisoGAJointConfParserTokenTypes.hpp"
#include <antlr/LLkParser.hpp>

#line 1 "AnisoGAJointConf.g"

	#include <string>
	#include <vector>
	#include <iostream>
	#include <cstdlib>

#line 19 "AnisoGAJointConfParser.hpp"
class CUSTOM_API AnisoGAJointConfParser : public antlr::LLkParser, public AnisoGAJointConfParserTokenTypes
{
#line 21 "AnisoGAJointConf.g"

private: 
int i; double dtemp; int itemp; std::string stemp; bool btemp;
public: 
bool verbose;
int mtfitexponent;
int popsize;
double inittemp;
double coolingratio;
int generations;
double mutationprob;
double crossoverprob;
int threads;
double starttime;
double endtime;
double tensorerror;
double reserror;
double phaseerror;
std::string gatype;
std::string outputbase;
std::string mode;
std::string mtfit;
std::string mtinputdata;
std::string ptensordata;
int annealinggeneration;
bool elitist;
std::vector< double > thickbase;
std::vector< double > thickstep;
std::vector< int > thicksizes;
std::vector< double > resbase;
std::vector< double > resstep;
std::vector< int > ressizes;
std::vector< double > velbase;
std::vector< double > velstep;
std::vector< int > velsizes;
std::vector< double > aresbase;
std::vector< double > aresstep;
std::vector< int > aressizes;
std::vector< double > avelbase;
std::vector< double > avelstep;
std::vector< int > avelsizes;
std::vector< double > strikebase;
std::vector< double > strikestep;
std::vector< int > strikesizes;
std::vector< double > dstrikebase;
std::vector< double > dstrikestep;
std::vector< int > dstrikesizes;
std::vector< double > weights;
double conddiffweight;
double anisotropyweight;
double strikediffweight;
double veldiffweight;
double anisovelweight;
double deltastrikediffweight;
double avelratio;
#line 23 "AnisoGAJointConfParser.hpp"
public:
	void initializeASTFactory( antlr::ASTFactory& factory );
protected:
	AnisoGAJointConfParser(antlr::TokenBuffer& tokenBuf, int k);
public:
	AnisoGAJointConfParser(antlr::TokenBuffer& tokenBuf);
protected:
	AnisoGAJointConfParser(antlr::TokenStream& lexer, int k);
public:
	AnisoGAJointConfParser(antlr::TokenStream& lexer);
	AnisoGAJointConfParser(const antlr::ParserSharedInputState& state);
	int getNumTokens() const
	{
		return AnisoGAJointConfParser::NUM_TOKENS;
	}
	const char* getTokenName( int type ) const
	{
		if( type > getNumTokens() ) return 0;
		return AnisoGAJointConfParser::tokenNames[type];
	}
	const char* const* getTokenNames() const
	{
		return AnisoGAJointConfParser::tokenNames;
	}
	public: void configentry();
	public: bool  boolvalue();
	public: double  numvalue();
	public: std::string  stringvalue();
	public: void configfile();
public:
	antlr::RefAST getAST()
	{
		return returnAST;
	}
	
protected:
	antlr::RefAST returnAST;
private:
	static const char* tokenNames[];
#ifndef NO_STATIC_CONSTS
	static const int NUM_TOKENS = 68;
#else
	enum {
		NUM_TOKENS = 68
	};
#endif
	
	static const unsigned long _tokenSet_0_data_[];
	static const antlr::BitSet _tokenSet_0;
	static const unsigned long _tokenSet_1_data_[];
	static const antlr::BitSet _tokenSet_1;
	static const unsigned long _tokenSet_2_data_[];
	static const antlr::BitSet _tokenSet_2;
	static const unsigned long _tokenSet_3_data_[];
	static const antlr::BitSet _tokenSet_3;
	static const unsigned long _tokenSet_4_data_[];
	static const antlr::BitSet _tokenSet_4;
	static const unsigned long _tokenSet_5_data_[];
	static const antlr::BitSet _tokenSet_5;
	static const unsigned long _tokenSet_6_data_[];
	static const antlr::BitSet _tokenSet_6;
};

#endif /*INC_AnisoGAJointConfParser_hpp_*/
