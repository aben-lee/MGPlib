#include <string>
#include <fstream>
#include <vector>

namespace gplib
  {
    class AnisoJointConf
      {
    public:
      void GetData(std::ifstream &instream);
      void GetData(std::string filename);
      void WriteData(std::ofstream &outstream);
      void WriteData(std::string filename);
      bool verbose;
      std::string outputbase;
      std::string ptensordata;
      std::vector<double> thickbase;
      std::vector<double> thickstep;
      std::vector<int> thicksizes;
      std::vector<double> resbase;
      std::vector<double> resstep;
      std::vector<int> ressizes;
      std::vector<double> velbase;
      std::vector<double> velstep;
      std::vector<int> velsizes;
      std::vector<double> aresbase;
      std::vector<double> aresstep;
      std::vector<int> aressizes;
      std::vector<double> avelbase;
      std::vector<double> avelstep;
      std::vector<int> avelsizes;
      std::vector<double> strikebase;
      std::vector<double> strikestep;
      std::vector<int> strikesizes;
      std::vector<double> dstrikebase;
      std::vector<double> dstrikestep;
      std::vector<int> dstrikesizes;
      std::vector<double> weights;
      double conddiffweight;
      double anisotropyweight;
      double strikediffweight;
      double veldiffweight;
      double anisovelweight;
      double deltastrikediffweight;
      double avelratio;
      AnisoJointConf();
      ~AnisoJointConf();
      AnisoJointConf(std::string filename)
        {
          GetData(filename);
        }
      };
  }
