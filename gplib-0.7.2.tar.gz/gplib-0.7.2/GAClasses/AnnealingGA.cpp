#include "AnnealingGA.h"
#include <cmath>

#include "miscfunc.h"

#ifdef _OPENMP
#include <omp.h>
#endif

using namespace std;
using namespace gplib;
namespace gplib
  {
    AnnealingGA::AnnealingGA(GeneralPropagation* const LocalPropagation,
        GeneralPopulation* const LocalPopulation,
        GeneralTranscribe* const LocalTranscribe,
        const tObjectiveVector &IndObjective, const int nthreads):
      GeneralGA(LocalPropagation, LocalPopulation, LocalTranscribe,
          IndObjective, nthreads), InitTemperature(1.0),
          AnnealingGeneration(1), AnnealingRatio(1.0)
      {
      }

    AnnealingGA::~AnnealingGA()
      {
      }

    int AnnealingGA::GetBestIndex()
      {
        return distance(Population->GetProbabilities().begin(), max_element(
            Population->GetProbabilities().begin(),
            Population->GetProbabilities().end()));
      }

    void AnnealingGA::SetParams(const double InitT, const int AnnealG,
        const double AnnealR)
      {
        InitTemperature = InitT;
        AnnealingGeneration = AnnealG;
        AnnealingRatio = AnnealR;
      }

    void AnnealingGA::CalcProbabilities(const int iterationnumber,
        rmat &LocalMisFit, GeneralPopulation &LocalPopulation)
      {
        double sum = 0;
        const int popsize = LocalPopulation.GetPopsize();
        double T = 1.0;
        gplib::rvec CurrentMisFit;
        tprobabilityv Probabilities(popsize);
        // The temperature depends on the iteration
        if (iterationnumber < AnnealingGeneration)
          T = InitTemperature;
        else
          T = InitTemperature / AnnealingRatio;
        // for all members of the population
        for (int i = 0; i < popsize; ++i)
          {
            CurrentMisFit = column(LocalMisFit, i); //Get the misfit vector of the current member
            Probabilities(i) = exp(-ublas::sum(CurrentMisFit) / T); //apply the annealing scheme to the summed misfits
            sum += Probabilities(i); // add all misfit values
          }
        const double factor = 1. / sum;
        for (int i = 0; i < popsize; ++i)
          Probabilities(i) *= factor;
        LocalPopulation.SetProbabilities(Probabilities);
      }

    void AnnealingGA::Elitism(const int iterationnumber)
      {
      }
  }
