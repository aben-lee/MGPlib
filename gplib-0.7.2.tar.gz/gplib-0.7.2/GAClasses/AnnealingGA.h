#ifndef CANNEALINGGA_H
#define CANNEALINGGA_H
#include <vector>
#include "GeneralGA.h"
#include "VecMat.h"

namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */
    //! AnnealingGA implements a genetic algorithm with an annealing style objective function
    /*! For the first AnnealingGeneration iterations the objective function is kept constant
     * after that the misfit is stretched  with an exponential annealing function  to focus on the minimum
     */
    class AnnealingGA: public GeneralGA
      {
    private:
      //! The initial "Temperature" for the Annealing function
      double InitTemperature;
      //! Before AnnealingGeneration iterations the objective function stays constant
      int AnnealingGeneration;
      //! The ratio by which the temperature is decreased
      double AnnealingRatio;
    protected:
      //! The implementation of Elitism for the AnnealingGA, in this case this function has no effect
      void virtual Elitism(const int iterationnumber);
    public:
      //! The index of the best population member
      int GetBestIndex();
      //! Set the parameters for the annealing process
      void SetParams(const double InitT, const int AnnealG,
          const double AnnealR);
      //! How many best models exist in this iteration, for this GA it is always 1
      unsigned int virtual GetNBestmodels()
        {
          return 1;
        } // there is one best model in each iteration
      //! Return the vector containing the best indices, here it has always one component equal to GetBestIndex
      std::vector<int> virtual GetBestModelIndices()
        {
          return std::vector<int>(1, GetBestIndex());
        }
      //! Calculate the selection probabilities given the iterationnumber, misfit and population to store the results
      void virtual CalcProbabilities(const int iterationnumber,
          gplib::rmat &LocalMisFit, GeneralPopulation &LocalPopulation);
      //! The constructor only passes on the parameters to GeneralGA
      AnnealingGA(GeneralPropagation* const LocalPropagation,
          GeneralPopulation* const LocalPopulation,
          GeneralTranscribe* const LocalTranscribe,
          const tObjectiveVector &IndObjective, const int nthreads = 1);
      virtual ~AnnealingGA();
      };
  /* @} */
  }
#endif // CANNEALINGGA_H
