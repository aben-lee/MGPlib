#include "BinaryPopulation.h"

namespace gplib
  {
    BinaryPopulation::BinaryPopulation(const int popsize, const int genesize,
        GeneralRNG &LocalRandom, const bool init) :
      GeneralPopulation(popsize, genesize), Random(LocalRandom)
      {
        if (init)
          InitPop();
      }

    BinaryPopulation::~BinaryPopulation()
      {
      }

    void BinaryPopulation::InitPop()
      {
        const size_t popsize = Population.size1();
        const size_t genesize = Population.size2();
        for (size_t i = 0; i < popsize; ++i)
          for (size_t j = 0; j < genesize; ++j)
            Population(i, j) = (Random.GetNumber() > 0.5);
      }

    BinaryPopulation& BinaryPopulation::operator=(
        const BinaryPopulation &source)
      {
        if (this == &source)
          return *this;
        GeneralPopulation::operator=(source);
        Random = source.Random;
        return *this;
      }
  }
