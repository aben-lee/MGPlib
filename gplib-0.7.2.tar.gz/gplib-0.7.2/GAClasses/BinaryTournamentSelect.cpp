#include "BinaryTournamentSelect.h"
#include "NumUtil.h"
#include <iostream>
#include <algorithm> // for swap
#include "FatalException.h"

using namespace std;
namespace gplib
  {
    BinaryTournamentSelect::BinaryTournamentSelect(GeneralRNG &LocalRandom,
        tProbabilityFunction myPF, tDistanceFunction myDF) :
      distancecount(0), Random(LocalRandom), ProbabilityFunction(myPF),
          DistanceFunction(myDF), ReturnIndex(0)
      {

      }

    BinaryTournamentSelect::~BinaryTournamentSelect()
      {
        cout << "Distance Count: " << distancecount << endl;
      }

    void BinaryTournamentSelect::DoInit()
      {
        if (ProbabilityFunction().size() != DistanceFunction().size())
          throw FatalException(
              "Probabilities and Crowding distances do not have the same size !");
        //Get Probabiliteis and crowding distances
        localprobabilities = ProbabilityFunction();
        localdistances = DistanceFunction();
        const size_t popsize = localdistances.size();
        PopulationIndex.assign(popsize * 2, 0); // we need every member index twice
        for (size_t i = 0; i < popsize; ++i)
          {
            PopulationIndex.at(i) = i;
            PopulationIndex.at(i + popsize) = i;
          }
        for (size_t i = 0; i < popsize; ++i)//shuffle the indices
          {
            int CurrentIndex = Random.GetNumber(popsize - i); //select an index for the first half
            swap(PopulationIndex.at(popsize - i - 1), PopulationIndex.at(
                CurrentIndex)); //swap indices
            CurrentIndex = Random.GetNumber(popsize - i); //generate a new index
            swap(PopulationIndex.at(2 * popsize - i - 1), PopulationIndex.at(
                popsize + CurrentIndex)); //swap indices in the secondhalf
          }
        ReturnIndex = 0;
      }

    size_t BinaryTournamentSelect::DoGetOne()
      {
        const double tolerance = 1e-5;
        //get two indices from the randomized PopulationIndex
        const int fatherindex = PopulationIndex.at(ReturnIndex);
        const int motherindex = PopulationIndex.at(ReturnIndex + 1);
        //increase index for next call
        ReturnIndex += 2;
        //compare within numerical precision
        const int comparison = fcmp(localprobabilities(fatherindex),
            localprobabilities(motherindex), tolerance);
        switch (comparison)
          {
        case 1:
          return fatherindex; //father has higher fitness
        case -1:
          return motherindex; //mother has higher fitness
        case 0:
          distancecount++; //have same fitness, decision based on crowding distance
          if (localdistances(fatherindex) >= localdistances(motherindex))
            return fatherindex;
          else
            return motherindex;
        default:
          throw FatalException(
              "Something went very wrong in CBinaryTournamentSelect::GetOne");
          }
      }
  }
