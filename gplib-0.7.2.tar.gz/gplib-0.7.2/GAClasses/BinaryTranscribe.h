#ifndef CSTANDARDTRANSCRIBE_H
#define CSTANDARDTRANSCRIBE_H
#include "GeneralTranscribe.h"

namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */

    //! BinaryTranscibe implements transcription for standard binary populations
    /*! It works for simple binary string populations with the "canonic" decoding of the bit string
     * For each parameter a basevalue, stepsize and genesize has to be specified
     * upon construction. These three vectors have to have identical size.
     */
    class BinaryTranscribe: public GeneralTranscribe
      {
    protected:
      //! The minimum value for each parameter
      const ttranscribed basevalues;
      //! The stepsize associated to a bit change for each parameter
      const ttranscribed stepsizes;
      //! The number of bits for each parameter
      const tsizev genesizes;
    public:
      //! Implements the abstract function from GeneralTranscribe
      virtual ttranscribed GetValues(const tpopmember &member);
      //! Without basevalues, stepsizes and genesizes BinaryTranscribe does not work, so we enforce their use by including them in the constructor
      BinaryTranscribe(const ttranscribed &base, const ttranscribed &step,
          const tsizev &gene);
      //! Returns the number of parameters that are encoded in the binary string
      virtual int GetNparams()
        {
          return basevalues.size();
        }
      ;
      //! We declare a copy constructor that copies the private variables;
      BinaryTranscribe(const BinaryTranscribe &Old);
      BinaryTranscribe(const GeneralTranscribe &Old);
      virtual ~BinaryTranscribe();
      };
  /* @} */
  }
#endif // CSTANDARDTRANSCRIBE_H
