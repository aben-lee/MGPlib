//============================================================================
// Name        : GAConf.h
// Author      : Apr 7, 2010
// Version     : 
// Copyright   : 2010, mmoorkamp
//============================================================================


#ifndef GACONF_H_
#define GACONF_H_

#include <string>

namespace gplib
  {

    class GAConf
      {
    public:
      int popsize;
      double inittemp;
      double coolingratio;
      int generations;
      double mutationprob;
      double crossoverprob;
      std::string gatype;
      int annealinggeneration;
      bool elitist;
      void GetData(std::ifstream &instream);
      GAConf();
      virtual ~GAConf();
      };

  }

#endif /* GACONF_H_ */
