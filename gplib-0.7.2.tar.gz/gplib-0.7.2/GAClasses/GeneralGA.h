#ifndef CGENERALGA_H
#define CGENERALGA_H

#include "GeneralPropagation.h"
#include "GeneralObjective.h"
#include "GeneralPopulation.h"
#include "GeneralTranscribe.h"
#include "GeneralRNG.h"
#include "GeneralSelect.h"
#include "UniquePop.h"
#include <vector>
#include <fstream>
#include "VecMat.h"
#include <boost/shared_ptr.hpp>
namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */

    //! General genetic algorithm class
    /*! GeneralGA implements the functionality that is common to all genetic algorithms
     * it declares a bunch of virtual functions, that are implemented in derived classes and
     * pointers to several other objects that together make up the genetic algorithm
     */
    class GeneralGA
      {
    public:
      //! We provide some typedefs that are used in other parts as well
      typedef std::vector<gplib::rvec> tparamvector;
      typedef std::vector<boost::shared_ptr<GeneralObjective> >
          tObjectiveVector;
      typedef std::vector<std::vector<int> > tparamindv;
    private:
      //! Calculate the misfit for all models, this implements the core functionality for misfit calculations
      void CalcMisfit(const int iterationnumber);
      //! The number of threads for parallel calculation, works only with OpenMP
      int Threads;
      //the process ID of the main program, used for file identification
      int Programnum;
      //! The average summed fit
      double CombAvgFit;
      //! The maximum summed fit
      double CombMaxFit;
      //! The minimum summed fit
      double CombMinFit;
      //! Should the GA be elitist, i.e. ensure that the best models are preserved
      bool Elitist;
      //!  Holds the summed Fit for each objective function
      std::vector<double> CombMisFit;
      std::vector<double> AvgFit;
      //! Maximum Fit for each objective function
      std::vector<double> MaxFit;
      //! Minimum Fit for each objective Function
      std::vector<double> MinFit;
      //! The weight for each objective function, the exact meaning will depend on the algorithm, i.e. the derived class
      std::vector<double> Weights;
      //! The object holding one copy of each model vector calculated so far
      UniquePop UniquePopHist;
      //! For each objective function we store the indices of the complete model vector that each objective function needs for its calculations
      tparamindv ParameterIndices;
    protected:
      gplib::rmat OldMisFit;
      //! The number of objective functions we're using
      const unsigned int nobjective;
      //! A matrix holding the numerical model vectors (transcribed from the genes) for each population member
      gplib::rmat Transcribed;
      //! Misfit first index objective function second index population member
      gplib::rmat MisFit;
      //! The vector holding the objective functions
      tObjectiveVector Objective;
      //! A pointer to an object dealing with propagation
      GeneralPropagation* const Propagation;
      //! A pointer to an object holding the population
      GeneralPopulation* const Population;
      //! A pointer to an object translating genes to model vectors
      GeneralTranscribe* const Transcribe;
      //! default implementation does nothing, this can be overriden @see ParetoGA
      void virtual Elitism(const int iterationnumber)
        {
        }
      ;
    public:
      //! Return the weight for each objecive function
      const std::vector<double> &GetWeights()
        {
          return Weights;
        }
      ;
      //! Copy the appropriate parameter values from the transcribed vector for use with the objective functions
      void SetupParams(const ttranscribed &member, tparamvector &params);
      //! Return the average fitness for each objective function
      const std::vector<double> &GetAvgFit()
        {
          return AvgFit;
        }
      ;
      //! Do we want elitist behaviour, effect depends on the GA implementetion in the derived class
      void SetElitist(const bool IsElitist)
        {
          Elitist = IsElitist;
        }
      ;
      //! Set the weights for each objective function
      void SetWeights(const std::vector<double> &LocalWeights);
      //! Configure which parts of the complete parameter vector are used in each objective function
      void SetParameterIndices(const tparamindv &Indices);
      //! Print Fitness statistics for each objective function to output
      void PrintFitStat(std::ostream &output);
      //!Print misfit for each member to output
      void PrintMisfit(std::ostream &output);
      //!Print transcribed values for each member to output
      void PrintTranscribed(std::ostream &output);
      //! Print each population member exactly once
      void PrintUniquePop(std::ostream &output)
        {
          UniquePopHist.PrintAll(output);
        }
      ;
      //! Print misfit of the best population members
      void PrintBestMisfit(std::ostream &output);
      //! This has to be implemented in the derived class to return the number of best models
      unsigned int virtual GetNBestmodels() = 0;
      //! Return the indices of the best models
      std::vector<int> virtual GetBestModelIndices() = 0;
      //! Do one iteration of the GA
      void virtual DoIteration(const int iterationnumber, const bool last);
      //! Calculate the Probabilities
      void virtual CalcProbabilities(const int iterationnumber,
          gplib::rmat &LocalMisFit, GeneralPopulation &LocalPopulation) = 0;
      GeneralGA(GeneralPropagation* const LocalPropagation,
          GeneralPopulation* const LocalPopulation,
          GeneralTranscribe* const LocalTranscribe,
          const tObjectiveVector &IndObjective, const int nthreads = 1);
      virtual ~GeneralGA();
      };
  /* @} */
  }
#endif // CGENERALGA_H
