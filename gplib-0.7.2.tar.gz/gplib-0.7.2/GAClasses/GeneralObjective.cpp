#include "GeneralObjective.h"
#include <numeric>
#include <cmath>

namespace gplib
  {
    GeneralObjective::GeneralObjective() :
      FitExponent(2), RMS(0.0), ParallelId("single")
      {
      }

    GeneralObjective::~GeneralObjective()
      {
      }

    GeneralObjective::GeneralObjective(const GeneralObjective &Old) :
      FitExponent(Old.FitExponent), RMS(Old.RMS), Misfit(Old.Misfit),
          SynthData(Old.SynthData), ParallelId(Old.ParallelId)
      {
      }

    GeneralObjective &GeneralObjective::operator=(
        const GeneralObjective &source)
      {
        if (this != &source)
          {
            FitExponent = source.FitExponent;
            RMS = source.RMS;
            Misfit = source.Misfit;
            SynthData = source.SynthData;
            ParallelId = source.ParallelId;
          }
        return *this;
      }

    void GeneralObjective::PreParallel(const ttranscribed &member)
      {

      }

    void GeneralObjective::SafeParallel(const ttranscribed &member)
      {

      }

    double GeneralObjective::CalcPerformance(const ttranscribed &member)
      {
        PreParallel(member);
        SafeParallel(member);
        return PostParallel(member);
      }

    double GeneralObjective::CalcMisfit(const double measured,
        const double predicted, const double measerror,
        const double errorlevel, const int index)
      {
        const double absolutemin = 1e-6;
        double currvalue = std::abs(measured - predicted);
        double absoluteerror = std::max(measerror, std::abs(measured * errorlevel));
        currvalue /= std::max(absolutemin, absoluteerror);
        currvalue = std::pow(currvalue, GetFitExponent());
        SetMisfit()(index) = currvalue; //set the misfit vector
        SetSynthData()(index) = measured;
        return currvalue;

      }

  /* For later implementation
   *
   * virtual GeneralObjective::GetGradient()
   {
   }

   virtual GeneralObjective::GetPartialDerivatives()
   {
   }*/
  }
