#include "GeneralPopulation.h"
#include "VecMat.h"
using namespace std;
namespace gplib
  {
    GeneralPopulation::GeneralPopulation(const int popsize, const int genesize) :
      Probabilities(popsize), CrowdingDistances(popsize), Population(popsize,
          genesize)
      {
        OldStored = false;
      }

    GeneralPopulation::~GeneralPopulation()
      {
      }

    GeneralPopulation::GeneralPopulation(GeneralPopulation &Old):
      OldPopulation(Old.OldPopulation), Probabilities(Old.Probabilities),
          CrowdingDistances(Old.CrowdingDistances), Population(Old.Population)
      {
        OldStored = Old.OldStored;
      }

    GeneralPopulation::GeneralPopulation(const tpopulation &FirstHalf,
        const tpopulation &SecondHalf):
      OldPopulation(FirstHalf.size1() + SecondHalf.size1(), FirstHalf.size2()),
          Probabilities(FirstHalf.size1() + SecondHalf.size1()),
          CrowdingDistances(FirstHalf.size1() + SecondHalf.size1()),
          Population(FirstHalf.size1() + SecondHalf.size1(), FirstHalf.size2())
      {
        OldStored = false;
        ublas::matrix_range<tpopulation> PopFirstHalf(Population, ublas::range(
            0, FirstHalf.size1()), ublas::range(0, FirstHalf.size2()));
        ublas::matrix_range<tpopulation> PopSecondHalf(Population,
            ublas::range(FirstHalf.size1(), FirstHalf.size1()
                + SecondHalf.size1()), ublas::range(0, FirstHalf.size2()));
        PopFirstHalf = FirstHalf;
        PopSecondHalf = SecondHalf;
      }

    GeneralPopulation& GeneralPopulation::operator=(
        const GeneralPopulation &source)
      {
        if (this != &source)
          {
            OldPopulation = source.OldPopulation;
            Population = source.Population;
            Probabilities = source.Probabilities;
            CrowdingDistances = source.CrowdingDistances;
          }
        return *this;
      }

    void GeneralPopulation::PrintPopulation(ostream &output) const
      {
        const int popsize = Population.size1();
        const int genesize = Population.size2();
        int i, j;
        output << popsize << " " << genesize << endl;
        for (i = 0; i < popsize; ++i)
          {
            for (j = 0; j < genesize; ++j)
              output << Population(i, j) << " ";
            output << endl;
          }
      }
    void GeneralPopulation::ResizePop(const int popsize, const int genesize)
      {
        OldPopulation.resize(popsize, genesize);
        Population.resize(popsize, genesize);
        Probabilities.resize(popsize);
        CrowdingDistances.resize(popsize);
      }

    void GeneralPopulation::ReadPopulation(std::istream &input)
      {
        unsigned int popsize, genesize, dummy;
        unsigned int i, j;

        input >> popsize >> genesize;
        ResizePop(popsize, genesize);
        for (i = 0; i < popsize; ++i)
          {
            for (j = 0; j < genesize; ++j)
              {
                input >> dummy;
                Population(i, j) = (dummy == 1);
              }
          }
      }
    void GeneralPopulation::PrintProbabilities(std::ostream &output) const
      {
        for (unsigned int i = 0; i < Probabilities.size(); ++i)
          {
            output << Probabilities(i) << " ";
          }
        output << endl;
      }

    void GeneralPopulation::PrintDistances(std::ostream &output) const
      {
        for (unsigned int i = 0; i < CrowdingDistances.size(); ++i)
          {
            output << CrowdingDistances(i) << " ";
          }
        output << endl;
      }
  }
