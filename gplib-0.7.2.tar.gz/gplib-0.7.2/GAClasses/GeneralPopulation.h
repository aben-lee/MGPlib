#ifndef CGENERALPOPULATION_H
#define CGENERALPOPULATION_H
#include "gentypes.h"
#include "GeneralRNG.h"
#include "FatalException.h"

namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */

    //! The base class for the population of a genetic algorithm, implements storage and access functions
    class GeneralPopulation
      {
    private:
      //! The population of the last iteration for elitism
      tpopulation OldPopulation;
      //! Did we store the last population
      bool OldStored;
      //! The selection probabilities for each population member
      tprobabilityv Probabilities;
      //! The crowding distance for each population member
      tcrowddistv CrowdingDistances;
    protected:
      //! Change the population size
      void ResizePop(const int popsize, const int genesize);
      //! The population of the current iteration
      tpopulation Population;
    public:
      virtual void InitPop()
        {
        }
      ;
      const tpopulation& GetOldPopulation() const
        {
          if (OldStored)
            return OldPopulation;
          else
            throw FatalException("Old Population has not been stored");
        }
      ;
      void StoreOldPopulation()
        {
          OldPopulation = Population;
          OldStored = true;
        }
      ;
      void PrintPopulation(std::ostream &output) const;
      void ReadPopulation(std::istream &input);
      void PrintProbabilities(std::ostream &output) const;
      void PrintDistances(std::ostream &output) const;
      const tpopulation& GetPopulation() const
        {
          return Population;
        }
      ;
      const tprobabilityv& GetProbabilities() const
        {
          return Probabilities;
        }
      ;
      const tcrowddistv& GetCrowdingDistances() const
        {
          return CrowdingDistances;
        }
      ;
      void SetPopulation(const tpopulation &LocalPop)
        {
          OldPopulation = Population;
          Population = LocalPop;
          OldStored = true;
        }
      ;
      void SetProbabilities(const tprobabilityv &LocalProb)
        {
          Probabilities = LocalProb;
        }
      ;
      void SetCrowdingDistances(const tcrowddistv &LocalDist)
        {
          CrowdingDistances = LocalDist;
        }
      ;
      int GetPopsize() const
        {
          return Population.size1();
        }
      ;
      int GetGenesize() const
        {
          return Population.size2();
        }
      ;
      GeneralPopulation(const int popsize, const int genesize);
      GeneralPopulation(GeneralPopulation &Old);
      //! Merge two populations in a new population object
      GeneralPopulation(const tpopulation &FirstHalf,
          const tpopulation &SecondHalf);
      virtual GeneralPopulation& operator=(const GeneralPopulation &source);
      virtual ~GeneralPopulation();
      };
  /* @} */
  }
#endif // CGENERALPOPULATION_H
