#ifndef CGENERALPROPAGATION_H
#define CGENERALPROPAGATION_H
#include "GeneralSelect.h"
#include "GeneralPopulation.h"
#include "GeneralRNG.h"
namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */

    //! The base class for genetic algorithm propagation methods
    /*! This class defines the common functionality that is necessary
     * to generate a new population from the current generation. The implementation
     * details depend on the type of GA and Population encoding and those classes
     * have to match to do anything useful.
     */
    class GeneralPropagation
      {
    protected:
      virtual void Crossover(tpopmember &father, tpopmember &mother);
      virtual void Mutation(tpopmember &child);
      GeneralSelect* const Select;
      GeneralPopulation* const Population;
      GeneralRNG* const Random;
      double MutationProb;
      double CrossoverProb;
    public:
      virtual void NextGeneration() = 0;
      void SetParams(const double mutation, const double crossover)
        {
          MutationProb = mutation;
          CrossoverProb = crossover;
        }
      ;
      GeneralPropagation(GeneralSelect* const LocalSelect,
          GeneralPopulation* const LocalPopulation,
          GeneralRNG* const LocalRandom);
      virtual ~GeneralPropagation();
      GeneralPropagation(GeneralPropagation &Old);
      };
  /* @} */
  }
#endif // CGENERALPROPAGATION_H
