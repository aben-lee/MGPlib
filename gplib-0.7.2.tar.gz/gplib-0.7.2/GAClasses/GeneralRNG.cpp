#include "GeneralRNG.h"

namespace gplib
  {
    GeneralRNG::GeneralRNG()
      {
      }
    GeneralRNG::~GeneralRNG()
      {
      }
  }
