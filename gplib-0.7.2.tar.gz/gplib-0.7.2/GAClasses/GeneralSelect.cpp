#include "GeneralSelect.h"
#include "FatalException.h"

namespace gplib
  {
    GeneralSelect::GeneralSelect() :
      initialized(false)
      {
      }

    GeneralSelect::~GeneralSelect()
      {
      }

    size_t GeneralSelect::GetOne()
      {
        if (!initialized)
          throw FatalException(
              "Trying to use Select::GetOne without initializing !");
        return DoGetOne();
      }
  }
