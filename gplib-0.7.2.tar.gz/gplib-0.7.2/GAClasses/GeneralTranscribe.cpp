#include "GeneralTranscribe.h"

namespace gplib
  {
    GeneralTranscribe::GeneralTranscribe()
      {
      }
    GeneralTranscribe::~GeneralTranscribe()
      {
      }

    GeneralTranscribe::GeneralTranscribe(const GeneralTranscribe &Old)
      {

      }
  }
