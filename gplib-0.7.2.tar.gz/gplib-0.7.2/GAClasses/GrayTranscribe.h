#ifndef GRAYTRANSCRIBE_H_
#define GRAYTRANSCRIBE_H_
#include "BinaryTranscribe.h"

namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */
    //! This class implements the Gray code representation of a binary string and the corresponding transcription
    class GrayTranscribe: public BinaryTranscribe
      {
    public:
      virtual ttranscribed GetValues(const tpopmember &member); //!< Re-Implements the  function from BinaryTranscribe
      GrayTranscribe(const ttranscribed &base, const ttranscribed &step,
          const tsizev &gene);
      virtual ~GrayTranscribe();
      };
  /* @} */
  }
#endif /*GRAYTRANSCRIBE_H_*/
