#ifndef CPARETOGA_H
#define CPARETOGA_H

#include "GeneralGA.h"
#include <iostream>
#include <vector>
#include "VecMat.h"

namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */
    //! Implements a genetic algorithm based on the concept of pareto-optimality, best suited for multi-objective problems
    /*! The class ParetoGA implements a variant of NSGA-II by Deb et al.:
     * Deb, K., Pratap. A, Agarwal, S., and Meyarivan, T. (2002). A fast and elitist multi-objective genetic algorithm: NSGA-II. IEEE Transaction on Evolutionary Computation, 6(2), 181-197.
     */
    class ParetoGA: public GeneralGA
      {
    private:
      typedef ublas::matrix_row<gplib::rmat>::const_iterator tMisfitIterator;
      void CalcCrowdingDistance(gplib::rmat &LocalMisFit,
          GeneralPopulation &LocalPopulation);
      std::vector<std::vector<int> > Ranks;
      int MaxRanks;
    protected:
      //! The function Elitism ensures that the best models are preserved after mutation and crossover
      void virtual Elitism(const int iterationnumber);
    public:
      //! Return the size of the pareto-optimal front
      unsigned int virtual GetNBestmodels()
        {
          return Ranks.front().size();
        }
      //! Get the indices of the models within the Pareto front
      std::vector<int> virtual GetBestModelIndices()
        {
          return Ranks.front();
        }
      //! Calculate the probabilities of reproduction by ranking the population
      void virtual CalcProbabilities(const int iterationnumber,
          gplib::rmat &LocalMisFit, GeneralPopulation &LocalPopulation);
      //! Write the population by ranks to the stream output
      void PrintRanks(std::ostream &output);
      //! Write the models in the pareto-optimal front to stream output
      void PrintFront(std::ostream &output);
      //! The constructor needs other classes that determine the behaviour of the GA
      ParetoGA(GeneralPropagation* const LocalPropagation,
          GeneralPopulation* const LocalPopulation,
          GeneralTranscribe* const LocalTranscribe,
          const tObjectiveVector &IndObjective, const int nthreads = 1) :
        GeneralGA(LocalPropagation, LocalPopulation, LocalTranscribe,
            IndObjective, nthreads)
        {
        }
      virtual ~ParetoGA();
      };
  /* @} */
  }
#endif // CPARETOGA_H
