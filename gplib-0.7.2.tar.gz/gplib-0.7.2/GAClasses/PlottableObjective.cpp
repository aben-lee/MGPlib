#include "PlottableObjective.h"
namespace gplib
  {
    PlottableObjective::PlottableObjective()
      {
      }

    PlottableObjective::~PlottableObjective()
      {
      }

    PlottableObjective& PlottableObjective::operator=(
        const PlottableObjective& source)
      {
        if (this == &source)
          return *this;

        GeneralObjective::operator=(source);
        return *this;

      }
  }
