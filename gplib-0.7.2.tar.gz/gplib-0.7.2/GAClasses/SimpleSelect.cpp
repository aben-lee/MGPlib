#include "SimpleSelect.h"
#include <cmath>
#include <iostream>

using namespace std;
namespace gplib
  {
    SimpleSelect::SimpleSelect(GeneralRNG &LocalRandom,
        tProbabilityFunction myPF) :
      Random(LocalRandom), ProbabilityFunction(myPF)
      {

      }

    SimpleSelect::~SimpleSelect()
      {
      }
    //The initialiazation routine basically does all the work
    //so that when we draw a member in the propagation phase
    //we only return the index of the a random selected member
    void SimpleSelect::DoInit()
      {
        const tprobabilityv probabilities = ProbabilityFunction();
        const size_t popsize = probabilities.size();
        size_t currentindex = 0;

        std::vector<double> fraction(popsize, 0);
        indices.assign(popsize, 0);
        remain = popsize;
        //go through the whole population
        for (size_t i = 0; i < popsize; ++i)
          {
            //how many members can we expect in the new population based
            //on the probabilities
            const double expected = probabilities(i) * popsize;
            //we always assign the expected number rounded down
            //to the new population
            int assign = int(floor(expected));
            //and the save the difference between the rounded
            //and not rounded to determine additional members
            //later
            fraction.at(i) = expected - assign;
            //generate assign times index entries in the index
            //vector that describes the new population
            while (assign > 0)
              {
                --assign;
                indices.at(currentindex) = i;
                ++currentindex;
              }

          }
        //now we determine the remainder of the population
        //based on the difference between expected and assigned
        size_t fractionindex = 0;
        //as long as the population is not full
        while (currentindex < popsize)
          {
            //cycle through the population members
            //and see if we want to include the current member
            if (Random.GetNumber() <= fraction.at(fractionindex))
              {
                indices.at(currentindex) = fractionindex;
                ++currentindex;
                fraction.at(fractionindex) -= 1.0;
              }
            ++fractionindex;
            //when we reached the end of the population, go back to the beginning
            if (fractionindex >= popsize)
              fractionindex -= popsize;
          }
      }

    size_t SimpleSelect::DoGetOne()
      {
        int pick = Random.GetNumber(remain);
        int result = indices.at(pick);
        // Have to reduce remain before because it starts with popsize but array is 0..popsize-1
        --remain;
        indices.at(pick) = indices.at(remain);
        return (result);
      }
  }
