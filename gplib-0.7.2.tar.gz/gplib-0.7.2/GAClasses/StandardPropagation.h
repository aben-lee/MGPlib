#ifndef CSTANDARDPROPAGATION_H
#define CSTANDARDPROPAGATION_H

#include "GeneralPropagation.h"

namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */
    //! This is the standard propagation class that generates a new population from the old one
    /*! This class implements the standard propagation schemes for genetic algorithms, selection,
     * crossover and mutation. Each of these steps is performed by a class that we can choose
     * in the constructor.
     */
    class StandardPropagation: public GeneralPropagation
      {
    public:
      virtual void NextGeneration();
      //! The constructor takes pointers to various base classes that configure the behaviour of the selection process.
      /*! This class is basically just a skeleton that uses the objects that implement Selection, Crossover and Mutation
       * in the right order.
       * @param LocalSelect A pointer to an object that implements a selection scheme for the genetic algorithm
       * @param LocalPopulation A pointer to a population object
       * @param LocalRandom A pointer to a random number generator
       */
      StandardPropagation(GeneralSelect* const LocalSelect,
          GeneralPopulation* const LocalPopulation,
          GeneralRNG* const LocalRandom);
      virtual ~StandardPropagation();
      };
  /* @} */
  }
#endif // CSTANDARDPROPAGATION_H
