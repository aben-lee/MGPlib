#ifndef CTESTOBJECTIVE_H
#define CTESTOBJECTIVE_H

#include "GeneralObjective.h"

namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */
    class TestObjective: public GeneralObjective
      {
    public:
      virtual TestObjective *clone() const
        {
          return new TestObjective(*this);
        }
      virtual double PostParallel(const ttranscribed &member);
      TestObjective();

      virtual ~TestObjective();
      };
  /* @} */
  }
#endif // CTESTOBJECTIVE_H
