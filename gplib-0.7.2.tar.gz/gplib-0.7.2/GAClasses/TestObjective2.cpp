#include "TestObjective2.h"
#include <cmath>

namespace gplib
  {
    TestObjective2::TestObjective2() :
      compatible(compat)
      {
      }

    TestObjective2::~TestObjective2()
      {
      }

    double TestObjective2::PostParallel(const ttranscribed &member)
      {
        double returnvalue = 0.0;
        if (compat)
          {
            returnvalue = 10. * std::pow(member(1) - std::pow(member(0), 2), 2) + std::pow(1.
                - member(0), 2);
          }
        else
          {
            returnvalue = 10. * std::pow(member(0) + std::pow(member(1), 2), 2) + std::pow(1.
                + member(1), 2);
          }
        return returnvalue;
      }
  }
