#ifndef CTESTOBJECTIVE2_H
#define CTESTOBJECTIVE2_H

#include "GeneralObjective.h"
namespace gplib
  {
    /** \addtogroup gainv Genetic algorithm optimization */
    /* @{ */
    class TestObjective2: public GeneralObjective
      {
    private:
      bool compatible;
    public:
      virtual TestObjective2 *clone() const
        {
          return new TestObjective2(*this);
        }
      virtual double PostParallel(const ttranscribed &member);
      TestObjective2(bool compat = true);
      virtual ~TestObjective2();
      };
  /* @} */
  }
#endif // CTESTOBJECTIVE_H
