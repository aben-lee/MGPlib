#include "UniformRNG.h"
#include <ctime>
#include <boost/cast.hpp>

using namespace std;

namespace gplib
  {
    //the constructor sets up the boost random number generator
    UniformRNG::UniformRNG() :
      generator(static_cast<unsigned int> (std::time(NULL))), real_dist(
          generator)
      {

      }

    UniformRNG::~UniformRNG()
      {
      }

    float UniformRNG::GetNumber(const float low, const float high)
      {
        //return float between low and high
        return low + (high - low) * GetNumber();
      }

    float UniformRNG::GetNumber()
      {
        //just forward the call to the boost random number generator
        return real_dist();
      }

    unsigned int UniformRNG::GetNumber(const unsigned int max)
      {
        //make an unsigned integer from the random float
        return (boost::numeric_cast<unsigned int>(max * real_dist()));
      }
  }
