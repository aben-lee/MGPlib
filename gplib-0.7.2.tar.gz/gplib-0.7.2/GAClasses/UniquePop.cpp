#include "UniquePop.h"

#include <iomanip>

using namespace std;

namespace gplib
  {

    UniquePop::UniquePop()
      {
      }
    UniquePop::~UniquePop()
      {
      }

    bool UniquePop::Insert(const tfitvec &fitness,
        const ttranscribed &popmember)
      {
        pair<tmembermap::iterator, bool> insertresult = MemberHashMap.insert(
            std::make_pair(popmember,fitness));
        return insertresult.second;
      }

    bool UniquePop::Find(const ttranscribed &popmember, tfitvec &fitness)
      {
        tmembermap::iterator FindPos = MemberHashMap.find(popmember);
        if (FindPos == MemberHashMap.end())
          return false;

        fitness = FindPos->second;
        return true;

      }

    void UniquePop::PrintAll(std::ostream &output)
      {
        tmembermap::iterator outit;

        for (outit = MemberHashMap.begin(); outit != MemberHashMap.end(); ++outit)
          {
            output << setprecision(10);
            copy(outit->first.begin(), outit->first.end(), ostream_iterator<
                double> (output, " "));
            output << "    ";
            copy(outit->second.begin(), outit->second.end(),
                ostream_iterator<double> (output, " "));
            output << endl;
          }
      }
  }
