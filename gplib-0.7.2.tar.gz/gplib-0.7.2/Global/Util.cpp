#include "Util.h"
#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/filesystem.hpp>
#ifdef HAVEREADLINE
#include <readline/readline.h>
#endif

namespace gplib
  {
    std::string AskFilename(const std::string prompt)
      {
        std::string result;
#ifdef HAVEREADLINE
        char *inputline = readline(prompt.c_str());
        result = inputline;
        free(inputline);
#endif
#ifndef HAVEREADLINE
        std::cout << prompt;
        std::cin >> result;
#endif    
        boost::trim(result);
        return result;
      }

    std::string FindToken(std::ifstream &filestream, const std::string &token)
      {
        //first we didn't find anything and we are not at the end of the file
        bool found = false;
        bool end = false;
        //holds the current line in the file
        std::string line;
        //while we didn't find the token and are not at the end of the file
        while (!found && !end)
          {
            //we read in the current line
            //if successful try to find the token, otherwise assume we reached
            //the end of the file (at least of what we can read)
            if (std::getline(filestream, line))
              {
                found = boost::algorithm::contains(line, token);
              }
            else
              {
                end = true;
              }
          }
        //if we found it we return the line, otherwise we throw an exception
        if (found)
          {
            return line;
          }
        else
          {
            throw FatalException("Token " + token + " not found !");
          }
      }

    void CleanFiles(const std::string &Root)
      {
        boost::filesystem::directory_iterator end_itr; // default construction yields past-the-end
        //go through all files in the current directory
        for (boost::filesystem::directory_iterator itr(
            boost::filesystem::current_path()); itr != end_itr; ++itr)
          {
            //get the name of the current file and see whether it starts
            //with the root given as a parameter
            const std::string currfile = itr->path().filename().string();
            if (boost::algorithm::starts_with(currfile, Root))
              {
                boost::filesystem::remove_all(currfile);
              }
          }
      }
  }
