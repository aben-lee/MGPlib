#ifndef UTIL_H_
#define UTIL_H_
#include <string>
#include <fstream>
#include "FatalException.h"

namespace gplib
  {
    /** \addtogroup genfunc General functions from various areas */
    /* @{ */

    //! Generate a sequence of integers, for use with generate and generate_n algorithms, taken from Josuttis, p. 296
    /*! The constructor takes the starting value and each call to operator() returns the current value and increases
     * it by 1.
     */
    class IntSequence
      {
    private:
      int value;
    public:
      IntSequence(int start) :
        value(start)
        {
        }
      int operator()()
        {
          return value++;
        }
      };

    //! Given a filename, return the file extension including the dot, i.e. for test.t it will return .t
    inline std::string GetFileExtension(const std::string &filename)
      {
        std::string ending;
        size_t dotpos = filename.find_last_of('.');
        if (dotpos != std::string::npos)
          ending = filename.substr(dotpos);
        return ending;
      }

    //! Display the prompt and return a filename read in from the command line with either readline or cin
    /*! The functions will display the string prompt thour cout and read in a filename. If
     * HAVEREADLINE is defined it will use the readline library for automatic completion. Otherwise
     * it will simply use cin. The read filename is trimmed of whitespace and returned.
     */
    std::string AskFilename(const std::string prompt);

    //! Given an open input filestream search for the string token in the file and return the line containing that token, throws if fails
    /*! This function performs a case-sensitive search for the content of the string token. If a line in the file contains
     * this string the function returns this line. If the token cannot be found it throws a FatalException.
     * @param filestream An open infile stream, will be pointing to the next line after finding the token
     * @param token The token to search for
     * @return The line in the file that contains the token
     */
    std::string FindToken(std::ifstream &filestream, const std::string &token);

    //! Remove all file starting with Root from current directory
    void CleanFiles(const std::string &Root);
/* @} */
}
#endif /*UTIL_H_*/
