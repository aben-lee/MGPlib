#include "FileAbort.h"
#include <fstream>
#include "stringcompare.h"
#include "Util.h"
#define BOOST_TEST_MODULE GlobalTest
#define BOOST_TEST_MAIN ...
#include <boost/test/included/unit_test.hpp>

void CreateFile()
  {
    std::ofstream abortfile;
    abortfile.open("abort");
    abortfile << "a";
    abortfile.close();
  }

BOOST_AUTO_TEST_CASE(GlobalTest)
  {
    CreateFile();
    BOOST_CHECK( WantAbort());
    RemoveAbort();
    BOOST_CHECK( !WantAbort() );
    BOOST_CHECK(ciStringCompare("best","test"));
    BOOST_CHECK(!ciStringCompare("test","TEST"));
    BOOST_CHECK(!ciStringCompare("test","Different"));
    BOOST_CHECK(!ciCharLess()('t','T'));
    BOOST_CHECK(!ciCharLess()('t','t'));
    BOOST_CHECK(!ciCharLess()('t','A'));
    BOOST_CHECK(ciCharLess()('A','t'));
    BOOST_CHECK(ciCharLess()('a','t'));
    BOOST_CHECK(IntSequence(5)()==5);
    IntSequence Seq(10);
    BOOST_CHECK(Seq()==10);
    BOOST_CHECK(Seq()==11);
    BOOST_CHECK(GetFileExtension("test.a")==".a");
    BOOST_CHECK(GetFileExtension("test.a.b")==".b");
    BOOST_CHECK(GetFileExtension("test")=="");
  }
