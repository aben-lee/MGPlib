#ifndef MISCFUNC_H_INCLUDED
#define MISCFUNC_H_INCLUDED
#include "types.h"
#include <vector>
#include "FatalException.h"
#include "TsSpectrum.h"
#include <boost/numeric/ublas/vector.hpp>
#include <boost/shared_ptr.hpp>
#include <iostream>
#include <functional>

namespace gplib
  {
    /** \addtogroup genfunc General functions from various areas */
    /* @{ */
    namespace ublas = boost::numeric::ublas;
    //! Calculate the normalized envelope of the input vector
    void NormEnvelope(std::vector<double>::iterator Inputbegin, std::vector<
        double>::iterator Inputend, std::vector<double> &Output);
    //! Calculate the hilbert transform of the input vector
    void Hilbert(std::vector<double>::iterator Inputbegin,
        std::vector<double>::iterator Inputend, std::vector<double> &Output);
    //! Calculate the normalized cross-correlation between Master and Corr between the indices startpoint and endpoint
    double Cross(ttsdata Master, ttsdata Corr, const int startpoint,
        const int endpoint);

    //! Calculates Commutator of two complex numbers
    inline double Commute(dcomp A, dcomp B)
      {
        return (A.real() * B.imag() - B.real() * A.imag());

      }
    //! Compare par1 and par2 within specified tolerance
    inline int FuzzComp(double par1, double par2, double tolerance)
      {
        double lower;
        double higher;

        lower = par1 - tolerance;
        higher = par1 + tolerance;
        if ((lower <= par2) && (higher >= par2))
          return (1);
        else
          return (0);
        //return (((par1-tolerance) <= par2) && ((par1+tolerance) >= par2));
      }

    //! perform spectral multiplication on two vector style container and write the result to output
    /*! Do_Spec_Mul takes two input vectors, Master and Corr of the same length, writes either the convolution or correlation
     * into the vector output, depending on docorrel
     */
    template<typename ts_type>
    void Do_Spec_Mul(const ts_type &Master, const ts_type &Corr,
        ts_type &Output, const bool docorrel, TsSpectrum &SpecCalc)
      {
        if (Corr.size() != Master.size()) //if input sizes are different
          throw FatalException("In Correl: Master.size != Corr.size !"); //throw exception
        if (Output.size() != Master.size()) //if ouput vector doesn't have the right length
          Output.resize(Master.size()); //adjust

        tcompdata MasterSpec(Master.size() / 2 + 1), CorrSpec(Corr.size() / 2
            + 1); //some temporary objects
        SpecCalc.CalcSpectrum(Master.begin(), Master.end(), MasterSpec.begin(),
            MasterSpec.end()); // calc spectrum for master
        SpecCalc.CalcSpectrum(Corr.begin(), Corr.end(), CorrSpec.begin(),
            CorrSpec.end()); // and for corr
        tcompdata CrossPower;
        if (docorrel) //if we want to do a correlation
          {
            std::transform(MasterSpec.begin(), MasterSpec.end(),
                CorrSpec.begin(), back_inserter(CrossPower), //we have to multiply
                boost::bind<std::complex<double> >( //Master elements with the conjugate of Corr elements and write
                    std::multiplies<std::complex<double> >(), //into CrossPower
                    _1, boost::bind<std::complex<double> >(&std::conj<double>,
                        _2)));
          }
        else //if convolution
          {
            std::transform(MasterSpec.begin(), MasterSpec.end(),
                CorrSpec.begin(), back_inserter(CrossPower), std::multiplies<
                    std::complex<double> >()); //just multiply elements in Master with elements in Corr
          }
        SpecCalc.CalcTimeSeries(CrossPower.begin(), CrossPower.end(),
            Output.begin(), Output.end()); //Calculate the timeseries from CrossPower
      }

    template<typename ts_type>
    void Do_Spec_Mul(const ts_type &Master, const ts_type &Corr,
        ts_type &Output, const bool docorrel)
      {
        TsSpectrum SpecCalc(false);
        Do_Spec_Mul(Master, Corr, Output, docorrel, SpecCalc);
      }

    //! A convenience wrapper to calculate correlations
    template<typename ts_type>
    void Correl(const ts_type &Master, const ts_type &Corr, ts_type &Output)
      {
        Do_Spec_Mul(Master, Corr, Output, true);
      }

    template<typename ts_type>
    void Correl(const ts_type &Master, const ts_type &Corr, ts_type &Output,
        TsSpectrum &SpecCalc)
      {
        Do_Spec_Mul(Master, Corr, Output, true, SpecCalc);
      }

    //! A convenience wrapper to calculate convolution
    template<typename ts_type>
    void Convolve(const ts_type &Master, const ts_type &Corr, ts_type &Output)
      {
        Do_Spec_Mul(Master, Corr, Output, false);
      }

    //! A convenience wrapper to calculate convolution
    template<typename ts_type>
    void Convolve(const ts_type &Master, const ts_type &Corr, ts_type &Output,
        TsSpectrum &SpecCalc)
      {
        Do_Spec_Mul(Master, Corr, Output, false, SpecCalc);
      }
  /* @} */
  }
#endif

