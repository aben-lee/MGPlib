#ifndef ABSVELRECOBJECTIVE_H_
#define ABSVELRECOBJECTIVE_H_

#include "C1DRecObjective.h"
#include "RFVelCalc.h"
#include "SurfaceWaveData.h"

namespace gplib
  {
    //! This objective function calculates the weighted misfit for a receiver function and the corresponding absolute velocity transformation
    class AbsVelRecObjective: public C1DRecObjective
      {
    private:
      //! The object to perform absolute velocity estimation
      RFVelCalc CalcAbsVel;
      SurfaceWaveData MeasuredAbsVel;
      SurfaceWaveData SynthAbsVel;
      double absvelweight;
      double recweight;
    public:
      //! return a pointer to a copy of the current object
      virtual AbsVelRecObjective *clone() const
        {
          return new AbsVelRecObjective(*this);
        }
      //! Set the relative weight for the absolute velocity information
      void SetAbsVelWeight(const double w)
        {
          absvelweight = w;
        }
      //! Set the relative weight for the pure receiver function
      void SetRecWeight(const double w)
        {
          recweight = w;
        }
      //! Write out the receiver function and absolute velocity data, the absolute velocity data gets .vel appended
      virtual void WriteData(const std::string &filename)
        {
          if (recweight > 0.0)
            C1DRecObjective::WriteData(filename);
          if (absvelweight > 0.0)
            SynthAbsVel.WriteAscii(filename + ".vel");
        }
      virtual double PostParallel(const ttranscribed &member);
      AbsVelRecObjective& operator=(const AbsVelRecObjective& source);
      AbsVelRecObjective(const AbsVelRecObjective &Old);
      virtual ~AbsVelRecObjective();
      //! This constructor is used for calculating absolute velocity information
      /*! @param TheRecData  Object containing the measured receiver function as from call RFVelCalc
       * @param AbsVel Object containing the measured absolute velocity information
       * @param myshift    the shift used for calculating the measured receiver function
       *  @param mysigma sigma used for calculating the measured receiver function
       *  @param myc water level used for calculating the measured receiver function
       *  @param myslowness slowness used for calculating the measured receiver function
       * @param normalized Is the measured data normalized to an initial correlation peak of 1
       */
      AbsVelRecObjective(boost::shared_ptr<const SeismicDataComp> TheRecData,
          SurfaceWaveData &AbsVel, const int myshift, const double mysigma,
          const double myc, const double myslowness,
          const RecCalc::trfmethod method = RecCalc::specdiv,
          const bool normalized = true);
      };
  }
#endif /*ABSVELRECOBJECTIVE_H_*/
