#include "Aniso1DMTObjective.h"
#include "Member2Aniso.h"

namespace gplib
  {
    Aniso1DMTObjective::Aniso1DMTObjective(const MTStation &LocalMTData) :
      C1DMTObjective(LocalMTData)
      {
      }

    Aniso1DMTObjective& Aniso1DMTObjective::operator=(
        const Aniso1DMTObjective& source)
      {
        if (this == &source)
          return *this;
        C1DMTObjective::operator=(source);
        AnisoMTSynth = source.AnisoMTSynth;
        return *this;
      }

    Aniso1DMTObjective::Aniso1DMTObjective(const Aniso1DMTObjective &Old) :
      C1DMTObjective(Old), AnisoMTSynth(Old.AnisoMTSynth)
      {

      }

    Aniso1DMTObjective::~Aniso1DMTObjective()
      {
      }

    void Aniso1DMTObjective::CalcSynthData(const ttranscribed &member)
      {
        Member2Aniso(member, AnisoMTSynth); //setup forward model with parameter given in member
        AnisoMTSynth.GetData(); //do forward calculation
      }
  }
