#ifndef C1DMTOBJECTIVE_H
#define C1DMTOBJECTIVE_H

#include "PlottableObjective.h"
#include "MTStation.h"
#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
namespace gplib
  {
    //! C1DMTObjective is the base class for MT misfit calculations from 1D models, it provides common functionality to calculate the misfit of various MT parameters
    class C1DMTObjective: public PlottableObjective
      {
    public:
      // We have to declare some public typedefs that are needed below
      //! A function that returns a real valued quantity calculated from an MT impedance tensor
      typedef boost::function<double(const MTTensor* const )> datafunc_t;
      //! A vector of MT data functions. This is used to store the types of data to fit
      typedef std::vector<datafunc_t> datafuncvector_t;
    private:
      //! A vector of member functions to MTTensor that return the data to fit
      datafuncvector_t DataFunctions;
      //! A vector of member functions that return the errors associated with the functions in DataFunctions
      datafuncvector_t ErrorFunctions;
      //! A vector of doubles that cotains the errorlevels associated with the functions in DataFunctions
      std::vector<double> ErrorLevels;
      //! have the fit parameters been set or do we use default values
      bool FitparametersSet;
      //! A copy of the data to fit
      MTStation MTData;
      //! This abstract function has to calculate the Synthetic data and fill the MTSynth object with it
      virtual void CalcSynthData(const ttranscribed &member) = 0;
    protected:
      virtual MTStation &GetMTSynth() = 0;
    public:
      //! function to set the parameters that determine the type of fit
      void SetFitParameters(const datafuncvector_t TheDataV,
          const datafuncvector_t TheErrorV,
          const std::vector<double> TheErrLevel);
      void AppendFitParameters(const datafunc_t TheDataFunc,
          const datafunc_t TheErrorFunc, const double TheErrLevel);
      //! Calc misfit for a model given by member
      virtual void SafeParallel(const ttranscribed &member);
      virtual double PostParallel(const ttranscribed &member);
      //! return a vector with pointers to the functions used to calculate the errors
      const datafuncvector_t &GetErrorFunctions() const
        {
          return ErrorFunctions;
        }
      //! write the current model to a file
      virtual void WriteModel(const std::string &filename)=0;
      //! write the current model for plotting to a file
      virtual void WritePlot(const std::string &filename)=0;
      //! Write current data to a file
      virtual void WriteData(const std::string &filename)=0;
      //! We need data to fit for any objective function, so we want it as constructor parameter, but no implicit conversion
      C1DMTObjective(const MTStation &LocalMTData);
      C1DMTObjective(const C1DMTObjective &Old);
      virtual ~C1DMTObjective();
      C1DMTObjective& operator=(const C1DMTObjective& source);
      };
  }
#endif
