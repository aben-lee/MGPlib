#include "CombinedRoughness.h"
#include <iostream>

using namespace std;

namespace gplib
  {
    CombinedRoughness::CombinedRoughness() :
      refcond(2.0), refvel(2.0)
      {
      }

    CombinedRoughness::~CombinedRoughness()
      {
      }

    //! Calculate the roughness of the model given by the parameter member
    void CombinedRoughness::SafeParallel(const ttranscribed &member)
      {
        const unsigned int length = member.size() / 3; //we have 3 parameters in the model, so size/3 layers
        double roughness = 0; // init returnvalue
        const int fitexp = GetFitExponent();

        for (unsigned int i = 1; i < length; ++i) // for all layers except the top
          {
            roughness += pow((member(i) - member(i - 1)) / refcond,
                fitexp); // add the squared difference of the values divided by reference
            roughness += pow((member(i + 2 * length) - member(i - 1 + 2
                * length)) / refvel, fitexp);
          }
        SetRMS(roughness);
      }

    double CombinedRoughness::PostParallel(const ttranscribed &member)
      {
        return GetRMS();
      }

    //!  We have to copy the base class and the local data
    CombinedRoughness::CombinedRoughness(const CombinedRoughness &Old) :
      GeneralObjective(Old), refcond(Old.refcond), refvel(Old.refvel)
      {
      }

    //! We have to copy the base class and the local data
    CombinedRoughness& CombinedRoughness::operator=(
        const CombinedRoughness& source)
      {
        if (this == &source)
          return *this;
        GeneralObjective::operator=(source);
        refcond = source.refcond;
        refvel = source.refvel;
        return *this;
      }
  }
