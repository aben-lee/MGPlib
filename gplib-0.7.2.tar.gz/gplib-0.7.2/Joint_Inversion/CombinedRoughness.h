#ifndef _CCOMBINEDROUGHNESS_H_
#define _CCOMBINEDROUGHNESS_H_
#include "GeneralObjective.h"

namespace gplib
  {
    //! CombinedRoughness calculates the roughness of a joint MT- receiver functions model without consideration for different parameter ranges
    class CombinedRoughness: public GeneralObjective
      {
    private:
      double refcond;
      double refvel;
    public:
      //! Clone the object
      virtual CombinedRoughness *clone() const
        {
          return new CombinedRoughness(*this);
        }
      //! Set reference conductivity for roughness calculation, changes weighting between velocity and conductivity
      void SetRefCond(const double cond)
        {
          refcond = cond;
        }
      //! Set reference velcoity for roughness calculation, changes weighting between velocity and conductivity
      void SetRefVel(const double vel)
        {
          refvel = vel;
        }
      virtual void SafeParallel(const ttranscribed &member);
      virtual double PostParallel(const ttranscribed &member);
      CombinedRoughness(const CombinedRoughness &Old);
      CombinedRoughness& operator=(const CombinedRoughness& source);
      CombinedRoughness();
      virtual ~CombinedRoughness();
      };
  }
#endif /*_CCOMBINEDROUGHNESS_H_*/
