#include "Iso1DMTObjective.h"
#include "Adaptors.h"

namespace gplib
  {
    Iso1DMTObjective::Iso1DMTObjective(const MTStation &LocalMTData) :
      C1DMTObjective(LocalMTData)
      {
      }

    Iso1DMTObjective& Iso1DMTObjective::operator=(
        const Iso1DMTObjective& source)
      {
        if (this == &source)
          return *this;
        C1DMTObjective::operator=(source);
        IsoMTSynth = source.IsoMTSynth;
        return *this;
      }

    Iso1DMTObjective::Iso1DMTObjective(const Iso1DMTObjective &Old) :
      C1DMTObjective(Old), IsoMTSynth(Old.IsoMTSynth)
      {

      }

    Iso1DMTObjective::~Iso1DMTObjective()
      {
      }

    void Iso1DMTObjective::CalcSynthData(const ttranscribed &member)
      {
        const int nlayers = member.size() / 2; //the model has the format resistivity/thickness
        // so the actual numer of layers is half the length
        trealdata res(nlayers, 0);
        trealdata thick(nlayers, 0);
        transform(member.begin(), member.begin() + nlayers, res.begin(),
            boost::bind(gplib::fopow<double, double>(), 10., _1)); //member contains log resistivity
        // transform to normal resistivity
        copy(member.begin() + nlayers, member.end(), thick.begin()); //copy thickness values
        IsoMTSynth.SetThicknesses(thick); //set them in the MTSynth object for forward calculation
        IsoMTSynth.SetResistivities(res);
        IsoMTSynth.CalcSynthetic(); // do forward calculation
      }
  }
