#ifndef ISO1DMTOBJECTIVE_H_
#define ISO1DMTOBJECTIVE_H_
#include "C1DMTObjective.h"
#include "C1DMTSynthData.h"

namespace gplib
  {
    //! This class implements the forward calculation for a 1D isotropic MT model
    /*! Here we implement the specific calls to generate data for a 1D isotropic
     * model, the misfit and the type of data to fit are all set and calculated
     * in the base class C1DMTObjective
     */
    class Iso1DMTObjective: public C1DMTObjective
      {
    private:
      //! This is the only function that implements some real functionality
      /*! This function implements the forward calculation of the data,
       * the base class uses the access function GetMTSynth to access this data
       * for misfit calculations etc.
       */
      virtual void CalcSynthData(const ttranscribed &member);
      C1DMTSynthData IsoMTSynth;
      virtual MTStation &GetMTSynth()
        {
          return IsoMTSynth;
        }
    public:
      explicit Iso1DMTObjective(const MTStation &LocalMTData);
      Iso1DMTObjective& operator=(const Iso1DMTObjective& source);
      Iso1DMTObjective(const Iso1DMTObjective &Old);
      virtual ~Iso1DMTObjective();
      //! clone clones the current object, derived from GeneralObjective
      virtual Iso1DMTObjective *clone() const
        {
          return new Iso1DMTObjective(*this);
        }
      //! write the current model to a file
      virtual void WriteModel(const std::string &filename)
        {
          IsoMTSynth.WriteModel(filename);
        }
      //! write the current model for plotting to a file
      virtual void WritePlot(const std::string &filename)
        {
          IsoMTSynth.WritePlot(filename);
        }
      //! Write current data to a file
      virtual void WriteData(const std::string &filename)
        {
          IsoMTSynth.WriteAsMtt(filename);
        }
      };
  }
#endif /*ISO1DMTOBJECTIVE_H_*/
