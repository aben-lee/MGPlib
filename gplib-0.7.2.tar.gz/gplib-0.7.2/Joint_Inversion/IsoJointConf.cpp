//============================================================================
// Name        : IsoJointConf.cpp
// Author      : Apr 8, 2010
// Version     : 
// Copyright   : 2010, mmoorkamp
//============================================================================


#include "IsoJointConf.h"
#include "convert.h"
#include "VecMat.h"
#include "VectorOptions.h"
#include <boost/program_options.hpp>
#include <cmath>
#include <boost/tokenizer.hpp>

namespace gplib
  {

    using namespace boost::program_options;

    IsoJointConf::IsoJointConf()
      {

      }

    IsoJointConf::~IsoJointConf()
      {
      }

    void IsoJointConf::GetData(std::ifstream &instream)
      {
        DummyVec<double> Test;

        options_description desc("Joint inversion options");
        desc.add_options()("outputbase", value<std::string> (&outputbase),
            "The start of the name of the output files")("verbose", value(
            &verbose)->default_value(false), "")("poisson", value<double> (
            &poisson), "Poisson's ration")
            ("threads", value<int> (
                        &threads), "Number of openmp threads")
            ("usevrefmodel",
            value(&usevrefmodel)->default_value(false), "")("vrefmodel", value(
            &vrefmodel), "")("thickbase", value<DummyVec<double> > (), "")(
            "thickstep", value<DummyVec<double> > (), "")("thicksizes", value<
            DummyVec<int> > (), "")("resbase", value<DummyVec<double> > (), "")(
            "resstep", value<DummyVec<double> > (), "")("ressizes", value<
            DummyVec<int> > (), "")("svelbase", value<DummyVec<double> > (), "")(
            "svelstep", value<DummyVec<double> > (), "")("svelsizes", value<
            DummyVec<int> > (), "")("weights", value<DummyVec<double> > (), "");

        variables_map vm;
        store(parse_config_file(instream, desc, true), vm);
        notify(vm);

        if (vm.count("thickbase"))
          {
            thickbase = vm["thickbase"].as<DummyVec<double> > ().VecVal;
          }
        if (vm.count("thickstep"))
          {
            thickstep = vm["thickstep"].as<DummyVec<double> > ().VecVal;
          }
        if (vm.count("thicksizes"))
          {
            thicksizes = vm["thicksizes"].as<DummyVec<int> > ().VecVal;
          }

        if (vm.count("resbase"))
          {
            resbase = vm["resbase"].as<DummyVec<double> > ().VecVal;
          }
        if (vm.count("resstep"))
          {
            resstep = vm["resstep"].as<DummyVec<double> > ().VecVal;
          }
        if (vm.count("ressizes"))
          {
            ressizes = vm["ressizes"].as<DummyVec<int> > ().VecVal;
          }

        if (vm.count("svelbase"))
          {
            svelbase = vm["svelbase"].as<DummyVec<double> > ().VecVal;
          }
        if (vm.count("svelstep"))
          {
            svelstep = vm["svelstep"].as<DummyVec<double> > ().VecVal;
          }
        if (vm.count("svelsizes"))
          {
            svelsizes = vm["svelsizes"].as<DummyVec<int> > ().VecVal;
          }

        if (vm.count("weights"))
          {
            weights = vm["weights"].as<DummyVec<double> > ().VecVal;
          }
      }
  }
