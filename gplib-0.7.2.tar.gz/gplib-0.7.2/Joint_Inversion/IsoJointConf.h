//============================================================================
// Name        : IsoJointConf.h
// Author      : Apr 8, 2010
// Version     : 
// Copyright   : 2010, mmoorkamp
//============================================================================


#ifndef ISOJOINTCONF_H_
#define ISOJOINTCONF_H_

#include <string>
#include <fstream>
#include <vector>

namespace gplib
  {

    class IsoJointConf
      {
    public:
      bool verbose;
      int threads;
      std::string outputbase;
      double poisson;
      bool usevrefmodel;
      std::string vrefmodel;
      std::vector<double> thickbase;
      std::vector<double> thickstep;
      std::vector<int> thicksizes;
      std::vector<double> resbase;
      std::vector<double> resstep;
      std::vector<int> ressizes;
      std::vector<double> svelbase;
      std::vector<double> svelstep;
      std::vector<int> svelsizes;
      std::vector<double> weights;
      void GetData(std::ifstream &instream);
      IsoJointConf();
      virtual ~IsoJointConf();
      };

  }

#endif /* ISOJOINTCONF_H_ */
