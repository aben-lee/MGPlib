#include "MTAnisoRoughness.h"
#include <cmath>

namespace gplib
  {
    MTAnisoRoughness::MTAnisoRoughness() :
      conddiffweight(), anisotropyweight(), strikediffweight()
      {
      }

    MTAnisoRoughness::~MTAnisoRoughness()
      {
      }

    void MTAnisoRoughness::SafeParallel(const ttranscribed &member)
      {
        const unsigned int length = member.size() / 4; //we have 4 parameters in the model, so size/4 layers
        double roughness = std::abs(member(2 * length)); // the loop starts at 1, so we skip this value in the 2nd summation
        const int fitexp = GetFitExponent();
        const double anglescale = 90.; //value if phi varies from 0 to 180
        for (unsigned int i = 1; i < length; ++i) // for all layers except the top
          {
            roughness += conddiffweight * std::pow((member(i) - member(i - 1)),
                fitexp); //minimize difference in conductivity between layers
            roughness += anisotropyweight * std::pow(std::abs(member(i + 2
                * length)), fitexp); //minimize anisotropy factor in each layer
            roughness += strikediffweight * std::pow((member(i + 3 * length))
                / anglescale, fitexp); //minimize strike within each layer
          }
        SetRMS(std::pow(roughness, 1. / fitexp));
      }

    double MTAnisoRoughness::PostParallel(const ttranscribed &member)
      {
        return GetRMS();
      }

    MTAnisoRoughness::MTAnisoRoughness(const MTAnisoRoughness &Old):
      GeneralObjective(Old), conddiffweight(Old.conddiffweight),
          anisotropyweight(Old.anisotropyweight), strikediffweight(
              Old.strikediffweight)
      {
      }

    MTAnisoRoughness& MTAnisoRoughness::operator=(
        const MTAnisoRoughness& source)
      {
        if (this == &source)
          return *this;
        GeneralObjective::operator=(source);
        conddiffweight = source.conddiffweight;
        anisotropyweight = source.anisotropyweight;
        strikediffweight = source.strikediffweight;
        return *this;
      }
  }
