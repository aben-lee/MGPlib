#ifndef MANISOTROUGHNESS_H_
#define MANISOTROUGHNESS_H_
#include "GeneralObjective.h"
namespace gplib
  {
    //! Caclulate the roughness for anisotropic MT models
    class MTAnisoRoughness: public GeneralObjective
      {
    private:
      double conddiffweight;
      double anisotropyweight;
      double strikediffweight;
    public:
//! Get read-only access to the vector of anisotropy coefficients for each layer
      void SetCondDiffWeight(const double w)
        {
          conddiffweight = w;
        }
      void SetAnisotropyWeight(const double w)
       {
         anisotropyweight = w;
        }
      void SetStrikeDiffWeight(const double w)
        {
          strikediffweight = w;
        }
      virtual MTAnisoRoughness *clone() const
        {
          return new MTAnisoRoughness(*this);
        }
      virtual void SafeParallel(const ttranscribed &member);
      virtual double PostParallel(const ttranscribed &member);
      MTAnisoRoughness(const MTAnisoRoughness &Old);
      MTAnisoRoughness& operator=(const MTAnisoRoughness& source);
      MTAnisoRoughness();
      virtual ~MTAnisoRoughness();
      };
  }
#endif /*MTANISOROUGHNESS_H_*/
