//============================================================================
// Name        : MTInvConf.h
// Author      : Apr 8, 2010
// Version     : 
// Copyright   : 2010, mmoorkamp
//============================================================================


#ifndef MTINVCONF_H_
#define MTINVCONF_H_

#include <string>
#include <fstream>

namespace gplib
  {

    class MTInvConf
      {
    public:
      int mtfitexponent;
      double tensorerror;
      double reserror;
      double phaseerror;
      double surferror;
      std::string mode;
      std::string mtfit;
      std::string mtinputdata;
      void GetData(std::ifstream &instream);
      MTInvConf();
      virtual ~MTInvConf();
      };

  }

#endif /* MTINVCONF_H_ */
