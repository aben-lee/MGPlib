#ifndef MTROUGHNESS_H_
#define MTROUGHNESS_H_
#include "GeneralObjective.h"
namespace gplib
  {
//! Calculate the roughness for the MT part of a joint MT-seismic model as used by 1dinvga
class MTRoughness: public GeneralObjective
{
public:
	virtual MTRoughness *clone() const {return new MTRoughness(*this);}
	virtual void SafeParallel(const ttranscribed &member);
	virtual double PostParallel(const ttranscribed &member);
	MTRoughness(const MTRoughness &Old);
	MTRoughness& operator=(const MTRoughness& source);
	MTRoughness();
	virtual ~MTRoughness();
};
  }
#endif /*MTROUGHNESS_H_*/
