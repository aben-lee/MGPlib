#include "Multi1DRecObjective.h"
#include <cassert>
#include <algorithm>
#include <numeric>
#include "FatalException.h"
#include "convert.h"
#include <iostream>
#include <boost/make_shared.hpp>
using namespace std;

namespace gplib
  {
    void Multi1DRecObjective::SetTimeWindow(const double start, const double end)
      {
        for_each(Objectives.begin(), Objectives.end(),
            [start,end](boost::shared_ptr<C1DRecObjective> CurrOb)
              { CurrOb->SetTimeWindow(start,end);});
      }

    void Multi1DRecObjective::SetPoisson(const double ratio)
      {
        for_each(Objectives.begin(), Objectives.end(),
            [ratio](boost::shared_ptr<C1DRecObjective> CurrOb)
              { CurrOb->SetPoisson(ratio);});
      }

    void Multi1DRecObjective::AddRecFunction(
        boost::shared_ptr<const SeismicDataComp> TheRecData, int myshift, double mysigma,
        double myc, double myslowness, RecCalc::trfmethod method, double errorlevel,
        bool normalized, ResPkModel::WaveType InWave)
      {
        auto Obj = boost::make_shared < gplib::C1DRecObjective
            > (TheRecData, myshift, mysigma, myc, myslowness, method, normalized, InWave);
        Obj->SetErrorLevel(errorlevel);
        Objectives.push_back(Obj);

      }

    void Multi1DRecObjective::AddAbsVelFunction(
        boost::shared_ptr<const SeismicDataComp> TheRecData, SurfaceWaveData &AbsVel,
        const int myshift, const double mysigma, const double myc,
        const double myslowness, const RecCalc::trfmethod method, const double errorlevel,
        const bool normalized, const double absvelweight, const double recweight)
      {
        boost::shared_ptr<AbsVelRecObjective> Obj(
            new AbsVelRecObjective(TheRecData, AbsVel, myshift, mysigma, myc, myslowness,
                method, normalized));
        Obj->SetErrorLevel(errorlevel);
        Obj->SetAbsVelWeight(absvelweight);
        Obj->SetRecWeight(recweight);
        Objectives.push_back(Obj);
      }

    void Multi1DRecObjective::PreParallel(const ttranscribed &member)
      {
        if (Objectives.empty())
          throw FatalException("In Multi1DRecObjective: No Objective functions set !");
        const size_t nobjs = Objectives.size();
        for (size_t i = 0; i < nobjs; ++i)
          {
            //the name has to end in a known letter, otherwise the delete
            //routine for the receiver function calculation will remove more
            //files than intended
            Objectives.at(i)->SetParallelID(GetParallelID() + "r" + stringify(i) + "r");
            Objectives.at(i)->PreParallel(member);

          }
      }
    double Multi1DRecObjective::PostParallel(const ttranscribed &member)
      {

        std::vector<double> values;
        const size_t nobjs = Objectives.size();
        transform(Objectives.begin(), Objectives.end(), back_inserter(values),
            [&member](boost::shared_ptr<C1DRecObjective> CurrOb) -> double
              { return CurrOb->PostParallel(member);});
        double sumsquares = inner_product(values.begin(), values.end(), values.begin(),
            0.0);
        //copy(values.begin(),values.end(),ostream_iterator<double>(cout," "));
        //cout << " " << sqrt(sumsquares/values.size()) << endl;
        return sqrt(sumsquares / values.size());
      }
    void Multi1DRecObjective::SafeParallel(const ttranscribed &member)
      {
        const size_t nobjs = Objectives.size();
        for_each(Objectives.begin(), Objectives.end(),
            [&member](boost::shared_ptr<C1DRecObjective> CurrOb)
              { CurrOb->SafeParallel(member);});
      }

    void Multi1DRecObjective::WriteData(const std::string &filename)
      {
        const size_t nobjs = Objectives.size();
        for (size_t i = 0; i < nobjs; ++i)
          {
            Objectives.at(i)->WriteData(filename + stringify(i));

          }
        //for_each(Objectives.begin(), Objectives.end(), boost::bind(
        //       &C1DRecObjective::WriteData, _1, filename));
      }

    void Multi1DRecObjective::WriteModel(const std::string &filename)
      {
        Objectives.front()->WriteModel(filename); //all models are the same, so we only write the first
      }

    void Multi1DRecObjective::WritePlot(const std::string &filename)
      {
        Objectives.front()->WritePlot(filename); //all models are the same, so we only plot the first
      }

    Multi1DRecObjective::Multi1DRecObjective()
      {
      }

    Multi1DRecObjective::~Multi1DRecObjective()
      {
      }

    Multi1DRecObjective::Multi1DRecObjective(const Multi1DRecObjective &Old)
      {
        const size_t nobjs = Old.Objectives.size();
        Objectives.clear();
        for (size_t i = 0; i < nobjs; ++i)
          {
            boost::shared_ptr<C1DRecObjective> Obj(Old.Objectives.at(i)->clone());
            Objectives.push_back(Obj);
          }
      }

    Multi1DRecObjective& Multi1DRecObjective::operator=(const Multi1DRecObjective& source)
      {
        if (this == &source)
          return *this;
        const size_t nobjs = source.Objectives.size();
        Objectives.clear();
        for (size_t i = 0; i < nobjs; ++i)
          {
            boost::shared_ptr<C1DRecObjective> Obj(source.Objectives.at(i)->clone());
            Objectives.push_back(Obj);
          }
        return *this;
      }
  }
