#ifndef MULTI1DRECOBJECTIVE_H_
#define MULTI1DRECOBJECTIVE_H_

#include "PlottableObjective.h"
#include <vector>
#include "C1DRecObjective.h"
#include "AbsVelRecObjective.h"
#include <boost/shared_ptr.hpp>

namespace gplib
  {
    //! This class is used to model several receiver functions simultaneously
    class Multi1DRecObjective: public PlottableObjective
      {
    private:
      std::vector<boost::shared_ptr<C1DRecObjective> > Objectives;
    public:
      //! return a pointer to a copy of the current object
      virtual Multi1DRecObjective *clone() const
        {
          return new Multi1DRecObjective(*this);
        }
      //! Set the start and end time in s for the part we want to fit
      void SetTimeWindow(const double start, const double end);
      //! Set Poisson's ratio to calculate P velocities from S-Velocities
      void SetPoisson(const double ratio);
      //! Add another reciever function to fit
      void AddRecFunction(boost::shared_ptr<const SeismicDataComp> TheRecData,
          int myshift, double mysigma, double myc,
          double myslowness, RecCalc::trfmethod method,
          double errorlevel, bool normalized, ResPkModel::WaveType InWave);
      //! Add another receiver function with absolute velocity transformation
      void AddAbsVelFunction(
          boost::shared_ptr<const SeismicDataComp> TheRecData,
          SurfaceWaveData &AbsVel, const int myshift, const double mysigma,
          const double myc, const double myslowness,
          const RecCalc::trfmethod method, const double errorlevel,
          const bool normalized, const double absvelweight,
          const double recweight);
      //! The operations that have to be done before the parallel part
      virtual void PreParallel(const ttranscribed &member);
      //! The operations that have to be done after the parallel part
      virtual double PostParallel(const ttranscribed &member);
      //! The operations that safely can be done in parallel
      virtual void SafeParallel(const ttranscribed &member);
      //! Write out all the data, endings will be appended automatically
      virtual void WriteData(const std::string &filename);
      //! Write the current model to ascii file for calculations
      void WriteModel(const std::string &filename);
      //! Write the current model to ascii file for plotting
      void WritePlot(const std::string &filename);
      Multi1DRecObjective(const Multi1DRecObjective &Old);
      Multi1DRecObjective& operator=(const Multi1DRecObjective& source);
      Multi1DRecObjective();
      virtual ~Multi1DRecObjective();
      };
  }
#endif /*MULTI1DRECOBJECTIVE_H_*/
