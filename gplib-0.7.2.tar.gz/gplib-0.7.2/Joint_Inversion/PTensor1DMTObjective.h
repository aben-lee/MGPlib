#ifndef PTENSOR1DMTOBJECTIVE_H_
#define PTENSOR1DMTOBJECTIVE_H_

#include "C1DAnisoMTSynthData.h"
#include "PTensorMTStation.h"
#include "PlottableObjective.h"

namespace gplib
  {
    //! This is a special objective function to fit phase tensor MT data
    /*! We don't have analytical expression for the error of phase tensor elements yet/
     * Recalculating them all the time with Jacknife or bootstrap methods is too expensive
     * so we calculate them once for the measured data, store it in a special file
     * and use this objective function to read the file and fit this data.
     */
    class PTensor1DMTObjective: public PlottableObjective
      {
    private:
      double errorlevel;
      PTensorMTStation MeasuredData;
      C1DAnisoMTSynthData AnisoMTSynth;
    public:
      //! Set the minimum relative error
      void SetErrorLevel(const double e)
        {
          errorlevel = e;
        }
      //! Calc misfit for a model given by member
      virtual void SafeParallel(const ttranscribed &member);
      virtual double PostParallel(const ttranscribed &member);
      //! write the current model to a file
      virtual void WriteModel(const std::string &filename)
        {
          AnisoMTSynth.WriteModel(filename);
        }
      //! write the current model for plotting to a file
      virtual void WritePlot(const std::string &filename)
        {
          AnisoMTSynth.WritePlot(filename);
        }
      //! Write current data to a file
      virtual void WriteData(const std::string &filename)
        {
          AnisoMTSynth.WriteAsMtt(filename);
        }
      virtual PTensor1DMTObjective *clone() const
        {
          return new PTensor1DMTObjective(*this);
        }
      PTensor1DMTObjective(const PTensorMTStation &LocalMTData);
      PTensor1DMTObjective(const PTensor1DMTObjective &Old);
      virtual ~PTensor1DMTObjective();
      PTensor1DMTObjective& operator=(const PTensor1DMTObjective& source);
      };
  }
#endif /*PTENSOR1DMTOBJECTIVE_H_*/
