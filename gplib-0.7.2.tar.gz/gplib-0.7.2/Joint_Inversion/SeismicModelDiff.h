#ifndef _SEISMICMODELDIFF_H_
#define _SEISMICMODELDIFF_H_
#include "GeneralObjective.h"
#include "ResPkModel.h"

namespace gplib
  {
    //! SeismicModelDiff calculates the roughness of a joint MT- receiver functions model compared to a seismic model
    class SeismicModelDiff: public GeneralObjective
      {
    private:
      ResPkModel Model;
    public:
      //! Clone the object
      virtual SeismicModelDiff *clone() const
        {
          return new SeismicModelDiff(*this);
        }
      virtual void SafeParallel(const ttranscribed &member);
      virtual double PostParallel(const ttranscribed &member);
      explicit SeismicModelDiff(const ResPkModel &Seis);
      SeismicModelDiff(const SeismicModelDiff &Old);
      SeismicModelDiff& operator=(const SeismicModelDiff& source);
      virtual ~SeismicModelDiff();
      };
  }
#endif /*_SEISMICMODELDIFF_H_*/
