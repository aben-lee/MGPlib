//============================================================================
// Name        : SurfInvConf.h
// Author      : Apr 8, 2010
// Version     : 
// Copyright   : 2010, mmoorkamp
//============================================================================


#ifndef SURFINVCONF_H_
#define SURFINVCONF_H_


#include <string>
#include <fstream>

namespace gplib
  {

    class SurfInvConf
      {
    public:
      std::string dispdata;
      int surffitexponent;
      double surferror;
      void GetData(std::ifstream &instream);
      SurfInvConf();
      virtual ~SurfInvConf();
      };

  }

#endif /* SURFINVCONF_H_ */
