#ifndef C1DANISOMTSYNTHDATA_H_
#define C1DANISOMTSYNTHDATA_H_

#include "MTStation.h"
#include "VecMat.h"

namespace gplib
  {
    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */
    //! Calculate response of a 1D anisotropic model, code is based on Pek and Santos fortran code
    class C1DAnisoMTSynthData: public MTStation
      {
    private:
      trealdata calc_frequencies;
      trealdata thicknesses; // Thickness for each layer
      trealdata strikes;
      trealdata slants;
      trealdata dips;
      trealdata rho1;
      trealdata rho2;
      trealdata rho3;
      trealdata effcond1;
      trealdata effcond2;
      trealdata effstrike;
      //! Transform angles and resistivities into effective horizontal values, has to be called before CalcZ
      void TransformRho();
      //! Calculate the response
      void CalcZ();
    public:
      //! Set the anisotropy strike for each layer in degree
      void SetStrikes(const trealdata &a)
        {
          strikes = a;
        }
      //! Set the anisotropy slant for each layer in degree
      void SetSlants(const trealdata &a)
        {
          slants = a;
        }
      //! Set the anisotropy dip for each layer in degree
      void SetDips(const trealdata &a)
        {
          dips = a;
        }
      //! Set the first principal resistivity for each layer in Ohm.m
      void SetRho1(const trealdata &a)
        {
          rho1 = a;
        }
      //! Set the second principal resistivity for each layer in Ohm.m
      void SetRho2(const trealdata &a)
        {
          rho2 = a;
        }
      //! Set the first principal resistivity for each layer in Ohm.m
      void SetRho3(const trealdata &a)
        {
          rho3 = a;
        }
      //! Set the thicknes in km
      void SetThicknesses(const trealdata &thick)
        {
          thicknesses = thick;
        }
      const trealdata &GetThicknesses()
        {
          return thicknesses;
        }
      using MTStation::GetData;
      //! Calculate the synthetic data given the previously set parameters
      virtual void GetData();
      //! write model into file
      gplib::rvec GetModelVector();
      void WriteModel(std::string filename);
      void ReadModel(std::string filename);
      void WritePlot(std::string filename);
      virtual C1DAnisoMTSynthData *clone() const
        {
          return new C1DAnisoMTSynthData(*this);
        }
      C1DAnisoMTSynthData(const C1DAnisoMTSynthData &old);
      C1DAnisoMTSynthData();
      virtual ~C1DAnisoMTSynthData();
      };
  /* @} */
  }
#endif /*C1DANISOMTSYNTHDATA_H_*/
