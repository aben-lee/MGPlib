#ifndef C1DMTSYNTHDATA_H
#define C1DMTSYNTHDATA_H

#include "MTStation.h"
#include "types.h"
#include <vector>
#include <string>
#include "VecMat.h"

namespace gplib
  {
  /** \addtogroup mttools MT data analysis, processing and inversion */
  /* @{ */
//! Calculate synthetic MT data for a 1D model using Cagniard's algorithm
    class C1DMTSynthData: public MTStation
      {
    private:
      tcompdata Z;
      void Calc();
      trealdata calc_frequencies;
      trealdata resistivity; //
      trealdata thickness; // Thickness for each layer
      trealdata reserrors; // the errors of the model parameters, only used for plotting
      trealdata thickerrors;
    public:
      //! Read only access to the vector of resistivities for the 1D model from top to bottom in Ohmm
      const trealdata &GetResistivities()
        {
          return resistivity;
        }
      //! Read only access to the vector of layer thicknesses for the 1D model from top to bottom in km
      const trealdata &GetThicknesses()
        {
          return thickness;
        }
      //! Read-write access to the vector of resistivities for the 1D model from top to bottom in Ohmm
      void SetResistivities(const trealdata &res)
        {
          resistivity = res;
        }
      //! Read only access to the vector of layer thicknesses for the 1D model from top to bottom in km
      void SetThicknesses(const trealdata &thick)
        {
          thickness = thick;
        }
      //! Set the error on the resistivities this is purely for plotting of inversion results
      void SetResistivityErrors(const trealdata &re)
        {
          reserrors = re;
        }
      //! Set the error on the thicknesses this is purely for plotting of inversion results
      void SetThicknessErrors(const trealdata &te)
        {
          thickerrors = te;
        }
      //! Return the model as a single vector first log10 of all resistivities, then all thicknesses in km
      gplib::rvec GetModelVector();
      //! Write model into file for cagniard algorithm
      void WriteModel(std::string filename);
      //! Read the model from a file
      void ReadModel(std::string filename);
      //! Write out a file that can be used for plotting with xmgrace first column depth, second column resistivity
      void WritePlot(std::string filename);
      //! Calculate the synthetic data given the previously set parameters
      virtual void CalcSynthetic();
      //! Provide a "virtual copy constructor"
      virtual C1DMTSynthData *clone() const
        {
          return new C1DMTSynthData(*this);
        }
      C1DMTSynthData(const C1DMTSynthData &old);
      C1DMTSynthData();
      virtual ~C1DMTSynthData();
      };
    /* @} */
  }
#endif
