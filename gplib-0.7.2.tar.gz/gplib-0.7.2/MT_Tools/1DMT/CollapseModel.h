#ifndef COLLAPSEMODEL_H_
#define COLLAPSEMODEL_H_
#include "gentypes.h"

namespace gplib
  {
    //! Remove layers with identical parameters from the model and collapse them into a single layer each
    void CollapseModel(ttranscribed &Thickness, ttranscribed &ParmValue);
  }
#endif /*COLLAPSEMODEL_H_*/
