#ifndef INC_JParserTokenTypes_hpp_
#define INC_JParserTokenTypes_hpp_

/* $ANTLR 2.7.7 (20160104): "JParser.g" -> "JParserTokenTypes.hpp"$ */

#ifndef CUSTOM_API
# define CUSTOM_API
#endif

#ifdef __cplusplus
struct CUSTOM_API JParserTokenTypes {
#endif
	enum {
		EOF_ = 1,
		ENTRY = 4,
		NEWLINE = 5,
		COMMENT = 6,
		AZIMUTH = 7,
		LATITUDE = 8,
		LONGITUDE = 9,
		ELEVATION = 10,
		STATION = 11,
		MISDAT = 12,
		EQUAL = 13,
		ZXX = 14,
		ZXY = 15,
		ZYX = 16,
		ZYY = 17,
		RXX = 18,
		RXY = 19,
		RYX = 20,
		RYY = 21,
		TZX = 22,
		TZY = 23,
		SI = 24,
		FIELD = 25,
		UNITS = 26,
		UNDEF = 27,
		PLUS = 28,
		MINUS = 29,
		WS = 30,
		DIGIT = 31,
		CHAR = 32,
		OTHER = 33,
		NULL_TREE_LOOKAHEAD = 3
	};
#ifdef __cplusplus
};
#endif
#endif /*INC_JParserTokenTypes_hpp_*/
