#ifndef CMTSTATION_H
#define CMTSTATION_H

#include "MTTensor.h"
#include "MagneticTF.h"
#include "types.h"
#include <string>
#include <map>
#include <boost/function.hpp>

namespace gplib
  {
    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    //! The class MTStation is used to store the transfer functions and related information for a MT-site
    class MTStation
      {
    public:
      enum tmtdataformat
        {
        unknown, mtt, j, edi, pek, nc, zmm, mtf
        };
    private:
      //! Station Latitude
      double latitude;
      //! Station Lonigude
      double longitude;
      //! Station elevation
      double elevation;
      //! Name, does not have to be filename for j and edi data
      std::string name;
      //! Azimuth from magnetic north if station was rotated
      double azimuth;
      // The MTTensor data for each frequency
      std::vector<MTTensor> MTData;
      // The Local induction vectors for each frequency
      std::vector<MagneticTF> TFData;
      void DoRotate(const int i, const double angle);
      //! Perform some initial Setup
      void InitialSetup();
      //! the format the data was stored in the original file
      tmtdataformat dataformat;
      //! Write data to file in goettingen .mtt format
      void WriteMtt(const std::string filename);
      //! Read data from edi file (not all features supported)
      void ReadEdi(const std::string filename);
      //! Read data from j file
      void ReadJ(const std::string filename);
      //! Read data from goettingen .mtt file
      void ReadMtt(const std::string filename);
      //! Read output of Pek's 1D anisotropy code
      void ReadPek1D(const std::string filename);
      //! Read output of Egbert's code, so far only supports files that contain only impedances and no tipper
      void ReadZmm(const std::string filename);
      //! Read mtf format for impedances by M. Smirnov
      void ReadMtf(const std::string filename);
#ifdef HAVENETCDF
      void ReadNetCDF(const std::string filename);
#endif
      // helper function for WriteAsJ
      void WriteJBlock(boost::function<std::complex<double>(const MTTensor*)> Comp,
          boost::function<double(const MTTensor*)> Err, std::ofstream &outfile,
          const double convfactor);
    protected:
      //! Update all derived quantities
      void Update();
      //! Assign() assigns zero to all derived quantities, this makes the calculation
      // more easy
      void Assign(const int nfreq);
    public:
      // Assign zero to everything, convenient for synthetic data that is not read in from file
      void AssignAll(const int nfreq);
      //! Given a rotation angle in radian this method rotates the impedance tensor
      //! and updates all derived quantities
      void Rotate(const double rotangle);
      //! Rotate to zero rotation angle
      void Rotate(void);
      //! return the available frequencies in a single vector
      trealdata GetFrequencies() const;
      //! Set the frequencies of the tensor elements, invalidates the previously stored impedance data, mainly for creating synthetic data
      void SetFrequencies(const trealdata &freqs);
      //! access funtion for Latitude
      double GetLatitude() const
        {
          return latitude;
        }
      void SetLatitude(double lat)
        {
          latitude = lat;
        }
      double GetLongitude() const
        {
          return longitude;
        }
      void SetLongitude(double lon)
        {
          longitude = lon;
        }
      double GetElevation() const
        {
          return elevation;
        }
      std::string GetName()
        {
          return name;
        }
      double GetAzimuth() const
        {
          return azimuth;
        }
      ;
      //! direct acces to a tensor at a given index
      const MTTensor &at(const unsigned int i) const
        {
          return MTData.at(i);
        }
      //! Get the full vector of Tensor elements read only
      const std::vector<MTTensor> &GetMTData() const
        {
          return MTData;
        }
      //! Get the full vector of Tensor elements for reading and writing
      std::vector<MTTensor> &SetMTData()
        {
          return MTData;
        }
      const std::vector<MagneticTF> &GetTipper() const
        {
          return TFData;
        }
      //! for parallel runs we need to make a copy of the object and its derived classes
      virtual MTStation *clone() const
        {
          return new MTStation(*this);
        }
      MTStation& operator=(const MTStation& source);
      MTStation();
      MTStation(const MTStation &old);
      MTStation(const int size);
      MTStation(const std::string filename);
      virtual ~MTStation();
      //! read in data from file, determines format by ending
      virtual void GetData(const std::string filename);
      virtual void GetData()
        {
        }
      //Write data to file, same as WriteBack
      virtual void WriteData(const std::string filename);
      friend class C1DMTSynthData;
      //! Write data in goettingen .mtt format
      void WriteAsMtt(const std::string filename);
      //! Write data as edi (no functionality yet)
      void WriteAsEdi(const std::string filename);
      //! Write data to j-file
      void WriteAsJ(const std::string filename);
      //! Write data back in original format, with filename given by station name
      void WriteBack();
      };

    const std::map<std::string, MTStation::tmtdataformat> MTFileTypes =
      {
        { ".mtt", MTStation::tmtdataformat::mtt },
        { ".j", MTStation::tmtdataformat::j },
        { ".dat", MTStation::tmtdataformat::j },
        { ".nc", MTStation::tmtdataformat::nc },
        { ".zmm", MTStation::tmtdataformat::zmm },
        { ".mtf", MTStation::tmtdataformat::mtf },
        { ".edi", MTStation::tmtdataformat::edi },
        { ".pek", MTStation::tmtdataformat::pek } };
  /* @} */
  }
#endif // CMTSTATION_H
