#ifndef CMTSTATIONLIST_H
#define CMTSTATIONLIST_H

#include <string>
#include "MTStation.h"
#include <vector>
#include <utility>

namespace gplib
  {
    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    typedef std::vector<MTStation> tStationList;
    //! MTStationList holds a number of MTSites, usually associated with a single project, line, etc.
    class MTStationList
      {
    private:
      //! The relative tolerance at which we accept two frequencies as being euqal
      double tolerance;
      //! A vector that holds the frequencies common to all sites
      trealdata commonfrequencies;
      //! A vector that holds the storage index for each of the commonfrequencies for each site
      std::vector<tindexvector> cfindices;
      //! The vector holding the actual site data
      tStationList StationData;
      //! A helper function that finds all common frequencies
      void FindCommon(void);
    public:
      //! Access to the complete vector of Stations
      tStationList &GetList()
        {
          return StationData;
        }
      //! Read a list of filenames and the associated data in those files to fill the list
      void GetData(const std::string filename);
      //! Write the names of the sites in the current list to a file
      void WriteList(const std::string filename = "station.list");
      //! Write the data of each station to an individual file
      void WriteAllData();
      //! Get a vector that for each site contains the indices to the common frequencies
      const std::vector<tindexvector> &GetComFreqIndices()
        {
          return cfindices;
        }
      //! Get a vector with frequencies that are common to all sites
      const trealdata &GetCommonFrequencies()
        {
          return commonfrequencies;
        }
      //! Get a reference to a site at a given index
      MTStation& at(int loc);
      MTStationList(double freqtol = 0.05);
      virtual ~MTStationList();
      };

    typedef std::vector<std::pair<MTStation*, MTStation*> > tStatSyncPair;
    //! Take two different site Lists of arguments and return a vector of pairs that point to the sites that correspond to each other
    tStatSyncPair FindCorrespondingSites(tStationList &MasterList,
        tStationList &SlaveList);
  /* @} */
  }
#endif // CMTSTATIONLIST_H
