#include "MTTensor.h"

namespace gplib
  {
    MTTensor::MTTensor() :
        Zxx(0), Zxy(0), Zyx(0), Zyy(0), dZxx(0), dZxy(0), dZyx(0), dZyy(0), frequency(0), rotangle(
            0), Rx(0), Ry(0), Nu(0)
      {
      }

    MTTensor::MTTensor(const std::complex<double> &xx, const std::complex<double> &xy,
        const std::complex<double> &yx, const std::complex<double> &yy, const double freq,
        const double angle) :
        Zxx(xx), Zxy(xy), Zyx(yx), Zyy(yy), dZxx(0), dZxy(0), dZyx(0), dZyy(0), frequency(
            freq), rotangle(angle), Rx(0), Ry(0), Nu(0)
      {
      }

    MTTensor& MTTensor::operator=(const MTTensor& source)
      {
        if (this == &source)
          return *this;
        Zxx = source.Zxx;
        Zxy = source.Zxy;
        Zyx = source.Zyx;
        Zyy = source.Zyy;
        dZxx = source.dZxx;
        dZxy = source.dZxy;
        dZyx = source.dZyx;
        dZyy = source.dZyy;
        frequency = source.frequency;
        rotangle = source.rotangle;
        Rx = source.Rx;
        Ry = source.Ry;
        Nu = source.Nu;
        return *this;
      }
    MTTensor::~MTTensor()
      {
      }

    void MTTensor::Rotate(double angle)
      {
        dcomp newxx, newxy, newyx, newyy;
        const double ca2 = pow(cos(angle), 2);
        const double sa2 = pow(sin(angle), 2);
        const double casa = sin(angle) * cos(angle);
        newxx = Zxx * ca2 - (Zxy + Zyx) * casa + Zyy * sa2;
        newxy = Zxy * ca2 + (Zxx - Zyy) * casa - Zyx * sa2;
        newyx = Zyx * ca2 + (Zxx - Zyy) * casa - Zxy * sa2;
        newyy = Zyy * ca2 + (Zxy + Zyx) * casa + Zxx * sa2;
        Zxx = newxx;
        Zxy = newxy;
        Zyx = newyx;
        Zyy = newyy;
        rotangle += angle;
      }
  }
