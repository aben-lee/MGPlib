#include "MagneticTF.h"

namespace gplib
  {
    MagneticTF::MagneticTF() :
      Tx(0), Ty(0), dTx(0), dTy(0), Rz(0), frequency(0)
      {
      }

    MagneticTF::~MagneticTF()
      {
      }
  }
