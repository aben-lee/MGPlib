#include "PTensorMTData.h"

namespace gplib
  {
    PTensorMTData::PTensorMTData():
      phi11(0.0), phi12(0.0), phi21(0.0), phi22(0.0), dphi11(0.0), dphi12(0.0),
          dphi21(0.0), dphi22(0.0), frequency(0.0)
      {
      }

    PTensorMTData::PTensorMTData(const double f, const double p11,
        const double p12, const double p21, const double p22,
        const double dp11, const double dp12, const double dp21,
        const double dp22):
      phi11(p11), phi12(p12), phi21(p21), phi22(p22), dphi11(dp11),
          dphi12(dp12), dphi21(dp21), dphi22(dp22), frequency(f)
      {

      }
    PTensorMTData::~PTensorMTData()
      {
      }
  }
