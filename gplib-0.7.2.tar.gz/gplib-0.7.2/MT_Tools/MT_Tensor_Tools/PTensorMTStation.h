#ifndef PTENSORMTSTATION_H_
#define PTENSORMTSTATION_H_
#include "PTensorMTData.h"
#include <vector>
#include <string>
#include "types.h"
#include "MTStation.h"

namespace gplib
  {
    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    class PTensorMTStation
      {
    private:
      std::vector<PTensorMTData> Tensor;
    public:
      const PTensorMTData &at(const unsigned int i) const
        {
          return Tensor.at(i);
        }
      PTensorMTData &at(const unsigned int i)
        {
          return Tensor.at(i);
        }
      std::vector<PTensorMTData> &GetTensor()
        {
          return Tensor;
        }
      const std::vector<PTensorMTData> &GetTensor() const
        {
          return Tensor;
        }
      const trealdata GetFrequencies() const;
      void GetData(const std::string &filename);
      void WriteData(const std::string &filename);
      //! copies the phase tensor elements calculated from the impedance in MTData, but without errors
      PTensorMTStation &operator=(const MTStation &MTData);
      PTensorMTStation();
      virtual ~PTensorMTStation();
      };
  /* @} */
  }
#endif /*PTENSORMTSTATION_H_*/
