//============================================================================
// Name        : StationParser.h
// Author      : Mar 5, 2010
// Version     : 
// Copyright   : 2010, mmoorkamp
//============================================================================


#ifndef STATIONPARSER_H_
#define STATIONPARSER_H_

#include <vector>
#include <iostream>

namespace gplib
  {
  /** \addtogroup mttools MT data analysis, processing and inversion */
  /* @{ */
    //! Read in an ascii file containing  a list of filenames for each station and optionally position
    /*! This class is used as a helper for programs that need to read in information from several
     * separate files. It reads in an ascii file in the format
     * name   lat long
     * where lat and long are optional and stores these values in vectors that can be accessed
     * by other classes or programs.
     */
    class StationParser
      {
    public:
      //! Vector of latitudes for each station, zero of no value in the file
      std::vector<double> Latitudes;
      //! Vector of longitudes for each station, zero of no value in the file
      std::vector<double> Longitudes;
      //! Do we have valid lat/lon information for each station
      std::vector<bool> HasLatLong;
      //! Name of the different station, usually a filename that is used in other classes
      std::vector<std::string> Stationnames;
      //! Read in lines from an ascii file and parse each line for station information
      void ParseFile(std::istream& in);
      StationParser();
      virtual ~StationParser();
      };
    /* @} */
  }

#endif /* STATIONPARSER_H_ */
