#include <iostream>
#include <string>
#include <numeric>
#include "statutils.h"
#include "TimeSeriesData.h"

using namespace std;
using namespace gplib;

string version = "$Id: ";

int main(int argc, char *argv[])
  {
    string infilename;
    if (argc == 2)
      {
        infilename = argv[1];
      }
    else
      {
        cout
            << "This is mtumedian: Apply a median filter to  Phoenix time series"
            << endl << endl;
        cout << " Usage:      mtumedian infilename " << endl;
        cout << " Ending '.med'  will be automatically assigned to outfilename"
            << endl << endl;
        cout << " This is Version: " << version << endl << endl;
        cout << " Mtu-Filename: ";
        cin >> infilename;
      }
    size_t seglength = 0;
    cout << "Segment length for Median: ";
    cin >> seglength;

    TimeSeriesData Data;

    Data.GetData(infilename);
    size_t datalength = Data.GetData().GetEx().GetData().size();
    for (size_t i = seglength / 2; i < datalength - seglength / 2; ++i)
      {
        const size_t startindex = i - seglength / 2;
        const size_t endindex = i + seglength / 2;
        Data.GetData().GetEx().GetData().at(i) = Median(
            Data.GetData().GetEx().GetData().begin() + startindex,
            Data.GetData().GetEx().GetData().begin() + endindex);
        Data.GetData().GetEx().GetData().at(i) = Median(
            Data.GetData().GetEy().GetData().begin() + startindex,
            Data.GetData().GetEy().GetData().begin() + endindex);
        Data.GetData().GetEx().GetData().at(i) = Median(
            Data.GetData().GetHx().GetData().begin() + startindex,
            Data.GetData().GetHx().GetData().begin() + endindex);
        Data.GetData().GetEx().GetData().at(i) = Median(
            Data.GetData().GetHy().GetData().begin() + startindex,
            Data.GetData().GetHy().GetData().begin() + endindex);
      }
    Data.WriteAsMtu(infilename + ".med");
  }
