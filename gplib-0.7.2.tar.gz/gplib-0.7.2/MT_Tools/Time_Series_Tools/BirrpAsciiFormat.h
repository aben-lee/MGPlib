#ifndef _BIRRPASCIIFORMAT_INCLUDED_
#define _BIRRPASCIIFORMAT_INCLUDED_
#include "TimeSeries.h"

namespace gplib
  {
    class MtuFormat;

    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    //! BirrpAsciiFormat reads and stores MT data in the ascii format used by the birrp processing software
    class BirrpAsciiFormat: public TimeSeries
      {
    private:
    public:
      BirrpAsciiFormat();
      ~BirrpAsciiFormat();
      //! Read data in birrp ascii format from a file called filename
      virtual void GetData(const std::string filename);
      //! Write data in birrp ascii format to a file called filename
      virtual void WriteData(const std::string filename);
      BirrpAsciiFormat& operator=(BirrpAsciiFormat& source);
      BirrpAsciiFormat& operator=(MtuFormat& source);
      BirrpAsciiFormat& operator=(TimeSeries& source);
      };
  /* @} */
  }
#endif

