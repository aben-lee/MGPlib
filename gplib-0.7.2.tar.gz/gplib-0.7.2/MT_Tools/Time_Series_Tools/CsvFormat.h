#ifndef _CSVFORMAT_INCLUDED_
#define _CSVFORMAT_INCLUDED_
#include "TimeSeries.h"

namespace gplib
  {
    class MtuFormat;

    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    //! This class reads and writes data from Comma Separated Files CSV as produced by Excel etc.  this particular flavour
    // aims at files produced by phoenix software
    class CsvFormat: public TimeSeries
      {
    public:
      CsvFormat();
      virtual ~CsvFormat();
      virtual void GetData();
      virtual void GetData(const std::string filename);
      virtual void WriteData(const std::string filename);
      CsvFormat& operator=(CsvFormat& source);
      CsvFormat& operator=(MtuFormat& source);
      CsvFormat& operator=(TimeSeries& source);
      };
  /* @} */
  }
#endif
