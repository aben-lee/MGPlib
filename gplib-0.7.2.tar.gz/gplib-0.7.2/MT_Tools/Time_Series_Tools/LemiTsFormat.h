#ifndef _CLEMITSFORMAT_H_
#define _CLEMITSFORMAT_H_

#include "TimeSeries.h"

namespace gplib
  {
    class MtuFormat;
    class BirrpAsciiFormat;

    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    //! Read and write ascii files produced by the LEMI instruments
    class LemiTsFormat: public TimeSeries
      {
    public:
      LemiTsFormat();
      virtual ~LemiTsFormat();
      virtual void GetData();
      virtual void GetData(const std::string filename);
      virtual void WriteData(const std::string filename);
      LemiTsFormat& operator=(BirrpAsciiFormat& source);
      LemiTsFormat& operator=(MtuFormat& source);
      LemiTsFormat& operator=(TimeSeries& source);
      LemiTsFormat& operator=(LemiTsFormat& source);
      };
  /* @} */
  }
#endif /*_CLEMITSFORMAT_H_*/
