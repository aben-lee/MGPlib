#ifndef CMTUFILTER_H
#define CMTUFILTER_H

#include "types.h"
#include <string>

namespace gplib
  {
    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    //! Store the filter coefficients for one component of Phoenix mtu data
    class MtuFilter
      {
      int seglength;
      double freqstep;
      tcompdata FilterCoeff;
    public:
      const tcompdata &GetFilterCoeff()
        {
          return FilterCoeff;
        }
      virtual void GetData(const std::string filename);
      virtual void WriteData(const std::string filename);
      MtuFilter(const int length, const double step) :
        seglength(length), freqstep(step)
        {
        }
      ;
      virtual ~MtuFilter();
      };
  /* @} */
  }
#endif // CMTUFILTER_H
