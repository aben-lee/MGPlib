#ifndef _MTUFORMAT_INCLUDED_
#define _MTUFORMAT_INCLUDED_
#include "TimeSeries.h"

#include <string>
#include <fstream>
#include <cstdint>
namespace gplib
  {
    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    //! Read and write phoenix mtu binary files
    class MtuFormat: public TimeSeries
      {
    private:
      char startsec;
      char startmin;
      char starthr;
      char startday;
      char startmonth;
      char startyear;
      char startdow;
      char startcentury;
      int64_t serialnumber;
      int64_t nscans;
      char nchannels;
      char taglength;
      char status;
      char saturationflags;
      char futurereserved;
      double sampledenom;
      double sampleenum;
      char sampleunit;
      char samplelength;
      char rateunit;
      char clockstatus;
      int64_t clockerror;
      char reserved[6];
      //! Read one record of data (header+data) from the filestream
      void ReadRecord(std::ifstream &infile);
      //! Write a number to file in mtu binary format
      void WriteNum(double number, std::ofstream &outfile);
      //! Convert raw bytes from mtu binary file to integer number
      int ByteToInt(unsigned char first, unsigned char second,
          unsigned char last);
      //! Convert byte sequence to a number and append to channel
      void ReadValue(TimeSeriesComponent &CurrChannel, char *pos);
      //! Set time information in header
      void UpDateHeader(unsigned char *&header, const int firstscan);
    public:
      //! remove the "bad" flag from the header
      void MakeGood();
      MtuFormat();
      virtual ~MtuFormat();
      virtual void GetData(const std::string filename);
      virtual void GetData();
      virtual void WriteData(const std::string filename);
      MtuFormat& operator=(MtuFormat &source);
      MtuFormat& operator=(TimeSeries &source);
      };
  /* @} */
  }
#endif
