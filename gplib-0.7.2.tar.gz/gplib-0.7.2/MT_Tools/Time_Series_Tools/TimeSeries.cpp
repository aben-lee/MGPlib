#include "TimeSeries.h"
#include <algorithm>
#include <numeric>
#include "FatalException.h"
#include <boost/cast.hpp>
#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>

using namespace std;
namespace gplib
  {
    TimeSeries::TimeSeries()
      {
        Ex.SetName("ex");
        Ey.SetName("ey");
        Hx.SetName("hx");
        Hy.SetName("hy");
        Hz.SetName("hz");
      }

    TimeSeries::~TimeSeries()
      {
      }

    TimeSeries& TimeSeries::operator=(const TimeSeries &source)
      {
        if (this != &source)
          {
            this->Ex = source.Ex;
            this->Ey = source.Ey;
            this->Hx = source.Hx;
            this->Hy = source.Hy;
            this->Hz = source.Hz;
            copy(source.t.begin(), source.t.end(), back_inserter(t));
          }
        return *this;
      }

    TimeSeries& TimeSeries::operator*=(const double &factor)
      {
        this->Ex *= factor;
        this->Ey *= factor;
        this->Hx *= factor;
        this->Hy *= factor;
        this->Hz *= factor;
        return *this;
      }

    TimeSeries& TimeSeries::operator+=(const double &shift)
      {
        this->Ex += shift;
        this->Ey += shift;
        this->Hx += shift;
        this->Hy += shift;
        this->Hz += shift;
        return *this;
      }

    void TimeSeries::erase(const int startindex, const int endindex)
      {
        Ex.GetData().erase(Ex.GetData().begin() + startindex,
            Ex.GetData().begin() + endindex);
        Ey.GetData().erase(Ey.GetData().begin() + startindex,
            Ey.GetData().begin() + endindex);
        Hx.GetData().erase(Hx.GetData().begin() + startindex,
            Hx.GetData().begin() + endindex);
        Hy.GetData().erase(Hy.GetData().begin() + startindex,
            Hy.GetData().begin() + endindex);
        Hz.GetData().erase(Hz.GetData().begin() + startindex,
            Hz.GetData().begin() + endindex);
        t.erase(t.begin() + startindex, t.begin() + endindex);
      }

    size_t TimeSeries::Size()
      {
        size_t exlength = Ex.GetData().size();
        if (exlength != Ey.GetData().size() || exlength != Hx.GetData().size()
            || exlength != Hy.GetData().size() || exlength
            != Hz.GetData().size())
          throw FatalException(
              "Component sizes differ, unable to determine size !");
        else
          return exlength;
      }

    //Here start some non-member funciton implementations
    //! Synchronize only works for continuous data at this point
    void Synchronize(TimeSeries &Data1, TimeSeries &Data2)
      {
        if (Data1.GetTime().empty() || Data2.GetTime().empty())
          throw FatalException("No time information available !");
        boost::posix_time::time_duration startdiff(Data1.GetTime().at(0)
            - Data2.GetTime().at(0));
        int offset = boost::numeric_cast<int>(startdiff.total_microseconds()
            * Data1.GetSamplerate() / 1000000); //calculate the offset in samples
        if (boost::numeric_cast<unsigned int>(abs(offset)) > min(
            Data1.GetTime().size(), Data2.GetTime().size()))
          throw FatalException("Offset too large. Cannot synchronize !");
        if (offset > 0) //Data1 starts later
          Data2.erase(0, offset);
        if (offset < 0)
          Data1.erase(0, -offset);
      }
  }
