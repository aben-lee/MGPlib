#include "TimeSeriesData.h"
#include "BirrpAsciiFormat.h"
#include "MtuFormat.h"
#include "CsvFormat.h"
#include "LemiTsFormat.h"
#include "FatalException.h"
#include "convert.h"
#include "Util.h"
#include <iostream>

using namespace std;
namespace gplib
  {
    TimeSeriesData::TimeSeriesData()
      {
      }

    TimeSeriesData::~TimeSeriesData()
      {
      }

    void TimeSeriesData::GetData(std::string filename)
      {
        string ending;
        //we identify the type of data by the file extension
        ending = GetFileExtension(filename);
        //Phoenix MTU data can have different endings depending on the sampling frequency
        if (ending == ".ts3" || ending == ".TS3" || ending == ".ts4" || ending
            == ".TS4" || ending == ".ts5" || ending == ".TS5")
          {
            Data = boost::shared_ptr<TimeSeries>(new MtuFormat);
            datatype = mtu;
          }
        //asc is the format used by birrp, basically just columns of numbers
        else if (ending == ".asc")
          {
            Data = boost::shared_ptr<TimeSeries>(new BirrpAsciiFormat);
            datatype = birrp;
          }
        //comma separated values have the ending .csv
        else if (ending == ".csv")
          {
            Data = boost::shared_ptr<TimeSeries>(new CsvFormat);
            datatype = csv;
          }
        //the lemi instruments produce ascii files with additional columns
        else if (ending == ".lem")
          {
            Data = boost::shared_ptr<TimeSeries>(new LemiTsFormat);
            datatype = lemi;
          }
        else
          {
            datatype = tsunknown;
            throw FatalException(
                "Unknown data format or file does not exist : " + filename);
          }
        name = filename;
        unsigned int dotpos = name.find('.', 0);
        if (dotpos != string::npos)
          name.erase(dotpos);
        Data->GetData(filename);
      }

    TimeSeriesData& TimeSeriesData::operator=(const TimeSeriesData& source)
      {
        if (this != &source)
          {
            this->name = source.name;
            this->datatype = source.datatype;
            //TODO introduce virtual constructors or redesign read/write mechanism
            this->Data = source.Data;
          }
        return *this;
      }

    void TimeSeriesData::WriteAsMtu(std::string filename_base)
      {
        if (datatype == mtu)
          {
            switch (int(Data->GetSamplerate()))
              {
            case 2400:
              Data->WriteData(filename_base + ".ts3");
              break;
            case 150:
              Data->WriteData(filename_base + ".ts4");
              break;
            case 15:
              Data->WriteData(filename_base + ".ts5");
              break;
            default:
              throw FatalException(
                  "Unknown samplerate ! Cannot write file. Value is: "
                      + stringify(Data->GetSamplerate()));
              break;
              }
          }
        else
          {
            throw FatalException("Data conversion not implemented yet ! ");
          }
      }

    void TimeSeriesData::WriteAsBirrp(std::string filename_base)
      {
        //return static_cast<CBirrpAsciiFormat*>(Data)->WriteData(filename_base+".asc");
        if (datatype == birrp)
          Data->WriteData(filename_base + ".asc");
        else
          {
            BirrpAsciiFormat BirrpData;
            BirrpData = *Data;
            BirrpData.WriteData(filename_base + ".asc");
          }
      }

    void TimeSeriesData::WriteAsLemi(std::string filename_base)
      {
        if (datatype == lemi)
          Data->WriteData(filename_base + ".lem");
        else
          {
            LemiTsFormat LemiData;
            LemiData = *Data;
            LemiData.WriteData(filename_base + ".lem");
          }
      }

    void TimeSeriesData::WriteAsCsv(std::string filename_base)
      {
        throw FatalException("Csv write not implemented yet ! ");
      }

    void TimeSeriesData::WriteBack(std::string filename_base)
      {
        switch (datatype)
          {
        case lemi:
          WriteAsLemi(filename_base);
          break;
        case birrp:
          WriteAsBirrp(filename_base);
          break;
        case mtu:
          WriteAsMtu(filename_base);
          break;
        case csv:
          WriteAsCsv(filename_base);
          break;
        default:
          throw FatalException("Cannot write back data ! Unknown datatype !");
          break;
          }
      }
  }
