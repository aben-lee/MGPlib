#ifndef CTIMESERIESDATA_H
#define CTIMESERIESDATA_H
#include "TimeSeries.h"
#include <string>
#include <boost/shared_ptr.hpp>

namespace gplib
  {
    /** \addtogroup mttools MT data analysis, processing and inversion */
    /* @{ */

    //! ttsdatatype is used to store the source the data was read from
    enum ttsdatatype
      {
      tsunknown, mtu, birrp, csv, lemi
      };

    //! TimeSeriesData stores  a pointer to the different components of magnetotelluric data and provides functions to read and write it to files

    /*! This should be made consistent with the corresponding Seismic data at some point
     */
    class TimeSeriesData
      {
    private:
      //! the sitename
      std::string name;
      //! the type of data
      ttsdatatype datatype;
      //! a pointer to the actual data object
      boost::shared_ptr<TimeSeries> Data;
    public:
      //! return a reference to the actual object stored in the pointer
      TimeSeries &GetData()
        {
          return *Data;
        }
      //! GetData reads in data from a file and determines the type from the ending
      void GetData(std::string filename);
      //! Write data to file in Phoenix MTU format
      void WriteAsMtu(std::string filename_base);
      //! Write data to file in ascii format for birrp processing
      void WriteAsBirrp(std::string filename_base);
      //! Write data as comma seperated ascii file
      void WriteAsCsv(std::string filename_base);
      //! Write as file in Lemi compatible format
      void WriteAsLemi(std::string filename_base);
      //! Write in the format it was originally read in
      void WriteBack(std::string filename_base);
      TimeSeriesData();
      virtual ~TimeSeriesData();
      //! The copy constructor
      TimeSeriesData& operator=(const TimeSeriesData& source);
      };
  /* @} */
  }
#endif // CTIMESERIESDATA_H
