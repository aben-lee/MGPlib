#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include "TimeSeriesData.h"

using namespace std;
using namespace gplib;

string version = "$Id: exchangecomp.cpp 1816 2009-09-07 11:28:35Z mmoorkamp $";

int main(int argc, char *argv[])
  {
    TimeSeriesData TsData;

    string mtufilename, compfilename;
    cout
        << "This is exchangecomp: Exchange one component of MTU file by contents of ascii file"
        << endl << endl;
    cout
        << " Output will have the same name as MTU Input with '.rep' appended "
        << endl << endl;
    cout << " This is Version: " << version << endl << endl;

    cout << "Mtu filename: ";
    cin >> mtufilename;
    TsData.GetData(mtufilename);

    cout << "Component filename: ";
    cin >> compfilename;
    vector<double> compdata;
    ifstream compfile(compfilename.c_str());
    copy(istream_iterator<double> (compfile), istream_iterator<double> (),
        back_inserter(compdata));
    if (compdata.size() != TsData.GetData().GetEx().GetData().size())
      {
        std::cerr << "Number of points incompatible !";
        return 100;
      }
    int compindex;
    cout << "Enter target component number (Ex,Ey,Hx,Hy): ";
    cin >> compindex;
    std::vector<double>::iterator outit;
    switch (compindex)
      {
    case 1:
      outit = TsData.GetData().GetEx().GetData().begin();
      break;
    case 2:
      outit = TsData.GetData().GetEy().GetData().begin();
      break;
    case 3:
      outit = TsData.GetData().GetHx().GetData().begin();
      break;
    case 4:
      outit = TsData.GetData().GetHy().GetData().begin();
      break;
    default:
      std::cerr << "Invalid component selection !";
      return 100;
      break;
      }
    copy(compdata.begin(), compdata.end(), outit);
    TsData.WriteAsMtu(mtufilename + ".rep");
  }
