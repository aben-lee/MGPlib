/*!
 * \addtogroup UtilProgs Utility Programs
 *@{
 * \file
 * This program calculates the mean magnetic time series for several MT sites. The user has to input the number of sites and the
 * filename for each site. The program then writes a file 'magmean.out' in birrp ascii format that contains the average Hx,Hy and Hz for the input sites.
 */

#include <iostream>
#include <string>
#include <vector>
#include "TimeSeriesData.h"
#include "Util.h"
#include "convert.h"

using namespace std;
using namespace gplib;

string version = "$Id: magmean.cpp 1816 2009-09-07 11:28:35Z mmoorkamp $";

int main(int argc, char *argv[])
  {

    unsigned int nfiles = 0;

    cout
        << "This is magmean: Calculate the mean magnetic time series from several stations"
        << endl<< endl;
    cout << "Usage: magmean" << endl;
    cout << "There are no command line arguments, only interactive mode"
        << endl<< endl;
    cout << "This is Version: " << version << endl << endl;
    cout << "How many stations: ";
    cin >> nfiles;
    string infilename;
    vector<TimeSeriesData> Sites;
    for (unsigned int i = 0; i < nfiles; ++i)
      {

        std::string prompt = "Site File " + stringify(i+1) + " :";
        TimeSeriesData CurrSite;
        infilename = AskFilename(prompt);
        CurrSite.GetData(infilename);
        Sites.push_back(CurrSite);
      }
    cout << "Calculating mean ... " << endl;

    for (unsigned int i = 1; i < nfiles; ++i)
      {
        Sites.at(0).GetData().GetHx() += Sites.at(i).GetData().GetHx();
        Sites.at(0).GetData().GetHy() += Sites.at(i).GetData().GetHy();
        Sites.at(0).GetData().GetHz() += Sites.at(i).GetData().GetHz();
      }
    Sites.at(0).GetData().GetHx() *= 1./nfiles;
    Sites.at(0).GetData().GetHy() *= 1./nfiles;
    Sites.at(0).GetData().GetHz() *= 1./nfiles;
    Sites.at(0).WriteAsBirrp("magmean.out");
    cout << "... done " << endl;
  }
/*@}*/

