#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <boost/shared_ptr.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "TimeSeriesData.h"
#include "miscfunc.h"
#include "Util.h"

using namespace std;
using namespace gplib;

string version = "$Id: mtuadaptive.cpp 942 2007-04-08 16:13:01Z max $";

int main()
  {
    cout
        << "This is tscross: Calculate the 0 lag cross-correlation between components of two times series"
        << endl << endl;
    cout << " The program will ask for reference and input filename. " << endl;
    cout
        << " The cross correlation for each component is written to the screen."
        << endl << endl;
    cout << " This is Version: " << version << endl << endl;

    TimeSeriesData Data1, Data2;

    int index;
    string data1filename, data2filename;

    data1filename = AskFilename("Data file 1: ");
    Data1.GetData(data1filename);
    cout << "Component Index (Hx,Hy,Ex,Ey): ";
    cin >> index;
    data2filename = AskFilename("Data file 2: ");
    Data2.GetData(data2filename);
    cout << "Data1 Start time: " << Data1.GetData().GetTime().front() << endl;
    cout << "Dat2 Start time: " << Data2.GetData().GetTime().front() << endl;
    if (Data1.GetData().GetTime().front() != Data2.GetData().GetTime().front())
      {
        cerr << "Time series not synchronized !" << endl;
        return 100;
      }

    int length = Data1.GetData().Size();

    cout << "Input End time: " << Data1.GetData().GetTime().back() << endl;
    cout << "Reference End time: " << Data2.GetData().GetTime().back() << endl;

    TimeSeriesComponent *RefComp;
    switch (index)
      {
    case 1:
      RefComp = &Data1.GetData().GetHx();
      break;
    case 2:
      RefComp = &Data1.GetData().GetHy();
      break;
    case 3:
      RefComp = &Data1.GetData().GetEx();
      break;
    case 4:
      RefComp = &Data1.GetData().GetEy();
      break;
    default:
      cerr << "Component index not valid !";
      return 100;
      break;
      }
    double cross = Cross(RefComp->GetData(), Data2.GetData().GetHx().GetData(),
        0, length);
    cout << "Cross Hx: " << cross << endl;
    cross = Cross(RefComp->GetData(), Data2.GetData().GetHy().GetData(), 0,
        length);
    cout << "Cross Hy: " << cross << endl;
    cross = Cross(RefComp->GetData(), Data2.GetData().GetEx().GetData(), 0,
        length);
    cout << "Cross Ex: " << cross << endl;
    cross = Cross(RefComp->GetData(), Data2.GetData().GetEy().GetData(), 0,
        length);
    cout << "Cross Ey: " << cross << endl;
  }

