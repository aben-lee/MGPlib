#include <iostream>
#include <string>
#include "Util.h"
#include "TimeSeriesData.h"
#include <boost/date_time/posix_time/posix_time.hpp>

using namespace std;
using namespace gplib;

/*!
 * \addtogroup UtilProgs Utility Programs
 *@{
 * \file
 * Cut a MT time series to a given number of points and (optionally) shift the beginning 
 * by some points.  
 */

string version = "$Id: mtucut.cpp 1889 2016-05-25 13:16:12Z mmoorkamp $";

int main(int argc, char *argv[])
  {
    string infilename;
    size_t newlength, startindex;

    cout << "This is mtucut: Cut Phoenix time series to a given length" << endl
        << endl;
    cout
        << "Ending .cut + ending [ts3,ts4,ts5] will be automatically assigned to outfilename"
        << endl << endl;
    cout << "This is Version: " << version << endl << endl;

    if (argc == 2)
      {
        infilename = argv[1];
      }
    else
      {
        infilename = AskFilename("Mtu-Filename: ");
      }

    TimeSeriesData Data;
    Data.GetData(infilename);
    cout << "Old length: " << Data.GetData().GetEx().GetData().size() << endl;
    cout << "Old Start time: " << Data.GetData().GetTime().front() << endl;
    cout << "Old End time: " << Data.GetData().GetTime().back() << endl;
    cout << "New length: ";
    cin >> newlength;
    cout << "Startindex: ";
    cin >> startindex;

    const size_t length = Data.GetData().GetEx().GetData().size();
    if (newlength + startindex > length)
      {
        cerr << "Selected segment is partially outside time series !";
        return 100;
      }
    else
      {
        // remove the data at the beginning that is not needed any more
        Data.GetData().erase(0, startindex);
        //remove the data at the end, that is not needed any more
        Data.GetData().erase(Data.GetData().Size() - (Data.GetData().Size()
            - newlength), Data.GetData().Size());
        Data.WriteAsMtu(infilename + ".cut");
      }

    cout << "New Start time: " << Data.GetData().GetTime().front() << endl;
    cout << "New End time: " << Data.GetData().GetTime().back() << endl;

  }
/*@}*/
