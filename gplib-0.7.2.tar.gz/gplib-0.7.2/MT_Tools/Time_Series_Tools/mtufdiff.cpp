#include <iostream>
#include <string>
#include <numeric>
#include "Util.h"
#include "TimeSeriesData.h"

using namespace std;
using namespace gplib;
string version = "$Id: mtu2birrp.cpp 651 2006-10-10 14:46:53Z max $";

/*!
 * \addtogroup UtilProgs Utility Programs
 *@{
 * \file
 * Calculate the first difference for all components of a MT time-series. 
 */

int main(int argc, char *argv[])
  {
    string infilename;
    if (argc == 2)
      {
        infilename = argv[1];
      }
    else
      {
        cout
            << "This is mtufdiff: Calculate first difference of  Phoenix time series"
            << endl << endl;
        cout << " Usage:      mtufdiff infilename " << endl;
        cout
            << " Ending '.fdiff'  will be automatically assigned to outfilename"
            << endl << endl;
        cout << " This is Version: " << version << endl << endl;
        infilename = AskFilename(" Mtu-Filename: ");
      }

    TimeSeriesData Data;

    Data.GetData(infilename);
    adjacent_difference(Data.GetData().GetEx().GetData().begin(),
        Data.GetData().GetEx().GetData().end(),
        Data.GetData().GetEx().GetData().begin());
    adjacent_difference(Data.GetData().GetEy().GetData().begin(),
        Data.GetData().GetEy().GetData().end(),
        Data.GetData().GetEy().GetData().begin());
    adjacent_difference(Data.GetData().GetHx().GetData().begin(),
        Data.GetData().GetHx().GetData().end(),
        Data.GetData().GetHx().GetData().begin());
    adjacent_difference(Data.GetData().GetHy().GetData().begin(),
        Data.GetData().GetHy().GetData().end(),
        Data.GetData().GetHy().GetData().begin());
    Data.WriteBack(infilename + ".fdiff");
  }
/*@}*/
