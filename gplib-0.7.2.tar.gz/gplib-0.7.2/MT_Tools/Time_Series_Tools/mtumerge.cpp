#include "MtuFormat.h"
#include <iostream>
#include "Util.h"

using namespace std;
using namespace gplib;

/*!
 * \addtogroup UtilProgs Utility Programs
 *@{
 * \file
 * Merge the electric field from one site with the magnetic field from another site. 
 */

int main()
  {
    MtuFormat ETsData, BTsData;

    string einfilename = AskFilename("E Channel Filename: ");
    string binfilename = AskFilename("B Channel Filename: ");
    string outfilename = AskFilename("Output Filename: ");

    ETsData.GetData(einfilename.c_str());
    BTsData.GetData(binfilename.c_str());
    BTsData.GetEx() = ETsData.GetEx();
    BTsData.GetEy() = ETsData.GetEy();
    BTsData.WriteData(outfilename.c_str());
  }
/*@}*/
