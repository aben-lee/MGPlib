#include "TimeSeriesData.h"
#include <iostream>

using namespace std;
using namespace gplib;

int main()
  {
    string infilename;
    TimeSeriesData TsData;

    cout << "Filename: ";
    cin >> infilename;

    TsData.GetData(infilename);
    cout << "Number of points: " << TsData.GetData().GetEx().GetData().size()
        << endl;
  }
