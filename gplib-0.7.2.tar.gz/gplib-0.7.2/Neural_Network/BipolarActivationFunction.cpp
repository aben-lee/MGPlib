#include "BipolarActivationFunction.h"
#include <cmath>
#include "NumUtil.h"
#include <iostream>

namespace gplib
  {
    BipolarActivationFunction::BipolarActivationFunction()
      {
      }
    BipolarActivationFunction::~BipolarActivationFunction()
      {
      }

    double BipolarActivationFunction::CalcOutput(const double input)
      {
        return (tanh(0.5 * input));
      }

    double BipolarActivationFunction::CalcDeriv(const double input)
      {
        return (0.5 * 1. / pow2(cosh(input)));
      }
  }
