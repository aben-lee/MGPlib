#ifndef CBIPOLARACTIVATIONFUNCTION_H
#define CBIPOLARACTIVATIONFUNCTION_H

#include "GeneralActivationFunction.h"

namespace gplib
  {
    /** \addtogroup neuralnet Neural Network filtering */
    /* @{ */
    //! The bipolar activation function is a common function in NN applications
    /*! The output is \f$ \tanh (0.5 x) \f$ and can assume values between \f$ -1 \ldots 1 \f$.
     */
    class BipolarActivationFunction: public GeneralActivationFunction
      {
    public:
      virtual double CalcOutput(const double input);
      virtual double CalcDeriv(const double input);
      BipolarActivationFunction();
      virtual ~BipolarActivationFunction();
      };
  /* @} */
  }
#endif // CBIPOLARACTIVATIONFUNCTION_H
