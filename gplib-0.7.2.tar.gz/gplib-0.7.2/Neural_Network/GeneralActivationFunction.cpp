#include "GeneralActivationFunction.h"

namespace gplib
  {
    GeneralActivationFunction::GeneralActivationFunction()
      {
      }
    GeneralActivationFunction::~GeneralActivationFunction()
      {
      }
  }
