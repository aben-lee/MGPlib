#ifndef CGENERALLINEARCOMBINER_H
#define CGENERALLINEARCOMBINER_H
#include <vector>
#include <boost/shared_ptr.hpp>

namespace gplib
  {
    class GeneralNeuron;

    /** \addtogroup neuralnet Neural Network filtering */
    /* @{ */

    //! A linear combiner as a component of a neural network
    /*! It can cache the last output for faster calculation within the network, but this assumes that between every output calculation
     the weights are updated.
     */
    class GeneralLinearCombiner
      {
    public:
      typedef std::vector<boost::shared_ptr<GeneralNeuron> > tinvector;
    private:
      //! The weight for each input channel
      std::vector<double> Weights;
      //! The current output
      double Output;
      //! A vector of pointers to other neurons, that provide the input for this combiner
      tinvector Input;
      //! The bias weight
      double Bias;
      //! have the weights changed since the last calculation ?
      bool wchanged;
      //! has the bias changed since the last calculation ?
      bool bchanged;
      //! do we want to cache the output or recalculate it every time
      bool cachedoutput;
    public:
      //! Set the bias weigth
      void SetBias(const double b)
        {
          bchanged = true;
          Bias = b;
        }
      //! Get the current value for the bias
      double GetBias() const
        {
          return Bias;
        }
      //! Get the values of the Weight vector
      const std::vector<double> &GetWeights() const
        {
          return Weights;
        }
      //! change the values of the Weight vector
      std::vector<double> &SetWeights()
        {
          wchanged = true;
          return Weights;
        }
      //! Calculate the output given the current configuration
      virtual double CalcOutput();
      //! connect the input channels to the neurons given in LocalInput
      virtual void SetInput(const tinvector &LocalInput);
      //! get the input channel configuration
      const tinvector &GetInput() const
        {
          return Input;
        }
      explicit GeneralLinearCombiner(bool wantcached = false);
      virtual ~GeneralLinearCombiner();
      };
  /* @} */
  }
#endif // CGENERALLINEARCOMBINER_H
