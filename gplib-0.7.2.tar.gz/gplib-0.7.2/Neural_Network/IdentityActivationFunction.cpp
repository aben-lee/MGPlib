#include "IdentityActivationFunction.h"
#include <iostream>

namespace gplib
  {
    IdentityActivationFunction::IdentityActivationFunction()
      {
      }
    IdentityActivationFunction::~IdentityActivationFunction()
      {
      }

    double IdentityActivationFunction::CalcOutput(const double input)
      {
        return input;
      }

    double IdentityActivationFunction::CalcDeriv(const double input)
      {
        return 1.0;
      }
  }
