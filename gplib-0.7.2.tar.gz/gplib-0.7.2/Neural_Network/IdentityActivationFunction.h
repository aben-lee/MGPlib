#ifndef CIDENTITYACTIVATIONFUNCTION_H
#define CIDENTITYACTIVATIONFUNCTION_H

#include "GeneralActivationFunction.h"

namespace gplib
  {
    /** \addtogroup neuralnet Neural Network filtering */
    /* @{ */
    //! This activation function simply outputs its input
    class IdentityActivationFunction: public GeneralActivationFunction
      {
    public:
      virtual double CalcOutput(const double input);
      virtual double CalcDeriv(const double input);
      IdentityActivationFunction();
      virtual ~IdentityActivationFunction();
      };
  /* @} */
  }
#endif // CIDENTITYACTIVATIONFUNCTION_H
