#ifndef CNEURALNETWORK_H
#define CNEURALNETWORK_H
#include <vector>
#include <iostream>
#include <boost/shared_ptr.hpp>
#include "SigmoidalNeuron.h"
#include "InputNeuron.h"
#include "AdaptiveFilter.h"

namespace gplib
  {
    /** \addtogroup neuralnet Neural Network filtering */
    /* @{ */

    //! The class NeuralNetwork manages the network output calculation, neuron storage and weight adaptation
    //! Derived from AdaptiveFilter so we can use the Filter functionality
    class NeuralNetwork: public AdaptiveFilter
      {
    public:
      typedef std::vector<boost::shared_ptr<GeneralNeuron> > tNeuralLayer;
      typedef std::vector<tNeuralLayer> tNeuralArray;
      typedef std::vector<SigmoidalNeuron::tneurontype> ttypeVector;
      typedef std::vector<ttypeVector> ttypeArray;
    private:
      //! Calculate the output for the whole network
      std::vector<double> &CalcOutput();
      //! In some cases (plotting etc.) we want all the network weights as a single vector
      gplib::rvec WeightsAsVector;
      //! The multiplier for the momentum term
      double alpha;
      //! The adaptation stepsize
      double mu;
      //! The storage of the individual neurons
      tNeuralArray Layers;
      //! The last input to the network, this is the place the input neurons point to
      std::vector<double> LocInput;
      //! The output of the network
      std::vector<double> LocOutput;
      //! The reference values for the current iteration
      std::vector<double> LocDesired;
      //! Adapt the network weights given the current values
      void AdaptWeights();
    public:
      //! Set the momentum multiplier
      void SetAlpha(const double a)
        {
          alpha = a;
        }
      //! Set the adaptation stepsize
      void SetMu(const double m)
        {
          mu = m;
        }
      //! Configure the layers of the network according to the types in typeArray
      void SetLayers(ttypeArray typeArray, bool cachedoutput = false);
      //! Initialize the weights with random values with the specified maxima
      void InitWeights(const double MaxWeight, const double MaxBias);
      //! Print the topology and weights of the network for plotting with the dot program
      void PrintTopology(std::string filename);
      //! Print the weights of the network to the specified output stream
      virtual void PrintWeights(std::ostream &output);
      //! Return the network weights as a single vector
      virtual const gplib::rvec &GetWeightsAsVector();
      //! Adapt the Filter with the current input and desired
      virtual void AdaptFilter(const gplib::rvec &Input,
          const gplib::rvec &Desired);
      //! Calculate the output with the given input
      virtual void CalcOutput(const gplib::rvec &Input, gplib::rvec &Output);
      //! The minium values for the network are the length of the input and output
      NeuralNetwork(const int inputsize, const int outputsize);
      //! Extended constructor with most of the necessary values
      NeuralNetwork(const int inputsize, const int outputsize,
          const double mu_, const ttypeArray &Layerssetup,
          const double maxinit, bool cachedoutput = false);
      virtual ~NeuralNetwork();
      };
  /* @} */
  }
#endif // CNEURALNETWORK_H
