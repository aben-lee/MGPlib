#include "SigmoidalNeuron.h"
#include "BipolarActivationFunction.h"
#include "IdentityActivationFunction.h"

namespace gplib
  {
    SigmoidalNeuron::SigmoidalNeuron(tneurontype type, bool wantcached) :
      Output(0.0), Delta(0.0), Net(0.0), cachedoutput(wantcached)
      {
        SetType(type);
      }

    SigmoidalNeuron::~SigmoidalNeuron()
      {
      }

    double SigmoidalNeuron::CalcOutput()
      {
        Net = Combiner->CalcOutput();
        Output = Function->CalcOutput(Net);
        return Output;
      }

    void SigmoidalNeuron::SetInput(
        const GeneralLinearCombiner::tinvector &input)
      {
        Combiner->SetInput(input);
      }

    void SigmoidalNeuron::SetType(tneurontype type)
      {
        switch (type)
          {
        case bipolar:
          Function = boost::shared_ptr<GeneralActivationFunction>(
              new BipolarActivationFunction);
          break;
        case identity:
          Function = boost::shared_ptr<GeneralActivationFunction>(
              new IdentityActivationFunction);
          break;
          }
        Combiner = boost::shared_ptr<GeneralLinearCombiner>(
            new GeneralLinearCombiner(cachedoutput));
      }
  }
