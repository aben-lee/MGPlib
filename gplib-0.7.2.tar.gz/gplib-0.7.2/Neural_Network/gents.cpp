#include <iostream>
#include <fstream>
#include "UniformRNG.h"
#include "types.h"

using namespace std;
using namespace gplib;

int main(void)
  {
    string outfilebase;
    ofstream cleants, noisets, noisets2;
    int length;
    double noiselevel, currentvalue;
    UniformRNG Random;

    cout << "Outfile Name Base:";
    cin >> outfilebase;
    cout << "Time Series Length:";
    cin >> length;
    cout << "Noiselevel:";
    cin >> noiselevel;
    cleants.open((outfilebase + ".ts").c_str());
    noisets.open((outfilebase + ".ns").c_str());
    noisets2.open((outfilebase + ".ns2").c_str());
    ofstream onlynoise("noise.ts");
    currentvalue = 0;
    const double Period = 50;
    const double PI = acos(-1.);
    double noisevalue = 0;
    for (int i = 0; i < length; ++i)
      {
        //currentvalue += Random.GetNumber() - 0.5;
        //cleants << currentvalue << endl;
        //noisets << currentvalue + (Random.GetNumber() -0.5 )* noiselevel  << endl;
        //noisets2 << currentvalue + (Random.GetNumber()-0.5) * noiselevel  << endl;
        noisevalue = (Random.GetNumber() - 0.5) * noiselevel;
        cleants << sin(2 * PI * i / Period) << endl;
        noisets << cos(2 * PI * i / Period) + noisevalue << endl;
        noisets2 << cos(2 * PI * i / Period) + noisevalue << endl;
        onlynoise << noisevalue << endl;
      }
    cleants.close();
    noisets.close();
    noisets2.close();
  }
