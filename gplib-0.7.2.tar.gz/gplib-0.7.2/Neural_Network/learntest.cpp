#include "NeuralNetwork.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include "UniformRNG.h"

using namespace std;
using namespace gplib;

int main()
  {
    // first some global constants that can be changed to play with
    const int seglength = 2; // the length of the segment we want to work on
    const double maxinit = 0.01; // the maximum the neuron weights are initialized to
    const double maxbias = 0.01; // the maximum bias for each neuron
    const int hiddenlayers = 1; // the number of hiddenlayers
    const double mu = 1; // the stepsize for weight adaptation for each neuron;
    const int trainsamples = 20;
    const int testsamples = 20;
    const int gap = trainsamples / 10;

    int currentindex = 0;
    ttypeVector typeVector; // a vector that contains the type for each neuron in a layer
    ttypeArray typeArray; // an array of typevectors that contains the neuron type for the whole network;

    UniformRNG Random;

    double currentinput, currentref; // the current input and reference values we're working on

    string logfilename("learn.log");
    ofstream logfile(logfilename.c_str());

    typeVector.assign(4 * seglength, bipolar); // we want 4* seglength number of bipolar neurons per hidden layer
    for (int i = 0; i < hiddenlayers; ++i) //intialize the type array for the hidden layers
      {
        typeArray.push_back(typeVector); // all layers are the same, so we copy the same vector there
      }
    typeVector.assign(1, identity);
    typeArray.push_back(typeVector); // and then we add it to the type Array

    NeuralNetwork Network; //We declare a new variable for the network
    Network.Input.assign(seglength, 0); // We have to allocate memory for the network input and set it to zero
    Network.SetLayers(typeArray); // We use the type array we created before to setup the neurons in the Network
    Network.InitWeights(maxinit, maxbias); // The Weights are initialized with the two maximum values
    Network.mu = mu; // The mu value is copied to the network properties


    for (int i = 0; i < trainsamples; ++i)
      {
        double input1 = (0.5 - Random.GetNumber());
        double input2 = (0.5 - Random.GetNumber());
        double desired = exp(input1 + input2);
        Network.Input.at(0) = input1;
        Network.Input.at(1) = input2;
        Network.Desired.front() = desired;
        Network.AdaptWeights();
        Network.CalcOutput();
        for (int j = 0; j < typeArray.size(); ++j)
          {
            cout << "Layer: " << j << endl;
            for (int k = 0; k < typeArray.at(j).size(); ++k)
              {
                cout << "Neuron: " << k << endl;
                cout << "Delta: " << Network.Layers.at(j).at(k)->Delta << endl;
                cout << "Net: " << Network.Layers.at(j).at(k)->Net << endl;
                cout << "Output: " << Network.Layers.at(j).at(k)->Output
                    << endl;
              }
            cout << endl;
          }
        logfile << i << " " << desired << " " << Network.Output.at(0) << " "
            << desired - Network.Output.at(0) << endl;
      }

    for (int i = trainsamples + gap; i < trainsamples + gap + testsamples; ++i)
      {
        double input1 = (0.5 - Random.GetNumber());
        double input2 = (0.5 - Random.GetNumber());
        double desired = input1 + input2;
        Network.Input.at(0) = input1;
        Network.Input.at(1) = input2;
        Network.CalcOutput();
        for (int j = 0; j < typeArray.size(); ++j)
          {
            cout << "Layer: " << j << endl;
            for (int k = 0; k < typeArray.at(j).size(); ++k)
              {
                cout << "Neuron: " << k << endl;
                cout << "Delta: " << Network.Layers.at(j).at(k)->Delta << endl;
                cout << "Net: " << Network.Layers.at(j).at(k)->Net << endl;
                cout << "Output: " << Network.Layers.at(j).at(k)->Output
                    << endl;
              }
            cout << endl;
          }
        //Network.AdaptWeights();
        logfile << i << " " << desired << " " << Network.Output.at(0) << " "
            << desired - Network.Output.at(0) << endl;
      }

  }
