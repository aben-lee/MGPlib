#include "NeuralNetwork.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include "CUniformRNG.h"

using namespace std;
using namespace gplib;

int main()
  {
    // first some global constants that can be changed to play with
    const int seglength = 100; // the length of the segment we want to work on
    const double maxinit = 0.01; // the maximum the neuron weights are initialized to
    const double maxbias = 0.01; // the maximum bias for each neuron
    const int maxit = 1000; // maximum number of iterations = maximum output length
    const int hiddenlayers = 2; // the number of hiddenlayers
    const double mu = 0.1; // the stepsize for weight adaptation for each neuron;

    ttypeVector typeVector; // a vector that contains the type for each neuron in a layer
    ttypeArray typeArray; // an array of typevectors that contains the neuron type for the whole network;
    ifstream inputfile, reffile; // the file objects for the two inputfiles: the noise time series and the reference
    ofstream outputfile, epsfile; // the file objects for the two outputfiles: the cleaned file and the difference to the original

    double currentinput, currentref; // the current input and reference values we're working on

    string inputfilename, reffilename; // the strings containing the filenames
    string outputfilename, epsfilename;

    cout << "Inputfile: ";
    cin >> inputfilename; // read in input filename
    cout << "Referencefile:";
    cin >> reffilename; // read in reference filename
    outputfilename = inputfilename + ".clean"; // set outputfilename for clean file
    epsfilename = inputfilename + ".eps"; // and for difference file
    inputfile.open(inputfilename.c_str()); // open the files for reading
    reffile.open(reffilename.c_str()); // reading
    epsfile.open(epsfilename.c_str()); // writing
    outputfile.open(outputfilename.c_str()); // writing

    typeVector.assign(seglength, bipolar); // we want seglength number of bipolar neurons per hidden layer
    for (int i = 0; i < hiddenlayers; ++i) //intialize the type array for the hidden layers
      {
        typeArray.push_back(typeVector); // all layers are the same, so we copy the same vector there
      }
    // We want to combine all values into one output values, also it's range should not be restricted
    typeVector.assign(1, identity); // the last layer therefore contains a single neuron with the identity activation function
    typeArray.push_back(typeVector); // and then we add it to the type Array

    NeuralNetwork Network; //We declare a new variable for the network
    Network.Input.assign(seglength, 0); // We have to allocate memory for the network input and set it to zero
    Network.SetLayers(typeArray); // We use the type array we created before to setup the neurons in the Network
    Network.InitWeights(maxinit, maxbias); // The Weights are initialized with the two maximum values
    Network.mu = mu; // The mu value is copied to the network properties
    for (int i = 0; i < seglength; ++i) // We read in the first segment of data
      {
        inputfile >> currentinput; // read from file into variable
        Network.Input.at(i) = currentinput; // copy same value to Network input vector
      }
    reffile >> currentref;
    Network.Desired.at(0) = currentref; //For the reference we only need a single value, we take the beginning of the segment (can be changed)
    Network.CalcOutput(); // We calculate the output for the first segment
    Network.AdaptWeights(); // and adapt the weights
    // this is done outside the first loop, because we don't want to output this value

    for (int iterations = 0; iterations < maxit; ++iterations) // now we do the remaining time seriesup to maxit
      {

        inputfile >> currentinput; // read in a new input value
        reffile >> currentref; // and reference value

        rotate(Network.Input.begin(), Network.Input.begin() + 1,
            Network.Input.end()); // shift all elements so that the second becomes the first
        Network.Input.back() = currentinput; // and copy the new values to the last position

        Network.Desired.at(0) = currentref; // again set the reference
        Network.CalcOutput(); // and calculate output
        Network.AdaptWeights(); // and adapt weights

        outputfile << Network.Output.at(0) << endl; // finally write calculated output to file
        epsfile << (Network.Desired.at(0) - Network.Output.at(0)) << endl; // calculated difference and write to file as well
      }
    inputfile.close();
    reffile.close();
    outputfile.close();
    epsfile.close();

  }
