#ifndef ANISOSURFACEWAVEMODEL_H_
#define ANISOSURFACEWAVEMODEL_H_

#include "types.h"
#include <string>

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! A class to store information about anisotropic surface wave models
    /*! This class stores 1D anisotropic seismic models. At the moment
     * we use these models to calculate surface waves with AnisoSurfaceWaveSynthetic,
     * but in general it can be used for other seismic methods as well.
     */

    class AnisoSurfaceWaveModel
      {
    private:
      //! The thickness of each layer in km
      trealdata thicknesses;
      //! The P-wave velocity of each layer in km/s
      trealdata vp;
      //! The S-wave velocity of each layer in km/s
      trealdata vs;
      //! The apparent S-wave velocity of each layer in km/s
      trealdata vsapp;
      //three anisotropy coefficients
      trealdata Temp; // Temporary coefficient (-/+B)
      trealdata Temp2; // another temporary coefficient
      trealdata B;
      trealdata C;
      trealdata E;
      trealdata anisoS;
      //and two anisotropy angles
      trealdata theta;
      trealdata phi;
      trealdata angle1;
      //! The density of each layer in g/cm^3
      trealdata densities;
    public:
      //! Get read-only access to the vector of layer thicknesses in km
      const trealdata &GetThicknesses() const
        {
          return thicknesses;
        }
      //! Get read-only access to the vector of P-wave velocities in km/s
      const trealdata &GetVp() const
        {
          return vp;
        }
      //! Get read-only access to the vector of S-wave velocities in km/s
      const trealdata &GetVs() const
        {
          return vs;
        }
      //! Get read-only access to the vector of apparent S-wave velocities in km/s
      const trealdata &GetVsapp() const
        {
          return vsapp;
        }
      //! Get read-only access to the vector of S-wave velocities in km/s
      const trealdata &GetAngle1() const
        {
          return angle1;
        }
      //! Get read-only access to the vector of anisotropy coefficients for each layer
      const trealdata &GetB() const
        {
          return B;
        }
      //! Get read-only access to the vector of anisotropy coefficients for each layer
      const trealdata &GetTemp() const
        {
           return Temp;
        }
      const trealdata &GetTemp2() const
        {
           return Temp2;
        }
      //! Get read-only access to the vector of anisotropy coefficients for each layer
      const trealdata &GetC() const
        {
          return C;
        }
      //! Get read-only access to the vector of anisotropy coefficients for each layer
      const trealdata &GetE() const
        {
          return E;
        }
      //! Get read-only access to the vector of anisotropy coefficients for each layer
      const trealdata &GetAnisoS() const
        {
          return anisoS;
        }
      //! Get read-only access to the vector of anisotropy angles theta for each layer
      const trealdata &GetTheta() const
        {
          return theta;
        }
      //! Get read-only access to the vector of anisotropy angles phi for each layer
      const trealdata &GetPhi() const
        {
          return phi;
        }
      //! Get read-only access to the vector densities for each layer
      const trealdata &GetDensities() const
        {
          return densities;
        }
      //! Set the vector of layer thicknesses in km
      trealdata &SetThicknesses()
        {
          return thicknesses;
        }
      //! Set the vector of P-wave velocities in km/s
      trealdata &SetVp()
        {
          return vp;
        }
      //! Set the vector of S-wave velocities in km/s
      trealdata &SetVs()
        {
          return vs;
        }
      //! Set the vector of S-wave velocities in km/s
      trealdata &SetVsapp()
        {
          return vsapp;
        }
      //! Set the vector of S-wave velocities in km/s
      trealdata &SetAngle1()
        {
          return angle1;
        }
      //! Set the vector of anisotropy coefficients B
      trealdata &SetB()
        {
          return B;
        }
      //! Set the vector of temporary coefficient Temp
      trealdata &SetTemp()
        {
          return Temp;
        }
      //! Set the vector of temporary coefficient Temp2
      trealdata &SetTemp2()
        {
          return Temp2;
        }
      //! Set the vector of anisotropy coefficients C
      trealdata &SetC()
        {
          return C;
        }
      //! Set the vector of anisotropy coefficients E
      trealdata &SetE()
        {
          return E;
        }
      //! Set the vector of anisotropy coefficients E
      trealdata &SetAnisoS()
        {
          return anisoS;
        }
      //! Set the vector of anisotropy angles theta
      trealdata &SetTheta()
        {
          return theta;
        }
      //! Set the vector of anisotropy angles phi
      trealdata &SetPhi()
        {
          return phi;
        }
      //! Set the vector of densities
      trealdata &SetDensities()
        {
          return densities;
        }
      //! Read the model information from an ascii file with name filename
      void ReadModel(const std::string &filename);
      //! Write the model to a file with name filename
      void WriteModel(const std::string &filename) const;
      //! Write out a script that computes synthetic data for a model with name filename+.dat
      void WriteRunFile(const std::string &filename) const;
      //!Write out an ascii file for plotting the model with xmgrace
      void WritePlot(const std::string &filename) const;
      //we use the compiler generated copy constructor and operator
      AnisoSurfaceWaveModel();
      virtual ~AnisoSurfaceWaveModel();
      };
  /* @} */
  }
#endif /*ANISOSURFACEWAVEMODEL_H_*/
