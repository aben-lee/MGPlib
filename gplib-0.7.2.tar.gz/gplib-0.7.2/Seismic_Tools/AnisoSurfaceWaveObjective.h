#ifndef ANISOSURFACEWAVEOBJECTIVE_H_
#define ANISOSURFACEWAVEOBJECTIVE_H_

#include "PlottableObjective.h"
#include "ParkSurfaceWaveData.h"
#include "AnisoSurfaceWaveSynthetic.h"
#include <string>

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */
    //! This class calculates the misfit for anisotropic surface wave dispersion data
    class AnisoSurfaceWaveObjective: public PlottableObjective
      {
    private:
      ParkSurfaceWaveData MeasuredData;
      ParkSurfaceWaveData SynthData;
      AnisoSurfaceWaveSynthetic Synthetic;
      double errorlevel;
      double poisson;
      double backazimuth;
      double avelratio;
    public:

      //! Write the current model to ascii file for calculations
      virtual void WriteModel(const std::string &filename)
        {
          Synthetic.WriteModel(filename);
        }
      //! Write the current model to ascii file for plotting
      virtual void WritePlot(const std::string &filename)
        {
          Synthetic.WritePlot(filename);
        }
      //! Write synthetic data as ascii file
      virtual void WriteData(const std::string &filename)
        {
          SynthData.WriteAscii(filename);
        }
      //! Provide read only access to the synthetic data
      const ParkSurfaceWaveData &GetSynthetic() const
        {
          return SynthData;
        }
      AnisoSurfaceWaveObjective(const AnisoSurfaceWaveObjective &Old);
      AnisoSurfaceWaveObjective& operator=(
          const AnisoSurfaceWaveObjective& source);
      AnisoSurfaceWaveObjective(const ParkSurfaceWaveData &Data,
          const double ba, const double avel, const double pois = 1.8,
          const double err = 0.01);
      virtual ~AnisoSurfaceWaveObjective();
      //! We need clone and create for building an array of derived objects, see FAQ lite 20.8, the return type depends on the derived class
      virtual AnisoSurfaceWaveObjective *clone() const
        {
          return new AnisoSurfaceWaveObjective(*this);
        }
      //! Some operations cannot be done in parallel, these are done before
      virtual void PreParallel(const ttranscribed &member);
      //! Some operations cannot be done in parallel, these are done after, returns the misfit value
      virtual double PostParallel(const ttranscribed &member);
      //! The core performance calculation, has to be safe to be done in parallel
      virtual void SafeParallel(const ttranscribed &member);
      };
  /* @} */
  }
#endif /*ANISOSURFACEWAVEOBJECTIVE_H_*/
