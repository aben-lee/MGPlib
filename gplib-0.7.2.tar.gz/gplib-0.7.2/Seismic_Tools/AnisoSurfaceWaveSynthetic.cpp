#include "AnisoSurfaceWaveSynthetic.h"
#include "Util.h"

namespace gplib
  {
    void AnisoSurfaceWaveSynthetic::PreParallel(const std::string &filename)
      {
        Model->WriteRunFile(filename);
        Model->WriteModel(filename + ".mod");
      }

    ParkSurfaceWaveData AnisoSurfaceWaveSynthetic::SafeParallel(
        const std::string &filename)
      {
        const std::string fullname = filename;
        int result = std::system(("bash ./" + fullname).c_str());
        SynthData.ReadAscii(fullname + ".cvel");
        CleanFiles(fullname);
        return SynthData;
      }

    ParkSurfaceWaveData AnisoSurfaceWaveSynthetic::GetSynthData(
        const std::string &filename)
      {
        PreParallel(filename);
        return SafeParallel(filename);
      }

    AnisoSurfaceWaveSynthetic::AnisoSurfaceWaveSynthetic()
      {
      }

    AnisoSurfaceWaveSynthetic::~AnisoSurfaceWaveSynthetic()
      {
      }

  }
