#include <fstream>
#include <algorithm>
 #include <CFatalException.h>
#include "CCalcRecConf.h"
using namespace std;
void CCalcRecConf::GetData(string filename)
{
ifstream infile;
infile.open(filename.c_str());
infile.peek();
if (!infile)
  throw CFatalException("No Configurationfile found !");
 GetData(infile);infile.close();
}

void CCalcRecConf::GetData(std::ifstream &instream)
{
CCalcRecConfLexer lexer(instream);
CCalcRecConfParser parser(lexer);
parser.configfile();
cc= parser.cc;
sigma= parser.sigma;
shift= parser.shift;
recmethod= parser.recmethod;
normalize= parser.normalize;
}

void CCalcRecConf::WriteData(string filename)
{
ofstream confout(filename.c_str());
WriteData(confout);}

void CCalcRecConf::WriteData(std::ofstream &outstream)
{
outstream << "cc"  << "=" ;
outstream << cc << endl;
outstream << "sigma"  << "=" ;
outstream << sigma << endl;
outstream << "shift"  << "=" ;
outstream << shift << endl;
outstream << "recmethod"  << "=" ;
outstream << recmethod << endl;
outstream << "normalize"  << "=" ;
outstream << (normalize ? "true" : "false") << endl;
}

