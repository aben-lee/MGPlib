 #include <string>
 #include "CCalcRecConfParser.hpp"
 #include "CCalcRecConfLexer.hpp"

 class CCalcRecConf{
public: 
void GetData(std::ifstream &instream);
void GetData(std::string filename);
void WriteData(std::ofstream &outstream);
void WriteData(std::string filename);
double cc;
double sigma;
int shift;
std::string recmethod;
bool normalize;
CCalcRecConf(std::string filename){GetData(filename);}
CCalcRecConf(){}
};
