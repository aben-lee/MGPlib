#ifndef CFKMODEL_H
#define CFKMODEL_H

#include "SeismicModel.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! A model for forward calculations with a wavenumber integration code, currently not in use and might be removed in a later version
    class FkModel: public SeismicModel
      {
    private:
      trealdata RecDist;
    public:
      //! Read-only access to the vector of receiver distances
      const trealdata &GetRecDist() const
        {
          return RecDist;
        }
      //! Read-write access to the vector of receiver distances
      trealdata &SetRecDist()
        {
          return RecDist;
        }
      //! Read the model in its native format from a file
      virtual void ReadModel(const std::string filename);
      //! Write the model in its native format to a file
      virtual void WriteModel(const std::string filename);
      FkModel();
      virtual ~FkModel();
      };
  /* @} */
  }
#endif // CFKMODEL_H
