#ifndef MOVEOUTCORRECTION_H_
#define MOVEOUTCORRECTION_H_
#include "SeismicDataComp.h"
#include "ResPkModel.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    class MoveoutCorrection
      {
    private:
      double refslowness;
      ResPkModel Model;
      double CalcTraveltime(const double rayparameter, const double depth);
      void InterpolateTo(trealdata &oldx, trealdata &y, trealdata &newx,
          trealdata &newy);
    public:
      void DoCorrection(SeismicDataComp &Rec, const double slowness);
      MoveoutCorrection(const double refslow, const ResPkModel &TheModel);
      virtual ~MoveoutCorrection()
        {
        }
      };
  /* @} */
  }
#endif /*MOVEOUTCORRECTION_H_*/
