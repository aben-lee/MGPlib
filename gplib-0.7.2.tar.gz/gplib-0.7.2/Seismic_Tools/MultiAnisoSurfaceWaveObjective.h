#ifndef MULTIANISOSURFACEWAVEOBJECTIVE_H_
#define MULTIANISOSURFACEWAVEOBJECTIVE_H_

#include "GeneralObjective.h"
#include "AnisoSurfaceWaveObjective.h"
#include <vector>
#include <boost/shared_ptr.hpp>
namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */
    //! Minimize the misfit for several surface wave dispersion curves simultaneously
    class MultiAnisoSurfaceWaveObjective: public GeneralObjective
      {
    private:
      std::vector<boost::shared_ptr<AnisoSurfaceWaveObjective> >
          IndividualObjectives;
      std::vector<double> backazimuths;
    public:
      virtual MultiAnisoSurfaceWaveObjective *clone() const
        {
          return new MultiAnisoSurfaceWaveObjective(*this);
        }
      void AddMeasurement(const ParkSurfaceWaveData &Measured,
          const double back, const double avel);
      //! Some operations cannot be done in parallel, these are done before
      virtual void PreParallel(const ttranscribed &member);
      //! Some operations cannot be done in parallel, these are done after, returns the misfit value
      virtual double PostParallel(const ttranscribed &member);
      //! The core performance calculation, has to be safe to be done in parallel
      virtual void SafeParallel(const ttranscribed &member);
      void WriteData(const std::string &filename);
      void WriteModel(const std::string &filename);
      void WritePlot(const std::string &filename);
      MultiAnisoSurfaceWaveObjective(const MultiAnisoSurfaceWaveObjective &Old);
      MultiAnisoSurfaceWaveObjective& operator=(
          const MultiAnisoSurfaceWaveObjective& source);
      MultiAnisoSurfaceWaveObjective();
      virtual ~MultiAnisoSurfaceWaveObjective();
      };
  /* @} */
  }
#endif /*MULTIANISOSURFACEWAVEOBJECTIVE_H_*/
