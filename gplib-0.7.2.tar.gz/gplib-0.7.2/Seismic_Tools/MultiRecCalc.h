#ifndef MULTIRECCALC_H_
#define MULTIRECCALC_H_
#include "SeismicDataComp.h"
#include "SeismicStationList.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! This class implements the multi-site receiver function calculation in the frequency domain as suggested by Gurrolla 1995
    class MultiRecCalc
      {
    private:
      //! The waterlevel to fill in spectral holes
      double c;
      //! The width of the gaussian filter to smooth the receiver functions
      double sigma;
      //! Shift the data to move the initial correlation peak
      int shift;
      //! Calculate the receiver function by spectral division
    public:
      //! Calculate Receiver functions from a vector of data components, both vectors have to have the same number of elements
      //! and the seismograms have to have the same length
      void CalcRecData(const SeismicStationList::tseiscompvector &RadComp,
          const SeismicStationList::tseiscompvector &VerComp,
          SeismicDataComp &Receiver);
      MultiRecCalc(const int myshift, const double mysigma, const double myc);
      virtual ~MultiRecCalc();
      };
  /* @} */
  }
#endif /*MULTIRECCALC_H_*/
