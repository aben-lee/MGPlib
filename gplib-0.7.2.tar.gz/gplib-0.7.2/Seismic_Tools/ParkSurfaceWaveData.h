#ifndef PARKSURFACEWAVEDATA_H_
#define PARKSURFACEWAVEDATA_H_

#include <vector>
#include <string>
#include <boost/cstdint.hpp>
#include "SurfaceWaveData.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    class ParkSurfaceWaveData: public SurfaceWaveData
      {
    public:
      virtual void ReadAscii(const std::string &filename);
      virtual void WriteAscii(const std::string &filename) const;
      ParkSurfaceWaveData();
      virtual ~ParkSurfaceWaveData();
      };
  /* @} */
  }
#endif /*PARKSURFACEWAVEDATA_H_*/
