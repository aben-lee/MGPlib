#ifndef RFVELCALC_H_
#define RFVELCALC_H_
#include "RecCalc.h"
#include "SeismicDataComp.h"
#include <string>

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! This class implements the method to calculate absolute S-Wave velocities from Receiver function data as described by Sevnningsen and Jacobsen, GJI 2007
    class RFVelCalc
      {
    private:
      RecCalc RFCalculator;
      ttsdata Velocities;
      ttsdata Periods;
      //! The core estimation routine, take radial and vertical receiver functions
      void AbsVelCalc(const double slowness, const SeismicDataComp &RadRec,
          const SeismicDataComp &VerRec, ttsdata &AppVel);
    public:
      //! return the vector of apparent velocities
      const ttsdata &GetVelocities()
        {
          return Velocities;
        }
      //! Calculate absolute velocities from the radial and vertical components of the seismogram
      void CalcRFVel(const double slowness, const SeismicDataComp &RadComp,
          const SeismicDataComp &VerComp, ttsdata &AppVel);
      //!Calculate absolute velocities from the radial receiver function and the vertical component of the seismogram
      void CalcRFVelFromRec(const double slowness, const SeismicDataComp &RRec,
          const SeismicDataComp &VerComp, ttsdata &AppVel);
      //! Write the velocity estiamtes and corresponding periods into an ascii file
      void WriteVelocities(const std::string filename);
      //!  The constructor takes three parameters for the receiver function estimation
      /*!  The constructor takes three parameters for the receiver function estimation
       * @param mysigma The width of the gaussian filter used in calculating the receiver function
       * @param myc The waterlevel, only relevant if spectral division is used for RF calculation
       * @param themethod Do we want to calculate the RF with spectral division of iterative deconvolution
       * @return
       */
      RFVelCalc(const double mysigma, const double myc,
          const RecCalc::trfmethod themethod = RecCalc::specdiv);
      RFVelCalc& operator=(const RFVelCalc& source);
      RFVelCalc(const RFVelCalc &Old);
      virtual ~RFVelCalc();
      };
  /* @} */
  }
#endif /*RFVELCALC_H_*/
