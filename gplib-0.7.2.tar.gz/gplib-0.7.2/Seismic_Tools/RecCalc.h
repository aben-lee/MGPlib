#ifndef CRECFUNC_H
#define CRECFUNC_H
#include "SeismicDataComp.h"
#include "ResPkModel.h"
#include "TsSpectrum.h"
#include <string>

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! This class is used to calculate receiver functions from seismic data
    class RecCalc
      {
    public:
      //! There are several ways to calculate receiver functions
      enum trfmethod
        {
        specdiv, iterdecon
        };
    private:
      //! The method we want to use to calculate the receiver function
      trfmethod method;
      //! For spectral division we need an object to calculate spectra
      TsSpectrum Spectrum;
      //! The waterlevel to fill in spectral holes
      double c;
      //! The width of the gaussian filter to smooth the receiver functions
      double sigma;
      //! Shift the data to move the initial correlation peak
      int shift;
      //! Should the receiver function be normalized to maximum amplitude
      bool normalize;
      //! The components used for the receiver function calculation
      SeismicDataComp RadComp;
      SeismicDataComp VerComp;
      //! Calculate the receiver function with the spectral division waterlevel method
      void SpectralDivision(const SeismicDataComp &RComp,
          const SeismicDataComp &VComp, SeismicDataComp &Receiver);
      //! Calculate the receiver function by iterative convolution
      void IterativeDeconvolution(const SeismicDataComp &RComp,
          const SeismicDataComp &VComp, SeismicDataComp &Receiver);
    public:
      //! Get the radial component, mostly needed for synthetic data
      const SeismicDataComp &GetRadComp()
        {
          return RadComp;
        }
      const SeismicDataComp &GetVerComp()
        {
          return VerComp;
        }
      //! Change whether the output receiver function is normalized to a maximum amplitude of 1
      void SetNormalize(const bool what)
        {
          normalize = what;
        }
      //! The three Synth*Parallel methods provide alternative acces to the steps in CalcRecSynth for safe parallel execution
      void SynthPreParallel(const std::string &filename, ResPkModel &Model,
          SeismicDataComp &Receiver, const bool cleanfiles = false);
      //! All operations that are safe to execute in parallel
      void SynthSafeParallel(const std::string &filename, ResPkModel &Model,
          SeismicDataComp &Receiver, const bool cleanfiles = false);
      //! Operations of the synthetic receiver function calculation that are not safe in parallel and hafe to be executed after the parallel part
      void SynthPostParallel(const std::string &filename, ResPkModel &Model,
          SeismicDataComp &Receiver, const bool cleanfiles = false);
      //! Calculate Receiver functions from two data components
      void CalcRecData(const SeismicDataComp &RadComp,
          const SeismicDataComp &VerComp, SeismicDataComp &Receiver);
      //! Calculate synthetic receiver funtions from a model
      void CalcRecSynth(const std::string &filename, ResPkModel &Model,
          SeismicDataComp &Receiver, const bool cleanfiles = false);
      RecCalc& operator=(const RecCalc& source);
      //! The constructor takes the essential parameters that shouldn't change during different calculations
      RecCalc(int myshift, double mysigma, double myc,
          bool multicalc = false, trfmethod themethod = iterdecon);
      RecCalc(const RecCalc &Old);
      virtual ~RecCalc();
      };
  /* @} */
  }
#endif // CRECFUNC_H
