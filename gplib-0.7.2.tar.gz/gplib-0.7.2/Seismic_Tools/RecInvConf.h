//============================================================================
// Name        : RecInvConf.h
// Author      : Apr 7, 2010
// Version     : 
// Copyright   : 2010, mmoorkamp
//============================================================================


#ifndef RECINVCONF_H_
#define RECINVCONF_H_

#include <fstream>
#include <string>

namespace gplib
  {

    class RecInvConf
      {
    public:
      std::string recinfofile;
      std::string recmethod;
      bool normrec;
      int recfitexponent;
      double starttime;
      double endtime;
      void GetData(std::ifstream &instream);
      RecInvConf();
      virtual ~RecInvConf();
      };

  }

#endif /* RECINVCONF_H_ */
