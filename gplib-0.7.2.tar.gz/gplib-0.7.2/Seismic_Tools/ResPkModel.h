#ifndef CRESPKMODEL_H
#define CRESPKMODEL_H

#include <vector>
#include "SeismicModel.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! This class stores and writes model for the respktn 1D seismic code that we use for receiver function calculations
    /*! Our joint inversion uses respktn from C. Ammon to calculate synthetics for receiver function inversion.
     * This class stores the description of this model and provides methods to read such models, write such models
     * and generate scripts that calculate synthetic for such a model.
     *
     */
    class ResPkModel: public SeismicModel
      {
    public:
      enum WaveType
        {
        SWave, PWave
        };
    private:
      double slowness;
      WaveType InputWave;
      trealdata Strike;
      trealdata Dip;
    public:
      void SetInputWave(WaveType w)
        {
          InputWave = w;
        }
      //! Get the slowness in s/km for the synthetic forward calculation
      double GetSlowness() const
        {
          return slowness;
        }
      //! Set the slowness in s/km for the synthetic forward calculation
      void SetSlowness(const double s)
        {
          slowness = s;
        }
      //! Read-only access to the vector of Strikes in each layer
      const trealdata &GetStrike() const
        {
          return Strike;
        }
      //! Read-write access to the vector of Strikes in each layer
      trealdata &SetStrike()
        {
          return Strike;
        }
      //! Read-only access to the vector of Dips in each layer
      const trealdata &GetDip() const
        {
          return Dip;
        }
      //! Read-write access to the vector of Dips in each layer
      trealdata &SetDip()
        {
          return Dip;
        }
      //! Read the model in its native format from a file
      virtual void ReadModel(const std::string filename);
      //! Write the model in its native format to a file
      virtual void WriteModel(const std::string filename);
      //! Write out a script that performs a forward calculation for the current model
      virtual void WriteRunFile(const std::string &filename);
      ResPkModel();
      ResPkModel(const int nlayers);
      ResPkModel(const SeismicModel& source);
      ResPkModel(const ResPkModel& source);
      ResPkModel& operator=(const ResPkModel& source);
      virtual ~ResPkModel();
      };
  /* @} */
  }
#endif // CRESPKMODEL_H
