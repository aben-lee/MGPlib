#ifndef SWANISOTROUGHNESS_H_
#define SWANISOTROUGHNESS_H_
#include "GeneralObjective.h"

namespace gplib
  {
//! Calculate the roughness for anisotropic SW models
class SWAnisoRoughness: public GeneralObjective
{
private:
	double veldiffweight;
	double anisovelweight;
	double strikediffweight;
	double deltastrikediffweight;
public:
        //! Regularize the velocity change across the layers. This is zero by default
	void SetVelDiffWeight(const double w){veldiffweight =w;}
	//! Regularize the anisotropy of the velocities. This is 1 by default
	void SetAnisovelWeight(const double w){anisovelweight = w;}
	//! Regularize the difference in anisotropy strike across layers. This is zero by default
	void SetStrikeDiffWeight(const double w){strikediffweight =w;}
	//! Regularize the difference between the seismic and electric strike. This is zero by default
	void SetDeltaStrikeDiffWeight(const double w){deltastrikediffweight = w;}
	virtual SWAnisoRoughness *clone() const {return new SWAnisoRoughness(*this);}
	virtual void SafeParallel(const ttranscribed &member);
	virtual double PostParallel(const ttranscribed &member);
	SWAnisoRoughness(const SWAnisoRoughness &Old);
	SWAnisoRoughness& operator=(const SWAnisoRoughness& source);
	SWAnisoRoughness();
	virtual ~SWAnisoRoughness();
};
}
#endif /*SWANISOROUGHNESS_H_*/
