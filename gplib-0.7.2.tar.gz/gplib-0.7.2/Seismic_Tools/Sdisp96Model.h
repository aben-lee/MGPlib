#ifndef SDISP96MODEL_H_
#define SDISP96MODEL_H_

#include "SurfaceWaveModel.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! This class can write files specific for the synthetic surface wave codes that are part of the computer programs in seismology
    class Sdisp96Model: public SurfaceWaveModel
      {
    private:
      bool isSpherical;
    public:
      //! Do we want a spherical model or a flat earth model
      void SetSpherical(const bool s)
        {
          isSpherical = s;
        }
      //! Read the model from a file
      virtual void ReadModel(const std::string &filename);
      //! Write them model to a file so that the forward codes can use it
      virtual void WriteModel(const std::string &filename) const;
      //! Write out a script file that when run creates synthetic data with the name filename+'.asc'
      virtual void WriteRunFile(const std::string &filename, const std::vector<
          double> periods) const;
      Sdisp96Model& operator=(const Sdisp96Model& source);
      Sdisp96Model(const Sdisp96Model &Old);
      Sdisp96Model(const SurfaceWaveModel &Old) :
        SurfaceWaveModel(Old)
        {
        }
      ;
      Sdisp96Model();
      virtual ~Sdisp96Model();
      };
  /* @} */
  }
#endif /*SDISP96MODEL_H_*/
