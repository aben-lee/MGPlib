#ifndef CSEISMICDATACOMP_H
#define CSEISMICDATACOMP_H
#include <string>
#include "types.h" 
#include "TimeSeriesComponent.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    class SeismicDataComp: public TimeSeriesComponent
      {
    public:
      enum tseismicdataformat
        {
        unknownseis, sac, sks, head, ascii
        };
      double GetB() const
        {
          return b;
        }
      void SetB(const double theb)
        {
          b = theb;
        }
      tseismicdataformat GetFormat()
        {
          return dataformat;
        }
      //! Return the latitude of the station
      double GetStLa() const
        {
          return stla;
        }
      //! Set the latitude of the station
      void SetStLa(const double lat)
        {
          stla = lat;
        }
      //! Get the longitude of the station
      double GetStLo() const
        {
          return stlo;
        }
      //! Set the longitude of the station
      void SetStLo(const double lon)
        {
          stla = lon;
        }
      //! Get the elevation of the station in m
      double GetStEl() const
        {
          return stel;
        }
      //! Get the depth of the station below the ground in m
      double GetStDp() const
        {
          return stdp;
        }
      //! Get the latitude of the event
      double GetEvLa() const
        {
          return evla;
        }
      //! Get the longitude of the event
      double GetEvLo() const
        {
          return evlo;
        }
      //! Get the elevation of the event
      double GetEvEl() const
        {
          return evel;
        }
      //! Get the depth of the event
      double GetEvDp() const
        {
          return evdp;
        }
      //! Get the magnitude of the event
      double GetMag() const
        {
          return mag;
        }
      //! Get the distance between event and station
      double GetDist() const
        {
          return dist;
        }
      //! Get the azimuth of the event
      double GetAz() const
        {
          return az;
        }
      //! Get the back-azimuth of the event
      double GetBaz() const
        {
          return baz;
        }
      //! Get the distance between station and event along a great circle
      double GetGcarc() const
        {
          return gcarc;
        }
      //! Read in data from a file, as we cannot determine the type from the ending we have to provide it
      int
          ReadData(const std::string &filename, tseismicdataformat format = sac);
      //! Write the data in sac binary format
      int WriteAsSac(const std::string &filename) const;
      //! Write the data in plain ascii format
      int WriteAsAscii(const std::string &filename) const;
      //! Write the data in the format it was read in and with the same filename
      int WriteBack() const;
      //! Copy the information in the header from another object
      void CopyHeader(const SeismicDataComp& source);
      SeismicDataComp(const std::string &filename, tseismicdataformat format =
          sac);
      SeismicDataComp();
      virtual ~SeismicDataComp();
      virtual SeismicDataComp& operator=(const SeismicDataComp& source);
    private:
      double stla;
      double stlo;
      double stel;
      double stdp;
      double evla;
      double evlo;
      double evel;
      double evdp;
      double mag;
      double dist;
      double az;
      double baz;
      double gcarc;
      //std::string name;
      double b; // Time Shift between origin time of eq and beginning of data
      //ttsdata Data;
      tseismicdataformat dataformat;
      void ReadSac(const std::string &filename);
      void ReadHeaderAscii(const std::string &filename);
      void ReadSKS(const std::string &filename);
      void ReadAscii(const std::string &filename);
      };
  /* @} */
  }
#endif // CSEISMICDATACOMP_H
