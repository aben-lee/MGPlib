#include "SeismicStationList.h"
#include "StationParser.h"
#include <fstream>
#include <iomanip>
using namespace std;

namespace gplib
  {
    SeismicStationList::SeismicStationList()
      {
      }

    SeismicStationList::~SeismicStationList()
      {
      }

    void SeismicStationList::ReadList(const std::string filename)
      {
        ifstream infile(filename.c_str());
        //we open file, check whether it opened OK
        if (infile)
          {
            StationParser parser;
            parser.ParseFile(infile);
            for (unsigned int i = 0; i < parser.Stationnames.size(); ++i)
              {
                //show information about each file
                cout << "Working on file " << parser.Stationnames.at(i) << endl;
                //create a shared pointer object
                boost::shared_ptr<SeismicDataComp> CurrentStation(
                    new SeismicDataComp);
                //and read in the data from the specified file
                CurrentStation->ReadData(parser.Stationnames.at(i));
                //we can optionally specify latitude and longitude information
                if (parser.HasLatLong.at(i))
                  {
                    //this overrides the information in the file
                    CurrentStation->SetStLo(parser.Longitudes.at(i));
                    CurrentStation->SetStLa(parser.Latitudes.at(i));
                  }
                StationList.push_back(CurrentStation);
              }
          }
        else
          {
            throw("File not found: " + filename);
          }
      }

    void SeismicStationList::WriteList(const std::string filename)
      {
        ofstream outfile(filename.c_str());
        //go through the vector of seismic component objects
        for (tseiscompvector::iterator CurrentStation = StationList.begin(); CurrentStation
            != StationList.end(); CurrentStation++)
          {
            //write out name, longitude and latitude with some formatting
            outfile << CurrentStation->get()->GetName();
            outfile << setfill(' ') << setw(15) << resetiosflags(ios::fixed);
            outfile << CurrentStation->get()->GetStLo() << " ";
            outfile << setfill(' ') << setw(15) << resetiosflags(ios::fixed);
            outfile << CurrentStation->get()->GetStLa();
            outfile << endl;
          }
      }

    void SeismicStationList::WriteAllData()
      {
        //go through the vector of seismic components
        //and write each one in the format it was read in
        for (tseiscompvector::iterator CurrentStation = StationList.begin(); CurrentStation
            != StationList.end(); CurrentStation++)
          CurrentStation->get()->WriteBack();
      }
  }
