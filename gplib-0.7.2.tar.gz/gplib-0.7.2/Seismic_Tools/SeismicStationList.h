#ifndef SEISMICSTATIONLIST_H_
#define SEISMICSTATIONLIST_H_
#include <vector>
#include <boost/shared_ptr.hpp>
#include "SeismicDataComp.h"

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! Manages a collection of seismic traces, mainly provides functionality to read in data specified in a file with names
    class SeismicStationList
      {
    public:
      typedef std::vector<boost::shared_ptr<SeismicDataComp> > tseiscompvector;
    private:
      tseiscompvector StationList;
    public:
      //! Return the content of the list for manipulation
      tseiscompvector &GetList()
        {
          return StationList;
        }
      //! return a read only version of thelist
      const tseiscompvector &GetList() const
        {
          return StationList;
        }
      //! read in a file with names and optionally coordinates
      void ReadList(const std::string filename);
      //! Write out a file with the names of the files in the current list
      void WriteList(const std::string filename = "station.list");
      //! Write out the data of the files in the list
      void WriteAllData();
      SeismicStationList();
      virtual ~SeismicStationList();
      };
  /* @} */
  }
#endif /*SEISMICSTATIONLIST_H_*/
