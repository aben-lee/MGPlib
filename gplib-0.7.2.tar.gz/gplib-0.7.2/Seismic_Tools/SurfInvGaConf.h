 #include <string>
 #include "SurfInvGaConfParser.hpp"
 #include "SurfInvGaConfLexer.hpp"

 class SurfInvGaConf{
public: 
void GetData(std::ifstream &instream);
void GetData(std::string filename);
void WriteData(std::ofstream &outstream);
void WriteData(std::string filename);
bool verbose;
bool usevrefmodel;
std::string vrefmodel;
std::string backgroundmodel;
int fitexponent;
int popsize;
double inittemp;
double coolingratio;
int generations;
double mutationprob;
double crossoverprob;
double poisson;
int threads;
double errorlevel;
std::string gatype;
std::string outputbase;
std::string inputdata;
int annealinggeneration;
bool elitist;
std::vector< double > thickbase;
std::vector< double > thickstep;
std::vector< int > thicksizes;
std::vector< double > svelbase;
std::vector< double > svelstep;
std::vector< int > svelsizes;
std::vector< double > weights;
SurfInvGaConf(std::string filename){GetData(filename);}
SurfInvGaConf(){}
};
