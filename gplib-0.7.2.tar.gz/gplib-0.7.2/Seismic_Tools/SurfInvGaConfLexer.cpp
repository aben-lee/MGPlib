/* $ANTLR 2.7.7 (2006-11-01): "SurfInvGaConf.g" -> "SurfInvGaConfLexer.cpp"$ */
#include "SurfInvGaConfLexer.hpp"
#include <antlr/CharBuffer.hpp>
#include <antlr/TokenStreamException.hpp>
#include <antlr/TokenStreamIOException.hpp>
#include <antlr/TokenStreamRecognitionException.hpp>
#include <antlr/CharStreamException.hpp>
#include <antlr/CharStreamIOException.hpp>
#include <antlr/NoViableAltForCharException.hpp>

#line 1 "SurfInvGaConf.g"
#line 13 "SurfInvGaConfLexer.cpp"
SurfInvGaConfLexer::SurfInvGaConfLexer(std::istream& in)
	: antlr::CharScanner(new antlr::CharBuffer(in),false)
{
	initLiterals();
}

SurfInvGaConfLexer::SurfInvGaConfLexer(antlr::InputBuffer& ib)
	: antlr::CharScanner(ib,false)
{
	initLiterals();
}

SurfInvGaConfLexer::SurfInvGaConfLexer(const antlr::LexerSharedInputState& state)
	: antlr::CharScanner(state,false)
{
	initLiterals();
}

void SurfInvGaConfLexer::initLiterals()
{
}

antlr::RefToken SurfInvGaConfLexer::nextToken()
{
	antlr::RefToken theRetToken;
	for (;;) {
		antlr::RefToken theRetToken;
		int _ttype = antlr::Token::INVALID_TYPE;
		resetText();
		try {   // for lexical and char stream error handling
			switch ( LA(1)) {
			case 0x3d /* '=' */ :
			{
				mEQUAL(true);
				theRetToken=_returnToken;
				break;
			}
			case 0x9 /* '\t' */ :
			case 0xa /* '\n' */ :
			case 0xd /* '\r' */ :
			case 0x20 /* ' ' */ :
			{
				mWS(true);
				theRetToken=_returnToken;
				break;
			}
			case 0x2b /* '+' */ :
			case 0x2d /* '-' */ :
			case 0x2e /* '.' */ :
			case 0x30 /* '0' */ :
			case 0x31 /* '1' */ :
			case 0x32 /* '2' */ :
			case 0x33 /* '3' */ :
			case 0x34 /* '4' */ :
			case 0x35 /* '5' */ :
			case 0x36 /* '6' */ :
			case 0x37 /* '7' */ :
			case 0x38 /* '8' */ :
			case 0x39 /* '9' */ :
			{
				mNUMBER(true);
				theRetToken=_returnToken;
				break;
			}
			case 0x2f /* '/' */ :
			{
				mCOMMENT(true);
				theRetToken=_returnToken;
				break;
			}
			default:
				if ((LA(1) == 0x75 /* 'u' */ ) && (LA(2) == 0x73 /* 's' */ ) && (LA(3) == 0x65 /* 'e' */ ) && (LA(4) == 0x76 /* 'v' */ ) && (LA(5) == 0x72 /* 'r' */ ) && (LA(6) == 0x65 /* 'e' */ ) && (LA(7) == 0x66 /* 'f' */ ) && (LA(8) == 0x6d /* 'm' */ ) && (LA(9) == 0x6f /* 'o' */ ) && (LA(10) == 0x64 /* 'd' */ )) {
					mUSEVREFMODELT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x62 /* 'b' */ ) && (LA(2) == 0x61 /* 'a' */ ) && (LA(3) == 0x63 /* 'c' */ ) && (LA(4) == 0x6b /* 'k' */ ) && (LA(5) == 0x67 /* 'g' */ ) && (LA(6) == 0x72 /* 'r' */ ) && (LA(7) == 0x6f /* 'o' */ ) && (LA(8) == 0x75 /* 'u' */ ) && (LA(9) == 0x6e /* 'n' */ ) && (LA(10) == 0x64 /* 'd' */ )) {
					mBACKGROUNDMODELT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x66 /* 'f' */ ) && (LA(2) == 0x69 /* 'i' */ ) && (LA(3) == 0x74 /* 't' */ ) && (LA(4) == 0x65 /* 'e' */ ) && (LA(5) == 0x78 /* 'x' */ ) && (LA(6) == 0x70 /* 'p' */ ) && (LA(7) == 0x6f /* 'o' */ ) && (LA(8) == 0x6e /* 'n' */ ) && (LA(9) == 0x65 /* 'e' */ ) && (LA(10) == 0x6e /* 'n' */ )) {
					mFITEXPONENTT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x63 /* 'c' */ ) && (LA(2) == 0x6f /* 'o' */ ) && (LA(3) == 0x6f /* 'o' */ ) && (LA(4) == 0x6c /* 'l' */ ) && (LA(5) == 0x69 /* 'i' */ ) && (LA(6) == 0x6e /* 'n' */ ) && (LA(7) == 0x67 /* 'g' */ ) && (LA(8) == 0x72 /* 'r' */ ) && (LA(9) == 0x61 /* 'a' */ ) && (LA(10) == 0x74 /* 't' */ )) {
					mCOOLINGRATIOT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x67 /* 'g' */ ) && (LA(2) == 0x65 /* 'e' */ ) && (LA(3) == 0x6e /* 'n' */ ) && (LA(4) == 0x65 /* 'e' */ ) && (LA(5) == 0x72 /* 'r' */ ) && (LA(6) == 0x61 /* 'a' */ ) && (LA(7) == 0x74 /* 't' */ ) && (LA(8) == 0x69 /* 'i' */ ) && (LA(9) == 0x6f /* 'o' */ ) && (LA(10) == 0x6e /* 'n' */ )) {
					mGENERATIONST(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x6d /* 'm' */ ) && (LA(2) == 0x75 /* 'u' */ ) && (LA(3) == 0x74 /* 't' */ ) && (LA(4) == 0x61 /* 'a' */ ) && (LA(5) == 0x74 /* 't' */ ) && (LA(6) == 0x69 /* 'i' */ ) && (LA(7) == 0x6f /* 'o' */ ) && (LA(8) == 0x6e /* 'n' */ ) && (LA(9) == 0x70 /* 'p' */ ) && (LA(10) == 0x72 /* 'r' */ )) {
					mMUTATIONPROBT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x63 /* 'c' */ ) && (LA(2) == 0x72 /* 'r' */ ) && (LA(3) == 0x6f /* 'o' */ ) && (LA(4) == 0x73 /* 's' */ ) && (LA(5) == 0x73 /* 's' */ ) && (LA(6) == 0x6f /* 'o' */ ) && (LA(7) == 0x76 /* 'v' */ ) && (LA(8) == 0x65 /* 'e' */ ) && (LA(9) == 0x72 /* 'r' */ ) && (LA(10) == 0x70 /* 'p' */ )) {
					mCROSSOVERPROBT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x65 /* 'e' */ ) && (LA(2) == 0x72 /* 'r' */ ) && (LA(3) == 0x72 /* 'r' */ ) && (LA(4) == 0x6f /* 'o' */ ) && (LA(5) == 0x72 /* 'r' */ ) && (LA(6) == 0x6c /* 'l' */ ) && (LA(7) == 0x65 /* 'e' */ ) && (LA(8) == 0x76 /* 'v' */ ) && (LA(9) == 0x65 /* 'e' */ ) && (LA(10) == 0x6c /* 'l' */ )) {
					mERRORLEVELT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x6f /* 'o' */ ) && (LA(2) == 0x75 /* 'u' */ ) && (LA(3) == 0x74 /* 't' */ ) && (LA(4) == 0x70 /* 'p' */ ) && (LA(5) == 0x75 /* 'u' */ ) && (LA(6) == 0x74 /* 't' */ ) && (LA(7) == 0x62 /* 'b' */ ) && (LA(8) == 0x61 /* 'a' */ ) && (LA(9) == 0x73 /* 's' */ ) && (LA(10) == 0x65 /* 'e' */ )) {
					mOUTPUTBASET(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x61 /* 'a' */ ) && (LA(2) == 0x6e /* 'n' */ ) && (LA(3) == 0x6e /* 'n' */ ) && (LA(4) == 0x65 /* 'e' */ ) && (LA(5) == 0x61 /* 'a' */ ) && (LA(6) == 0x6c /* 'l' */ ) && (LA(7) == 0x69 /* 'i' */ ) && (LA(8) == 0x6e /* 'n' */ ) && (LA(9) == 0x67 /* 'g' */ ) && (LA(10) == 0x67 /* 'g' */ )) {
					mANNEALINGGENERATIONT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x74 /* 't' */ ) && (LA(2) == 0x68 /* 'h' */ ) && (LA(3) == 0x69 /* 'i' */ ) && (LA(4) == 0x63 /* 'c' */ ) && (LA(5) == 0x6b /* 'k' */ ) && (LA(6) == 0x73 /* 's' */ ) && (LA(7) == 0x69 /* 'i' */ ) && (LA(8) == 0x7a /* 'z' */ ) && (LA(9) == 0x65 /* 'e' */ ) && (LA(10) == 0x73 /* 's' */ )) {
					mTHICKSIZEST(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x76 /* 'v' */ ) && (LA(2) == 0x72 /* 'r' */ ) && (LA(3) == 0x65 /* 'e' */ ) && (LA(4) == 0x66 /* 'f' */ ) && (LA(5) == 0x6d /* 'm' */ ) && (LA(6) == 0x6f /* 'o' */ ) && (LA(7) == 0x64 /* 'd' */ ) && (LA(8) == 0x65 /* 'e' */ ) && (LA(9) == 0x6c /* 'l' */ ) && (true)) {
					mVREFMODELT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x69 /* 'i' */ ) && (LA(2) == 0x6e /* 'n' */ ) && (LA(3) == 0x70 /* 'p' */ ) && (LA(4) == 0x75 /* 'u' */ ) && (LA(5) == 0x74 /* 't' */ ) && (LA(6) == 0x64 /* 'd' */ ) && (LA(7) == 0x61 /* 'a' */ ) && (LA(8) == 0x74 /* 't' */ ) && (LA(9) == 0x61 /* 'a' */ ) && (true)) {
					mINPUTDATAT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x74 /* 't' */ ) && (LA(2) == 0x68 /* 'h' */ ) && (LA(3) == 0x69 /* 'i' */ ) && (LA(4) == 0x63 /* 'c' */ ) && (LA(5) == 0x6b /* 'k' */ ) && (LA(6) == 0x62 /* 'b' */ ) && (LA(7) == 0x61 /* 'a' */ ) && (LA(8) == 0x73 /* 's' */ ) && (LA(9) == 0x65 /* 'e' */ ) && (true)) {
					mTHICKBASET(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x74 /* 't' */ ) && (LA(2) == 0x68 /* 'h' */ ) && (LA(3) == 0x69 /* 'i' */ ) && (LA(4) == 0x63 /* 'c' */ ) && (LA(5) == 0x6b /* 'k' */ ) && (LA(6) == 0x73 /* 's' */ ) && (LA(7) == 0x74 /* 't' */ ) && (LA(8) == 0x65 /* 'e' */ ) && (LA(9) == 0x70 /* 'p' */ ) && (true)) {
					mTHICKSTEPT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x73 /* 's' */ ) && (LA(2) == 0x76 /* 'v' */ ) && (LA(3) == 0x65 /* 'e' */ ) && (LA(4) == 0x6c /* 'l' */ ) && (LA(5) == 0x73 /* 's' */ ) && (LA(6) == 0x69 /* 'i' */ ) && (LA(7) == 0x7a /* 'z' */ ) && (LA(8) == 0x65 /* 'e' */ ) && (LA(9) == 0x73 /* 's' */ ) && (true)) {
					mSVELSIZEST(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x69 /* 'i' */ ) && (LA(2) == 0x6e /* 'n' */ ) && (LA(3) == 0x69 /* 'i' */ ) && (LA(4) == 0x74 /* 't' */ ) && (LA(5) == 0x74 /* 't' */ ) && (LA(6) == 0x65 /* 'e' */ ) && (LA(7) == 0x6d /* 'm' */ ) && (LA(8) == 0x70 /* 'p' */ ) && (true) && (true)) {
					mINITTEMPT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x73 /* 's' */ ) && (LA(2) == 0x76 /* 'v' */ ) && (LA(3) == 0x65 /* 'e' */ ) && (LA(4) == 0x6c /* 'l' */ ) && (LA(5) == 0x62 /* 'b' */ ) && (LA(6) == 0x61 /* 'a' */ ) && (LA(7) == 0x73 /* 's' */ ) && (LA(8) == 0x65 /* 'e' */ ) && (true) && (true)) {
					mSVELBASET(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x73 /* 's' */ ) && (LA(2) == 0x76 /* 'v' */ ) && (LA(3) == 0x65 /* 'e' */ ) && (LA(4) == 0x6c /* 'l' */ ) && (LA(5) == 0x73 /* 's' */ ) && (LA(6) == 0x74 /* 't' */ ) && (LA(7) == 0x65 /* 'e' */ ) && (LA(8) == 0x70 /* 'p' */ ) && (true) && (true)) {
					mSVELSTEPT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x76 /* 'v' */ ) && (LA(2) == 0x65 /* 'e' */ ) && (LA(3) == 0x72 /* 'r' */ ) && (LA(4) == 0x62 /* 'b' */ ) && (LA(5) == 0x6f /* 'o' */ ) && (LA(6) == 0x73 /* 's' */ ) && (LA(7) == 0x65 /* 'e' */ ) && (true) && (true) && (true)) {
					mVERBOSET(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x70 /* 'p' */ ) && (LA(2) == 0x6f /* 'o' */ ) && (LA(3) == 0x70 /* 'p' */ ) && (LA(4) == 0x73 /* 's' */ ) && (LA(5) == 0x69 /* 'i' */ ) && (LA(6) == 0x7a /* 'z' */ ) && (LA(7) == 0x65 /* 'e' */ ) && (true) && (true) && (true)) {
					mPOPSIZET(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x70 /* 'p' */ ) && (LA(2) == 0x6f /* 'o' */ ) && (LA(3) == 0x69 /* 'i' */ ) && (LA(4) == 0x73 /* 's' */ ) && (LA(5) == 0x73 /* 's' */ ) && (LA(6) == 0x6f /* 'o' */ ) && (LA(7) == 0x6e /* 'n' */ ) && (true) && (true) && (true)) {
					mPOISSONT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x74 /* 't' */ ) && (LA(2) == 0x68 /* 'h' */ ) && (LA(3) == 0x72 /* 'r' */ ) && (LA(4) == 0x65 /* 'e' */ ) && (LA(5) == 0x61 /* 'a' */ ) && (LA(6) == 0x64 /* 'd' */ ) && (LA(7) == 0x73 /* 's' */ ) && (true) && (true) && (true)) {
					mTHREADST(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x65 /* 'e' */ ) && (LA(2) == 0x6c /* 'l' */ ) && (LA(3) == 0x69 /* 'i' */ ) && (LA(4) == 0x74 /* 't' */ ) && (LA(5) == 0x69 /* 'i' */ ) && (LA(6) == 0x73 /* 's' */ ) && (LA(7) == 0x74 /* 't' */ ) && (true) && (true) && (true)) {
					mELITISTT(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x77 /* 'w' */ ) && (LA(2) == 0x65 /* 'e' */ ) && (LA(3) == 0x69 /* 'i' */ ) && (LA(4) == 0x67 /* 'g' */ ) && (LA(5) == 0x68 /* 'h' */ ) && (LA(6) == 0x74 /* 't' */ ) && (LA(7) == 0x73 /* 's' */ ) && (true) && (true) && (true)) {
					mWEIGHTST(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x67 /* 'g' */ ) && (LA(2) == 0x61 /* 'a' */ ) && (LA(3) == 0x74 /* 't' */ ) && (LA(4) == 0x79 /* 'y' */ ) && (LA(5) == 0x70 /* 'p' */ ) && (LA(6) == 0x65 /* 'e' */ ) && (true) && (true) && (true) && (true)) {
					mGATYPET(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x66 /* 'f' */ ) && (LA(2) == 0x61 /* 'a' */ ) && (LA(3) == 0x6c /* 'l' */ ) && (LA(4) == 0x73 /* 's' */ ) && (LA(5) == 0x65 /* 'e' */ ) && (true) && (true) && (true) && (true) && (true)) {
					mFALSE(true);
					theRetToken=_returnToken;
				}
				else if ((LA(1) == 0x74 /* 't' */ ) && (LA(2) == 0x72 /* 'r' */ ) && (LA(3) == 0x75 /* 'u' */ ) && (LA(4) == 0x65 /* 'e' */ ) && (true) && (true) && (true) && (true) && (true) && (true)) {
					mTRUE(true);
					theRetToken=_returnToken;
				}
				else if (((LA(1) >= 0x61 /* 'a' */  && LA(1) <= 0x7a /* 'z' */ )) && (true) && (true) && (true) && (true) && (true) && (true) && (true) && (true) && (true)) {
					mSTRING(true);
					theRetToken=_returnToken;
				}
			else {
				if (LA(1)==EOF_CHAR)
				{
					uponEOF();
					_returnToken = makeToken(antlr::Token::EOF_TYPE);
				}
				else {throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());}
			}
			}
			if ( !_returnToken )
				goto tryAgain; // found SKIP token

			_ttype = _returnToken->getType();
			_ttype = testLiteralsTable(_ttype);
			_returnToken->setType(_ttype);
			return _returnToken;
		}
		catch (antlr::RecognitionException& e) {
				throw antlr::TokenStreamRecognitionException(e);
		}
		catch (antlr::CharStreamIOException& csie) {
			throw antlr::TokenStreamIOException(csie.io);
		}
		catch (antlr::CharStreamException& cse) {
			throw antlr::TokenStreamException(cse.getMessage());
		}
tryAgain:;
	}
}

void SurfInvGaConfLexer::mEQUAL(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = EQUAL;
	std::string::size_type _saveIndex;
	
	match('=' /* charlit */ );
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mTRUE(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = TRUE;
	std::string::size_type _saveIndex;
	
	match("true");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mFALSE(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = FALSE;
	std::string::size_type _saveIndex;
	
	match("false");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mWS(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = WS;
	std::string::size_type _saveIndex;
	
	{ // ( ... )+
	int _cnt130=0;
	for (;;) {
		switch ( LA(1)) {
		case 0x20 /* ' ' */ :
		{
			match(' ' /* charlit */ );
			break;
		}
		case 0xa /* '\n' */ :
		case 0xd /* '\r' */ :
		{
			mNEWLINE(false);
			break;
		}
		case 0x9 /* '\t' */ :
		{
			match('\t' /* charlit */ );
			break;
		}
		default:
		{
			if ( _cnt130>=1 ) { goto _loop130; } else {throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());}
		}
		}
		_cnt130++;
	}
	_loop130:;
	}  // ( ... )+
	if ( inputState->guessing==0 ) {
#line 124 "SurfInvGaConf.g"
		_ttype = ANTLR_USE_NAMESPACE(antlr)Token::SKIP;
#line 310 "SurfInvGaConfLexer.cpp"
	}
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mNEWLINE(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = NEWLINE;
	std::string::size_type _saveIndex;
	
	{
	switch ( LA(1)) {
	case 0xa /* '\n' */ :
	{
		match('\n' /* charlit */ );
		break;
	}
	case 0xd /* '\r' */ :
	{
		match('\r' /* charlit */ );
		match('\n' /* charlit */ );
		break;
	}
	default:
	{
		throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
	}
	}
	}
	if ( inputState->guessing==0 ) {
#line 150 "SurfInvGaConf.g"
		newline();
#line 347 "SurfInvGaConfLexer.cpp"
	}
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mSTRING(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = STRING;
	std::string::size_type _saveIndex;
	
	mCHAR(false);
	{ // ( ... )*
	for (;;) {
		switch ( LA(1)) {
		case 0x61 /* 'a' */ :
		case 0x62 /* 'b' */ :
		case 0x63 /* 'c' */ :
		case 0x64 /* 'd' */ :
		case 0x65 /* 'e' */ :
		case 0x66 /* 'f' */ :
		case 0x67 /* 'g' */ :
		case 0x68 /* 'h' */ :
		case 0x69 /* 'i' */ :
		case 0x6a /* 'j' */ :
		case 0x6b /* 'k' */ :
		case 0x6c /* 'l' */ :
		case 0x6d /* 'm' */ :
		case 0x6e /* 'n' */ :
		case 0x6f /* 'o' */ :
		case 0x70 /* 'p' */ :
		case 0x71 /* 'q' */ :
		case 0x72 /* 'r' */ :
		case 0x73 /* 's' */ :
		case 0x74 /* 't' */ :
		case 0x75 /* 'u' */ :
		case 0x76 /* 'v' */ :
		case 0x77 /* 'w' */ :
		case 0x78 /* 'x' */ :
		case 0x79 /* 'y' */ :
		case 0x7a /* 'z' */ :
		{
			mCHAR(false);
			break;
		}
		case 0x30 /* '0' */ :
		case 0x31 /* '1' */ :
		case 0x32 /* '2' */ :
		case 0x33 /* '3' */ :
		case 0x34 /* '4' */ :
		case 0x35 /* '5' */ :
		case 0x36 /* '6' */ :
		case 0x37 /* '7' */ :
		case 0x38 /* '8' */ :
		case 0x39 /* '9' */ :
		{
			mDIGIT(false);
			break;
		}
		case 0x23 /* '#' */ :
		case 0x24 /* '$' */ :
		case 0x25 /* '%' */ :
		case 0x26 /* '&' */ :
		case 0x27 /* '\'' */ :
		case 0x28 /* '(' */ :
		case 0x29 /* ')' */ :
		case 0x2a /* '*' */ :
		case 0x2b /* '+' */ :
		case 0x2c /* ',' */ :
		case 0x2d /* '-' */ :
		case 0x2e /* '.' */ :
		case 0x2f /* '/' */ :
		case 0x3a /* ':' */ :
		case 0x3b /* ';' */ :
		case 0x3c /* '<' */ :
		case 0x3f /* '?' */ :
		case 0x40 /* '@' */ :
		case 0x5b /* '[' */ :
		case 0x5d /* ']' */ :
		case 0x5e /* '^' */ :
		case 0x5f /* '_' */ :
		case 0x7b /* '{' */ :
		case 0x7c /* '|' */ :
		case 0x7d /* '}' */ :
		case 0x7e /* '~' */ :
		{
			mOTHER(false);
			break;
		}
		default:
		{
			goto _loop133;
		}
		}
	}
	_loop133:;
	} // ( ... )*
	_ttype = testLiteralsTable(_ttype);
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mCHAR(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = CHAR;
	std::string::size_type _saveIndex;
	
	{
	matchRange('a','z');
	}
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mDIGIT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = DIGIT;
	std::string::size_type _saveIndex;
	
	matchRange('0','9');
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mOTHER(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = OTHER;
	std::string::size_type _saveIndex;
	
	switch ( LA(1)) {
	case 0x27 /* '\'' */ :
	{
		match('\'' /* charlit */ );
		break;
	}
	case 0x23 /* '#' */ :
	{
		match('#' /* charlit */ );
		break;
	}
	case 0x24 /* '$' */ :
	{
		match('$' /* charlit */ );
		break;
	}
	case 0x25 /* '%' */ :
	{
		match('%' /* charlit */ );
		break;
	}
	case 0x26 /* '&' */ :
	{
		match('&' /* charlit */ );
		break;
	}
	case 0x28 /* '(' */ :
	{
		match('(' /* charlit */ );
		break;
	}
	case 0x29 /* ')' */ :
	{
		match(')' /* charlit */ );
		break;
	}
	case 0x2a /* '*' */ :
	{
		match('*' /* charlit */ );
		break;
	}
	case 0x2b /* '+' */ :
	{
		match('+' /* charlit */ );
		break;
	}
	case 0x2c /* ',' */ :
	{
		match(',' /* charlit */ );
		break;
	}
	case 0x2d /* '-' */ :
	{
		match('-' /* charlit */ );
		break;
	}
	case 0x2e /* '.' */ :
	{
		match('.' /* charlit */ );
		break;
	}
	case 0x2f /* '/' */ :
	{
		match('/' /* charlit */ );
		break;
	}
	case 0x3a /* ':' */ :
	{
		match(':' /* charlit */ );
		break;
	}
	case 0x3b /* ';' */ :
	{
		match(';' /* charlit */ );
		break;
	}
	case 0x3c /* '<' */ :
	{
		match('<' /* charlit */ );
		break;
	}
	case 0x3f /* '?' */ :
	{
		match('?' /* charlit */ );
		break;
	}
	case 0x40 /* '@' */ :
	{
		match('@' /* charlit */ );
		break;
	}
	case 0x5b /* '[' */ :
	{
		match('[' /* charlit */ );
		break;
	}
	case 0x5d /* ']' */ :
	{
		match(']' /* charlit */ );
		break;
	}
	case 0x5e /* '^' */ :
	{
		match('^' /* charlit */ );
		break;
	}
	case 0x5f /* '_' */ :
	{
		match('_' /* charlit */ );
		break;
	}
	case 0x7b /* '{' */ :
	{
		match('{' /* charlit */ );
		break;
	}
	case 0x7c /* '|' */ :
	{
		match('|' /* charlit */ );
		break;
	}
	case 0x7d /* '}' */ :
	{
		match('}' /* charlit */ );
		break;
	}
	case 0x7e /* '~' */ :
	{
		match('~' /* charlit */ );
		break;
	}
	default:
	{
		throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
	}
	}
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mNUMBER(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = NUMBER;
	std::string::size_type _saveIndex;
	
	{
	switch ( LA(1)) {
	case 0x2b /* '+' */ :
	{
		match('+' /* charlit */ );
		break;
	}
	case 0x2d /* '-' */ :
	{
		match('-' /* charlit */ );
		break;
	}
	case 0x2e /* '.' */ :
	case 0x30 /* '0' */ :
	case 0x31 /* '1' */ :
	case 0x32 /* '2' */ :
	case 0x33 /* '3' */ :
	case 0x34 /* '4' */ :
	case 0x35 /* '5' */ :
	case 0x36 /* '6' */ :
	case 0x37 /* '7' */ :
	case 0x38 /* '8' */ :
	case 0x39 /* '9' */ :
	{
		break;
	}
	default:
	{
		throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
	}
	}
	}
	{
	bool synPredMatched138 = false;
	if (((_tokenSet_0.member(LA(1))) && (_tokenSet_0.member(LA(2))) && (true) && (true) && (true) && (true) && (true) && (true) && (true) && (true))) {
		int _m138 = mark();
		synPredMatched138 = true;
		inputState->guessing++;
		try {
			{
			mREAL(false);
			}
		}
		catch (antlr::RecognitionException& pe) {
			synPredMatched138 = false;
		}
		rewind(_m138);
		inputState->guessing--;
	}
	if ( synPredMatched138 ) {
		mREAL(false);
	}
	else if (((LA(1) >= 0x30 /* '0' */  && LA(1) <= 0x39 /* '9' */ )) && (true) && (true) && (true) && (true) && (true) && (true) && (true) && (true) && (true)) {
		mINT(false);
	}
	else {
		throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
	}
	
	}
	{
	if ((LA(1) == 0x65 /* 'e' */ )) {
		{
		match('e' /* charlit */ );
		}
		{
		switch ( LA(1)) {
		case 0x2b /* '+' */ :
		{
			match('+' /* charlit */ );
			break;
		}
		case 0x2d /* '-' */ :
		{
			match('-' /* charlit */ );
			break;
		}
		case 0x30 /* '0' */ :
		case 0x31 /* '1' */ :
		case 0x32 /* '2' */ :
		case 0x33 /* '3' */ :
		case 0x34 /* '4' */ :
		case 0x35 /* '5' */ :
		case 0x36 /* '6' */ :
		case 0x37 /* '7' */ :
		case 0x38 /* '8' */ :
		case 0x39 /* '9' */ :
		{
			break;
		}
		default:
		{
			throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		mINT(false);
	}
	else {
	}
	
	}
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mREAL(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = REAL;
	std::string::size_type _saveIndex;
	
	{
	switch ( LA(1)) {
	case 0x2e /* '.' */ :
	{
		match('.' /* charlit */ );
		mINT(false);
		break;
	}
	case 0x30 /* '0' */ :
	case 0x31 /* '1' */ :
	case 0x32 /* '2' */ :
	case 0x33 /* '3' */ :
	case 0x34 /* '4' */ :
	case 0x35 /* '5' */ :
	case 0x36 /* '6' */ :
	case 0x37 /* '7' */ :
	case 0x38 /* '8' */ :
	case 0x39 /* '9' */ :
	{
		mINT(false);
		match('.' /* charlit */ );
		{
		if (((LA(1) >= 0x30 /* '0' */  && LA(1) <= 0x39 /* '9' */ ))) {
			mINT(false);
		}
		else {
		}
		
		}
		break;
	}
	default:
	{
		throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
	}
	}
	}
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mINT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = INT;
	std::string::size_type _saveIndex;
	
	{ // ( ... )+
	int _cnt153=0;
	for (;;) {
		if (((LA(1) >= 0x30 /* '0' */  && LA(1) <= 0x39 /* '9' */ ))) {
			mDIGIT(false);
		}
		else {
			if ( _cnt153>=1 ) { goto _loop153; } else {throw antlr::NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());}
		}
		
		_cnt153++;
	}
	_loop153:;
	}  // ( ... )+
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mCOMMENT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = COMMENT;
	std::string::size_type _saveIndex;
	
	match('/' /* charlit */ );
	match('/' /* charlit */ );
	{ // ( ... )*
	for (;;) {
		if ((_tokenSet_1.member(LA(1)))) {
			{
			match(_tokenSet_1);
			}
		}
		else {
			goto _loop145;
		}
		
	}
	_loop145:;
	} // ( ... )*
	mNEWLINE(false);
	if ( inputState->guessing==0 ) {
#line 141 "SurfInvGaConf.g"
		
					_ttype = ANTLR_USE_NAMESPACE(antlr)Token::SKIP;
				
#line 855 "SurfInvGaConfLexer.cpp"
	}
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mVERBOSET(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = VERBOSET;
	std::string::size_type _saveIndex;
	
	match("verbose");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mUSEVREFMODELT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = USEVREFMODELT;
	std::string::size_type _saveIndex;
	
	match("usevrefmodel");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mVREFMODELT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = VREFMODELT;
	std::string::size_type _saveIndex;
	
	match("vrefmodel");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mBACKGROUNDMODELT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = BACKGROUNDMODELT;
	std::string::size_type _saveIndex;
	
	match("backgroundmodel");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mFITEXPONENTT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = FITEXPONENTT;
	std::string::size_type _saveIndex;
	
	match("fitexponent");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mPOPSIZET(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = POPSIZET;
	std::string::size_type _saveIndex;
	
	match("popsize");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mINITTEMPT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = INITTEMPT;
	std::string::size_type _saveIndex;
	
	match("inittemp");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mCOOLINGRATIOT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = COOLINGRATIOT;
	std::string::size_type _saveIndex;
	
	match("coolingratio");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mGENERATIONST(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = GENERATIONST;
	std::string::size_type _saveIndex;
	
	match("generations");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mMUTATIONPROBT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = MUTATIONPROBT;
	std::string::size_type _saveIndex;
	
	match("mutationprob");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mCROSSOVERPROBT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = CROSSOVERPROBT;
	std::string::size_type _saveIndex;
	
	match("crossoverprob");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mPOISSONT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = POISSONT;
	std::string::size_type _saveIndex;
	
	match("poisson");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mTHREADST(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = THREADST;
	std::string::size_type _saveIndex;
	
	match("threads");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mERRORLEVELT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = ERRORLEVELT;
	std::string::size_type _saveIndex;
	
	match("errorlevel");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mGATYPET(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = GATYPET;
	std::string::size_type _saveIndex;
	
	match("gatype");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mOUTPUTBASET(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = OUTPUTBASET;
	std::string::size_type _saveIndex;
	
	match("outputbase");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mINPUTDATAT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = INPUTDATAT;
	std::string::size_type _saveIndex;
	
	match("inputdata");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mANNEALINGGENERATIONT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = ANNEALINGGENERATIONT;
	std::string::size_type _saveIndex;
	
	match("annealinggeneration");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mELITISTT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = ELITISTT;
	std::string::size_type _saveIndex;
	
	match("elitist");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mTHICKBASET(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = THICKBASET;
	std::string::size_type _saveIndex;
	
	match("thickbase");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mTHICKSTEPT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = THICKSTEPT;
	std::string::size_type _saveIndex;
	
	match("thickstep");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mTHICKSIZEST(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = THICKSIZEST;
	std::string::size_type _saveIndex;
	
	match("thicksizes");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mSVELBASET(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = SVELBASET;
	std::string::size_type _saveIndex;
	
	match("svelbase");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mSVELSTEPT(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = SVELSTEPT;
	std::string::size_type _saveIndex;
	
	match("svelstep");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mSVELSIZEST(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = SVELSIZEST;
	std::string::size_type _saveIndex;
	
	match("svelsizes");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}

void SurfInvGaConfLexer::mWEIGHTST(bool _createToken) {
	int _ttype; antlr::RefToken _token; std::string::size_type _begin = text.length();
	_ttype = WEIGHTST;
	std::string::size_type _saveIndex;
	
	match("weights");
	if ( _createToken && _token==antlr::nullToken && _ttype!=antlr::Token::SKIP ) {
	   _token = makeToken(_ttype);
	   _token->setText(text.substr(_begin, text.length()-_begin));
	}
	_returnToken = _token;
	_saveIndex=0;
}


const unsigned long SurfInvGaConfLexer::_tokenSet_0_data_[] = { 0UL, 67059712UL, 0UL, 0UL, 0UL, 0UL };
const antlr::BitSet SurfInvGaConfLexer::_tokenSet_0(_tokenSet_0_data_,6);
const unsigned long SurfInvGaConfLexer::_tokenSet_1_data_[] = { 4294958079UL, 4294967295UL, 4294967295UL, 4294967295UL, 0UL, 0UL, 0UL, 0UL };
// 0x0 0x1 0x2 0x3 0x4 0x5 0x6 0x7 0x8 0x9 0xb 0xc 0xe 0xf 0x10 0x11 0x12 
// 0x13 0x14 0x15 0x16 0x17 0x18 0x19 0x1a 0x1b 0x1c 0x1d 0x1e 0x1f   ! 
// \" # $ % & \' ( ) * 
const antlr::BitSet SurfInvGaConfLexer::_tokenSet_1(_tokenSet_1_data_,8);

