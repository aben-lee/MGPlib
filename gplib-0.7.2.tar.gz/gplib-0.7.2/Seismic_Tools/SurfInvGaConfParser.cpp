/* $ANTLR 2.7.7 (2006-11-01): "SurfInvGaConf.g" -> "SurfInvGaConfParser.cpp"$ */
#include "SurfInvGaConfParser.hpp"
#include <antlr/NoViableAltException.hpp>
#include <antlr/SemanticException.hpp>
#include <antlr/ASTFactory.hpp>
#line 1 "SurfInvGaConf.g"
#line 8 "SurfInvGaConfParser.cpp"
SurfInvGaConfParser::SurfInvGaConfParser(antlr::TokenBuffer& tokenBuf, int k)
: antlr::LLkParser(tokenBuf,k)
{
}

SurfInvGaConfParser::SurfInvGaConfParser(antlr::TokenBuffer& tokenBuf)
: antlr::LLkParser(tokenBuf,10)
{
}

SurfInvGaConfParser::SurfInvGaConfParser(antlr::TokenStream& lexer, int k)
: antlr::LLkParser(lexer,k)
{
}

SurfInvGaConfParser::SurfInvGaConfParser(antlr::TokenStream& lexer)
: antlr::LLkParser(lexer,10)
{
}

SurfInvGaConfParser::SurfInvGaConfParser(const antlr::ParserSharedInputState& state)
: antlr::LLkParser(state,10)
{
}

void SurfInvGaConfParser::configentry() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case VERBOSET:
		{
			match(VERBOSET);
			match(EQUAL);
			verbose=boolvalue();
			break;
		}
		case USEVREFMODELT:
		{
			match(USEVREFMODELT);
			match(EQUAL);
			usevrefmodel=boolvalue();
			break;
		}
		case VREFMODELT:
		{
			match(VREFMODELT);
			match(EQUAL);
			vrefmodel=stringvalue();
			break;
		}
		case BACKGROUNDMODELT:
		{
			match(BACKGROUNDMODELT);
			match(EQUAL);
			backgroundmodel=stringvalue();
			break;
		}
		case FITEXPONENTT:
		{
			match(FITEXPONENTT);
			match(EQUAL);
			fitexponent=numvalue();
			break;
		}
		case POPSIZET:
		{
			match(POPSIZET);
			match(EQUAL);
			popsize=numvalue();
			break;
		}
		case INITTEMPT:
		{
			match(INITTEMPT);
			match(EQUAL);
			inittemp=numvalue();
			break;
		}
		case COOLINGRATIOT:
		{
			match(COOLINGRATIOT);
			match(EQUAL);
			coolingratio=numvalue();
			break;
		}
		case GENERATIONST:
		{
			match(GENERATIONST);
			match(EQUAL);
			generations=numvalue();
			break;
		}
		case MUTATIONPROBT:
		{
			match(MUTATIONPROBT);
			match(EQUAL);
			mutationprob=numvalue();
			break;
		}
		case CROSSOVERPROBT:
		{
			match(CROSSOVERPROBT);
			match(EQUAL);
			crossoverprob=numvalue();
			break;
		}
		case POISSONT:
		{
			match(POISSONT);
			match(EQUAL);
			poisson=numvalue();
			break;
		}
		case THREADST:
		{
			match(THREADST);
			match(EQUAL);
			threads=numvalue();
			break;
		}
		case ERRORLEVELT:
		{
			match(ERRORLEVELT);
			match(EQUAL);
			errorlevel=numvalue();
			break;
		}
		case GATYPET:
		{
			match(GATYPET);
			match(EQUAL);
			gatype=stringvalue();
			break;
		}
		case OUTPUTBASET:
		{
			match(OUTPUTBASET);
			match(EQUAL);
			outputbase=stringvalue();
			break;
		}
		case INPUTDATAT:
		{
			match(INPUTDATAT);
			match(EQUAL);
			inputdata=stringvalue();
			break;
		}
		case ANNEALINGGENERATIONT:
		{
			match(ANNEALINGGENERATIONT);
			match(EQUAL);
			annealinggeneration=numvalue();
			break;
		}
		case ELITISTT:
		{
			match(ELITISTT);
			match(EQUAL);
			elitist=boolvalue();
			break;
		}
		case THICKBASET:
		{
			match(THICKBASET);
			match(EQUAL);
			if ( inputState->guessing==0 ) {
#line 72 "SurfInvGaConf.g"
				i = 0; dtemp = 0; stemp = ""; btemp = false;
#line 179 "SurfInvGaConfParser.cpp"
			}
			{ // ( ... )+
			int _cnt78=0;
			for (;;) {
				if ((LA(1) == NUMBER)) {
					dtemp=numvalue();
					if ( inputState->guessing==0 ) {
#line 73 "SurfInvGaConf.g"
						if (i < thickbase.size()) {thickbase.at(i) = dtemp;} else{thickbase.push_back(dtemp);}++i;
#line 189 "SurfInvGaConfParser.cpp"
					}
				}
				else {
					if ( _cnt78>=1 ) { goto _loop78; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt78++;
			}
			_loop78:;
			}  // ( ... )+
			break;
		}
		case THICKSTEPT:
		{
			match(THICKSTEPT);
			match(EQUAL);
			if ( inputState->guessing==0 ) {
#line 74 "SurfInvGaConf.g"
				i = 0; dtemp = 0; stemp = ""; btemp = false;
#line 209 "SurfInvGaConfParser.cpp"
			}
			{ // ( ... )+
			int _cnt84=0;
			for (;;) {
				if ((LA(1) == NUMBER)) {
					dtemp=numvalue();
					if ( inputState->guessing==0 ) {
#line 75 "SurfInvGaConf.g"
						if (i < thickstep.size()) {thickstep.at(i) = dtemp;} else{thickstep.push_back(dtemp);}++i;
#line 219 "SurfInvGaConfParser.cpp"
					}
				}
				else {
					if ( _cnt84>=1 ) { goto _loop84; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt84++;
			}
			_loop84:;
			}  // ( ... )+
			break;
		}
		case THICKSIZEST:
		{
			match(THICKSIZEST);
			match(EQUAL);
			if ( inputState->guessing==0 ) {
#line 76 "SurfInvGaConf.g"
				i = 0; dtemp = 0; stemp = ""; btemp = false;
#line 239 "SurfInvGaConfParser.cpp"
			}
			{ // ( ... )+
			int _cnt90=0;
			for (;;) {
				if ((LA(1) == NUMBER)) {
					itemp=numvalue();
					if ( inputState->guessing==0 ) {
#line 77 "SurfInvGaConf.g"
						if (i < thicksizes.size()) {thicksizes.at(i) = itemp;} else{thicksizes.push_back(itemp);}++i;
#line 249 "SurfInvGaConfParser.cpp"
					}
				}
				else {
					if ( _cnt90>=1 ) { goto _loop90; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt90++;
			}
			_loop90:;
			}  // ( ... )+
			break;
		}
		case SVELBASET:
		{
			match(SVELBASET);
			match(EQUAL);
			if ( inputState->guessing==0 ) {
#line 78 "SurfInvGaConf.g"
				i = 0; dtemp = 0; stemp = ""; btemp = false;
#line 269 "SurfInvGaConfParser.cpp"
			}
			{ // ( ... )+
			int _cnt96=0;
			for (;;) {
				if ((LA(1) == NUMBER)) {
					dtemp=numvalue();
					if ( inputState->guessing==0 ) {
#line 79 "SurfInvGaConf.g"
						if (i < svelbase.size()) {svelbase.at(i) = dtemp;} else{svelbase.push_back(dtemp);}++i;
#line 279 "SurfInvGaConfParser.cpp"
					}
				}
				else {
					if ( _cnt96>=1 ) { goto _loop96; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt96++;
			}
			_loop96:;
			}  // ( ... )+
			break;
		}
		case SVELSTEPT:
		{
			match(SVELSTEPT);
			match(EQUAL);
			if ( inputState->guessing==0 ) {
#line 80 "SurfInvGaConf.g"
				i = 0; dtemp = 0; stemp = ""; btemp = false;
#line 299 "SurfInvGaConfParser.cpp"
			}
			{ // ( ... )+
			int _cnt102=0;
			for (;;) {
				if ((LA(1) == NUMBER)) {
					dtemp=numvalue();
					if ( inputState->guessing==0 ) {
#line 81 "SurfInvGaConf.g"
						if (i < svelstep.size()) {svelstep.at(i) = dtemp;} else{svelstep.push_back(dtemp);}++i;
#line 309 "SurfInvGaConfParser.cpp"
					}
				}
				else {
					if ( _cnt102>=1 ) { goto _loop102; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt102++;
			}
			_loop102:;
			}  // ( ... )+
			break;
		}
		case SVELSIZEST:
		{
			match(SVELSIZEST);
			match(EQUAL);
			if ( inputState->guessing==0 ) {
#line 82 "SurfInvGaConf.g"
				i = 0; dtemp = 0; stemp = ""; btemp = false;
#line 329 "SurfInvGaConfParser.cpp"
			}
			{ // ( ... )+
			int _cnt108=0;
			for (;;) {
				if ((LA(1) == NUMBER)) {
					itemp=numvalue();
					if ( inputState->guessing==0 ) {
#line 83 "SurfInvGaConf.g"
						if (i < svelsizes.size()) {svelsizes.at(i) = itemp;} else{svelsizes.push_back(itemp);}++i;
#line 339 "SurfInvGaConfParser.cpp"
					}
				}
				else {
					if ( _cnt108>=1 ) { goto _loop108; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt108++;
			}
			_loop108:;
			}  // ( ... )+
			break;
		}
		case WEIGHTST:
		{
			match(WEIGHTST);
			match(EQUAL);
			if ( inputState->guessing==0 ) {
#line 84 "SurfInvGaConf.g"
				i = 0; dtemp = 0; stemp = ""; btemp = false;
#line 359 "SurfInvGaConfParser.cpp"
			}
			{ // ( ... )+
			int _cnt114=0;
			for (;;) {
				if ((LA(1) == NUMBER)) {
					dtemp=numvalue();
					if ( inputState->guessing==0 ) {
#line 85 "SurfInvGaConf.g"
						if (i < weights.size()) {weights.at(i) = dtemp;} else{weights.push_back(dtemp);}++i;
#line 369 "SurfInvGaConfParser.cpp"
					}
				}
				else {
					if ( _cnt114>=1 ) { goto _loop114; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt114++;
			}
			_loop114:;
			}  // ( ... )+
			break;
		}
		default:
		{
			throw antlr::NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (antlr::RecognitionException& ex) {
		if( inputState->guessing == 0 ) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		} else {
			throw;
		}
	}
}

bool  SurfInvGaConfParser::boolvalue() {
#line 99 "SurfInvGaConf.g"
	bool r;
#line 402 "SurfInvGaConfParser.cpp"
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case TRUE:
		{
			match(TRUE);
			if ( inputState->guessing==0 ) {
#line 100 "SurfInvGaConf.g"
				r = true;
#line 413 "SurfInvGaConfParser.cpp"
			}
			break;
		}
		case FALSE:
		{
			match(FALSE);
			if ( inputState->guessing==0 ) {
#line 100 "SurfInvGaConf.g"
				r = false;
#line 423 "SurfInvGaConfParser.cpp"
			}
			break;
		}
		default:
		{
			throw antlr::NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (antlr::RecognitionException& ex) {
		if( inputState->guessing == 0 ) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		} else {
			throw;
		}
	}
	return r;
}

std::string  SurfInvGaConfParser::stringvalue() {
#line 103 "SurfInvGaConf.g"
	std::string r;
#line 448 "SurfInvGaConfParser.cpp"
	antlr::RefToken  currvalue = antlr::nullToken;
	
	try {      // for error handling
		currvalue = LT(1);
		match(STRING);
		if ( inputState->guessing==0 ) {
#line 104 "SurfInvGaConf.g"
			r = currvalue->getText();
#line 457 "SurfInvGaConfParser.cpp"
		}
	}
	catch (antlr::RecognitionException& ex) {
		if( inputState->guessing == 0 ) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		} else {
			throw;
		}
	}
	return r;
}

double  SurfInvGaConfParser::numvalue() {
#line 95 "SurfInvGaConf.g"
	double r;
#line 474 "SurfInvGaConfParser.cpp"
	antlr::RefToken  currvalue = antlr::nullToken;
	
	try {      // for error handling
		currvalue = LT(1);
		match(NUMBER);
		if ( inputState->guessing==0 ) {
#line 96 "SurfInvGaConf.g"
			r = atof(currvalue->getText().c_str());
#line 483 "SurfInvGaConfParser.cpp"
		}
	}
	catch (antlr::RecognitionException& ex) {
		if( inputState->guessing == 0 ) {
			reportError(ex);
			recover(ex,_tokenSet_1);
		} else {
			throw;
		}
	}
	return r;
}

void SurfInvGaConfParser::configfile() {
#line 87 "SurfInvGaConf.g"
	
	verbose = false;
	usevrefmodel = false;
	fitexponent = 2;
	
#line 504 "SurfInvGaConfParser.cpp"
	
	try {      // for error handling
		{ // ( ... )+
		int _cnt118=0;
		for (;;) {
			if ((_tokenSet_2.member(LA(1)))) {
				configentry();
				{
				if ((LA(1) == COMMENT) && (_tokenSet_0.member(LA(2))) && (LA(3) == antlr::Token::EOF_TYPE || LA(3) == EQUAL || LA(3) == COMMENT) && (_tokenSet_3.member(LA(4))) && (_tokenSet_1.member(LA(5))) && (_tokenSet_4.member(LA(6))) && (_tokenSet_5.member(LA(7))) && (_tokenSet_5.member(LA(8))) && (_tokenSet_5.member(LA(9))) && (_tokenSet_5.member(LA(10)))) {
					match(COMMENT);
				}
				else if ((_tokenSet_0.member(LA(1))) && (LA(2) == antlr::Token::EOF_TYPE || LA(2) == EQUAL || LA(2) == COMMENT) && (_tokenSet_3.member(LA(3))) && (_tokenSet_1.member(LA(4))) && (_tokenSet_4.member(LA(5))) && (_tokenSet_5.member(LA(6))) && (_tokenSet_5.member(LA(7))) && (_tokenSet_5.member(LA(8))) && (_tokenSet_5.member(LA(9))) && (_tokenSet_5.member(LA(10)))) {
				}
				else {
					throw antlr::NoViableAltException(LT(1), getFilename());
				}
				
				}
			}
			else {
				if ( _cnt118>=1 ) { goto _loop118; } else {throw antlr::NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt118++;
		}
		_loop118:;
		}  // ( ... )+
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == COMMENT)) {
				match(COMMENT);
			}
			else {
				goto _loop120;
			}
			
		}
		_loop120:;
		} // ( ... )*
		match(antlr::Token::EOF_TYPE);
	}
	catch (antlr::RecognitionException& ex) {
		if( inputState->guessing == 0 ) {
			reportError(ex);
			recover(ex,_tokenSet_6);
		} else {
			throw;
		}
	}
}

void SurfInvGaConfParser::initializeASTFactory( antlr::ASTFactory& )
{
}
const char* SurfInvGaConfParser::tokenNames[] = {
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	"VERBOSET",
	"EQUAL",
	"USEVREFMODELT",
	"VREFMODELT",
	"STRING",
	"BACKGROUNDMODELT",
	"FITEXPONENTT",
	"NUMBER",
	"POPSIZET",
	"INITTEMPT",
	"COOLINGRATIOT",
	"GENERATIONST",
	"MUTATIONPROBT",
	"CROSSOVERPROBT",
	"POISSONT",
	"THREADST",
	"ERRORLEVELT",
	"GATYPET",
	"OUTPUTBASET",
	"INPUTDATAT",
	"ANNEALINGGENERATIONT",
	"ELITISTT",
	"THICKBASET",
	"THICKSTEPT",
	"THICKSIZEST",
	"SVELBASET",
	"SVELSTEPT",
	"SVELSIZEST",
	"WEIGHTST",
	"COMMENT",
	"TRUE",
	"FALSE",
	"WS",
	"NEWLINE",
	"REAL",
	"INT",
	"DIGIT",
	"CHAR",
	"OTHER",
	0
};

const unsigned long SurfInvGaConfParser::_tokenSet_0_data_[] = { 4294964946UL, 3UL, 0UL, 0UL };
// EOF VERBOSET USEVREFMODELT VREFMODELT BACKGROUNDMODELT FITEXPONENTT 
// POPSIZET INITTEMPT COOLINGRATIOT GENERATIONST MUTATIONPROBT CROSSOVERPROBT 
// POISSONT THREADST ERRORLEVELT GATYPET OUTPUTBASET INPUTDATAT ANNEALINGGENERATIONT 
// ELITISTT THICKBASET THICKSTEPT THICKSIZEST SVELBASET SVELSTEPT SVELSIZEST 
// WEIGHTST COMMENT 
const antlr::BitSet SurfInvGaConfParser::_tokenSet_0(_tokenSet_0_data_,4);
const unsigned long SurfInvGaConfParser::_tokenSet_1_data_[] = { 4294966994UL, 3UL, 0UL, 0UL };
// EOF VERBOSET USEVREFMODELT VREFMODELT BACKGROUNDMODELT FITEXPONENTT 
// NUMBER POPSIZET INITTEMPT COOLINGRATIOT GENERATIONST MUTATIONPROBT CROSSOVERPROBT 
// POISSONT THREADST ERRORLEVELT GATYPET OUTPUTBASET INPUTDATAT ANNEALINGGENERATIONT 
// ELITISTT THICKBASET THICKSTEPT THICKSIZEST SVELBASET SVELSTEPT SVELSIZEST 
// WEIGHTST COMMENT 
const antlr::BitSet SurfInvGaConfParser::_tokenSet_1(_tokenSet_1_data_,4);
const unsigned long SurfInvGaConfParser::_tokenSet_2_data_[] = { 4294964944UL, 1UL, 0UL, 0UL };
// VERBOSET USEVREFMODELT VREFMODELT BACKGROUNDMODELT FITEXPONENTT POPSIZET 
// INITTEMPT COOLINGRATIOT GENERATIONST MUTATIONPROBT CROSSOVERPROBT POISSONT 
// THREADST ERRORLEVELT GATYPET OUTPUTBASET INPUTDATAT ANNEALINGGENERATIONT 
// ELITISTT THICKBASET THICKSTEPT THICKSIZEST SVELBASET SVELSTEPT SVELSIZEST 
// WEIGHTST 
const antlr::BitSet SurfInvGaConfParser::_tokenSet_2(_tokenSet_2_data_,4);
const unsigned long SurfInvGaConfParser::_tokenSet_3_data_[] = { 2306UL, 14UL, 0UL, 0UL };
// EOF STRING NUMBER COMMENT TRUE FALSE 
const antlr::BitSet SurfInvGaConfParser::_tokenSet_3(_tokenSet_3_data_,4);
const unsigned long SurfInvGaConfParser::_tokenSet_4_data_[] = { 4294967026UL, 3UL, 0UL, 0UL };
// EOF VERBOSET EQUAL USEVREFMODELT VREFMODELT BACKGROUNDMODELT FITEXPONENTT 
// NUMBER POPSIZET INITTEMPT COOLINGRATIOT GENERATIONST MUTATIONPROBT CROSSOVERPROBT 
// POISSONT THREADST ERRORLEVELT GATYPET OUTPUTBASET INPUTDATAT ANNEALINGGENERATIONT 
// ELITISTT THICKBASET THICKSTEPT THICKSIZEST SVELBASET SVELSTEPT SVELSIZEST 
// WEIGHTST COMMENT 
const antlr::BitSet SurfInvGaConfParser::_tokenSet_4(_tokenSet_4_data_,4);
const unsigned long SurfInvGaConfParser::_tokenSet_5_data_[] = { 4294967282UL, 15UL, 0UL, 0UL };
// EOF VERBOSET EQUAL USEVREFMODELT VREFMODELT STRING BACKGROUNDMODELT 
// FITEXPONENTT NUMBER POPSIZET INITTEMPT COOLINGRATIOT GENERATIONST MUTATIONPROBT 
// CROSSOVERPROBT POISSONT THREADST ERRORLEVELT GATYPET OUTPUTBASET INPUTDATAT 
// ANNEALINGGENERATIONT ELITISTT THICKBASET THICKSTEPT THICKSIZEST SVELBASET 
// SVELSTEPT SVELSIZEST WEIGHTST COMMENT TRUE FALSE 
const antlr::BitSet SurfInvGaConfParser::_tokenSet_5(_tokenSet_5_data_,4);
const unsigned long SurfInvGaConfParser::_tokenSet_6_data_[] = { 2UL, 0UL, 0UL, 0UL };
// EOF 
const antlr::BitSet SurfInvGaConfParser::_tokenSet_6(_tokenSet_6_data_,4);


