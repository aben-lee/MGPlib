#include "SurfaceWaveData.h"
#include <fstream>
#include <iomanip>
#include "FatalException.h"
#include <cassert>
#include "Util.h"
using namespace std;

namespace gplib
  {
    SurfaceWaveData::SurfaceWaveData()
      {
      }

    SurfaceWaveData::~SurfaceWaveData()
      {
      }

    SurfaceWaveData::SurfaceWaveData(const SurfaceWaveData &Old) :
      periods(Old.periods), phasevelocities(Old.phasevelocities)
      {

      }

    SurfaceWaveData& SurfaceWaveData::operator=(const SurfaceWaveData& source)
      {
        if (this == &source)
          return *this;
        periods.clear();
        phasevelocities.clear();
        copy(source.periods.begin(), source.periods.end(), back_inserter(
            periods));
        copy(source.phasevelocities.begin(), source.phasevelocities.end(),
            back_inserter(phasevelocities));
        return *this;
      }

    void SurfaceWaveData::ReadFile(const std::string &filename)
      {
        std::string ending = GetFileExtension(filename);
        if (ending == ".asc")
          {
            ReadAscii(filename);
          }
        else
          {
            ReadSurf96(filename);
          }
      }
    void SurfaceWaveData::ReadSurf96(const std::string &filename)
      {
        ifstream infile(filename.c_str());
        double currperiod, currphase, dummy;
        periods.clear();
        phasevelocities.clear();

        char line[255];
        infile.getline(line, 255);//we ignore the first line
        while (infile.good())
          {
            infile >> dummy >> dummy >> currperiod >> dummy >> currphase;
            if (infile.good())
              {
                periods.push_back(currperiod);
                phasevelocities.push_back(currphase);
              }
          }
        if (periods.empty() || phasevelocities.empty() || periods.size() != phasevelocities.size())
          throw FatalException("Cannot read phase velocities from file: "
              + filename);
      }

    void SurfaceWaveData::ReadAscii(const std::string &filename)
      {
        ifstream infile(filename.c_str());
        double currperiod, currphase;
        periods.clear();
        phasevelocities.clear();
        while (infile.good())
          {
            infile >> currperiod >> currphase;
            if (infile.good())
              {
                periods.push_back(currperiod);
                phasevelocities.push_back(currphase);
              }
          }
        if (periods.empty() || phasevelocities.empty() || periods.size() != phasevelocities.size())
          throw FatalException("Cannot read phase velocities from file: "
              + filename);
      }

    void SurfaceWaveData::WriteAscii(const std::string &filename) const
      {
        ofstream outfile(filename.c_str());
        assert(periods.size() == phasevelocities.size());
        const unsigned int nelements = periods.size();
        for (unsigned int i = 0; i < nelements; ++i)
          {
            outfile << setw(10) << setprecision(5) << periods.at(i);
            outfile << setw(10) << setprecision(5) << phasevelocities.at(i);
            outfile << endl;
          }
      }
  }
