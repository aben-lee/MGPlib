#ifndef SURFACEWAVEDATA_H_
#define SURFACEWAVEDATA_H_
#include <string>
#include "types.h" 

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */
    //! A class to read, write and store fundamental mode surface wave dispersion data
    class SurfaceWaveData
      {
    private:
      trealdata periods;
      trealdata phasevelocities;
    public:
      //! Read-only access to the vector of phase velocities
      const trealdata &GetPhaseVelocities() const
        {
          return phasevelocities;
        }
      //! Read-only access to the vector of periods for the phase velocities
      const trealdata &GetPeriods() const
        {
          return periods;
        }
      //! Read-write access to phase velocities, the format might be changed in the future
      trealdata &SetPhaseVelocities()
        {
          return phasevelocities;
        }
      //! Read-write access to periods, the format might be changed in the future
      trealdata &SetPeriods()
        {
          return periods;
        }
      //! Read data from file, depending on the extension
      /*! Read data from file, depending on the extension
       * it will either call ReadAscii (for ending .asc), or ReadSurf96
       * (for any other ending).*/
      void ReadFile(const std::string &filename);
      //! Read a file in general ascii format, i.e lines with period velocity each
      virtual void ReadAscii(const std::string &filename);
      //! read data as produced by the computer programs in seismology codes ascii
      void ReadSurf96(const std::string &filename);
      //! Write the data in simple ascii format
      virtual void WriteAscii(const std::string &filename) const;
      SurfaceWaveData& operator=(const SurfaceWaveData& source);
      SurfaceWaveData(const SurfaceWaveData &Old);
      SurfaceWaveData();
      virtual ~SurfaceWaveData();
      };
  /* @} */
  }
#endif /*SURFACEWAVEDATA_H_*/
