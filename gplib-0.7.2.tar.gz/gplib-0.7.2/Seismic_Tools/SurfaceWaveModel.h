#ifndef SURFACEWAVEMODEL_H_
#define SURFACEWAVEMODEL_H_
#include "types.h"
#include <string>
#include <vector>

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! A class to store 1D model for calculation of synthetic surface wave data
    /*! This is the base class for general 1D surface wave models.
     *
     */
    class SurfaceWaveModel
      {
    private:
      trealdata pvvelocities;
      trealdata phvelocities;
      trealdata svvelocities;
      trealdata shvelocities;
      trealdata densities;
      trealdata thicknesses;
      trealdata eta;
      trealdata qmu;
      trealdata qkappa;
      double refperiod;
      int anisotropic;
      std::string name;
      int carddeckmodel;
      int ninnercore;
      int noutercore;
      void WriteLayer(std::ostream &stream, const unsigned int index,
          const trealdata &depth) const;
    protected:
      void CheckConsistency() const;
    public:
      const trealdata &GetPvVelocities() const
        {
          return pvvelocities;
        }
      const trealdata &GetPhVelocities() const
        {
          return phvelocities;
        }
      const trealdata &GetSvVelocities() const
        {
          return svvelocities;
        }
      const trealdata &GetShVelocities() const
        {
          return shvelocities;
        }
      const trealdata &GetDensities() const
        {
          return densities;
        }
      const trealdata &GetThicknesses() const
        {
          return thicknesses;
        }
      const trealdata &GetEta() const
        {
          return eta;
        }
      const trealdata &GetQmu() const
        {
          return qmu;
        }
      const trealdata &GetQkappa() const
        {
          return qkappa;
        }
      std::string GetName() const
        {
          return name;
        }
      trealdata &SetPvVelocities()
        {
          return pvvelocities;
        }
      trealdata &SetPhVelocities()
        {
          return phvelocities;
        }
      trealdata &SetSvVelocities()
        {
          return svvelocities;
        }
      trealdata &SetShVelocities()
        {
          return shvelocities;
        }
      trealdata &SetDensities()
        {
          return densities;
        }
      trealdata &SetThicknesses()
        {
          return thicknesses;
        }
      trealdata &SetEta()
        {
          return eta;
        }
      trealdata &SetQmu()
        {
          return qmu;
        }
      trealdata &SetQkappa()
        {
          return qkappa;
        }
      double GetMaxDepth(const double depth);
      //! Splits a layer into several layers with a maximum thickness of maxthick, but otherwise identical properties
      int SplitLayer(const int index, const double maxthick);
      //! Insert a layer with 0 thickness to create a discontinuity for the forward code
      void AddDiscontinuity(const int index);
      //! Merge this model with another background model, the depth range below this model will be filled with the values from the background model
      void MergeModel(const SurfaceWaveModel &Background);
      //! Read a model from a file
      virtual void ReadModel(const std::string &filename) = 0;
      //! Write the model to a file
      virtual void WriteModel(const std::string &filename) const = 0;
      //! Write out a script that when executed performs a forward calculation for this model
      virtual void WriteRunFile(const std::string &filename, const std::vector<
          double> periods) const = 0;
      //! Write out an ascii file for plotting with xmgrace or similar programs
      void WritePlot(const std::string &filename) const;
      SurfaceWaveModel& operator=(const SurfaceWaveModel& source);
      SurfaceWaveModel(const SurfaceWaveModel &Old);
      SurfaceWaveModel();
      virtual ~SurfaceWaveModel();
      };
  /* @} */
  }
#endif /*SURFACEWAVEMODEL_H_*/
