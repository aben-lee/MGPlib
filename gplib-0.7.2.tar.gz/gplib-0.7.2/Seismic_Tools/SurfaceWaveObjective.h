#ifndef SURFACEWAVEOBJECTIVE_H_
#define SURFACEWAVEOBJECTIVE_H_

#include "PlottableObjective.h"
#include "SurfaceWaveData.h"
#include "SurfaceWaveSynthetic.h"
#include <string>

namespace gplib
  {
    /** \addtogroup seistools Seismic data analysis and modeling */
    /* @{ */

    //! This class calculates the misfit between observed surface wave dispersion data and the data calculated from a seismic model
    class SurfaceWaveObjective: public PlottableObjective
      {
    private:
      //! The data that has been measured
      SurfaceWaveData MeasuredData;
      //! The synthetic data that corresponds to the current model
      SurfaceWaveData SynthData;
      //! The object used to calculate the synthetic data
      SurfaceWaveSynthetic Synthetic;
      //! The relative error of the measurements
      double errorlevel;
      //! Poisson's ratio Vp/Vs
      double poisson;
    public:
      //! Set Poisson's ratio Vp/Vs
      void SetPoisson(const double p)
        {
          poisson = p;
        }
      //! Set the relative error for each measurement
      void SetErrorLevel(const double level)
        {
          errorlevel = level;
        }
      //! We need clone and create for building an array of derived objects, see FAQ lite 20.8, the return type depends on the derived class
      virtual GeneralObjective *clone() const
        {
          return new SurfaceWaveObjective(*this);
        }
      ;
      //! Some operations cannot be done in parallel, these are done before
      virtual void PreParallel(const ttranscribed &member);
      //! Some operations cannot be done in parallel, these are done after, returns the misfit value
      virtual double PostParallel(const ttranscribed &member);
      //! The core performance calculation, has to be safe to be done in parallel
      virtual void SafeParallel(const ttranscribed &member);
      //! Write the synthetic data to a sac file with name filename
      virtual void WriteData(const std::string &filename)
        {
          SynthData.WriteAscii(filename);
        }
      //! Write the current model to ascii file for calculations
      virtual void WriteModel(const std::string &filename)
        {
          Synthetic.GetModel().WriteModel(filename);
        }
      //! Write the current model to ascii file for plotting
      virtual void WritePlot(const std::string &filename)
        {
          Synthetic.GetModel().WritePlot(filename);
        }
      SurfaceWaveObjective& operator=(const SurfaceWaveObjective& source);
      SurfaceWaveObjective(const SurfaceWaveObjective &Old);
      SurfaceWaveObjective(const SurfaceWaveData &Data);
      virtual ~SurfaceWaveObjective();
      };
  /* @} */
  }
#endif /*SURFACEWAVEOBJECTIVE_H_*/
