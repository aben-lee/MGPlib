#include "SurfaceWaveSynthetic.h"
#include <boost/filesystem.hpp>

namespace gplib
  {
    SurfaceWaveSynthetic::SurfaceWaveSynthetic()
      {
      }

    SurfaceWaveSynthetic::~SurfaceWaveSynthetic()
      {
      }

    void SurfaceWaveSynthetic::PreParallel(const std::string &filename)
      {

        Model.WriteRunFile("surf" + filename, calculationperiods);
        Model.WriteModel("surf" + filename + ".mod");
      }

    SurfaceWaveData SurfaceWaveSynthetic::SafeParallel(
        const std::string &filename)
      {
        const std::string fullname = "./surf" + filename;
        int result = std::system((std::string("bash ")+fullname).c_str());
        SynthData.ReadSurf96(fullname + ".asc96");
        boost::filesystem::remove_all(fullname);
        boost::filesystem::remove_all(fullname + "_dir");
        return SynthData;
      }

    SurfaceWaveData SurfaceWaveSynthetic::GetSynthData(
        const std::string &filename)
      {
        PreParallel(filename);
        return SafeParallel(filename);
      }
  }
