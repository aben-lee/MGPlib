#include <grace_np.h>
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/convenience.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/version.hpp>
#include <iostream>
#include <string>
#include <cstdio>
#include "SeismicDataComp.h"

namespace fs = boost::filesystem;
using namespace std;
using namespace gplib;

int main(int argc, char* argv[])
  {
    SeismicDataComp RecData;

    string version =
        "$Id: chooserecfunc.cpp 1870 2011-04-01 11:55:47Z mmoorkamp $";
    cout << endl << endl;
    cout << "Program " << version << endl;
    cout
        << " Display all the receiver functions in a directory and select good and bad ones "
        << endl;
    cout << " Receiver functions are identified by file ending '.rec' " << endl;
    cout
        << " Type 'g' for good or 'b' for bad after receiver function is displayed "
        << endl;
    cout << endl << endl;

    fs::path full_path(fs::initial_path());

    if (!fs::exists(full_path))
      {
        std::cout << "\nNot found: " << full_path << std::endl;
        return 1;
      }
    std::string statid;
    cout << "Enter station identifier: ";
    cin >> statid;
    if (GraceOpen(2048) == -1)
      {
        fprintf(stderr, "Can't run Grace. \n");
        exit(EXIT_FAILURE);
      }
    fs::directory_iterator end_iter;
    std::string response;
    for (fs::directory_iterator dir_itr(full_path); dir_itr != end_iter; ++dir_itr)
      {
        if (extension(*dir_itr) == ".rec" && boost::algorithm::contains(
            dir_itr->path().filename().string(), statid))
          {
            std::string currentname(dir_itr->path().filename().string());
            RecData.ReadData(currentname);
            const double dt = RecData.GetDt();
            for (size_t i = 0; i < RecData.GetData().size() && GraceIsOpen(); i++)
              {
                if (finite(RecData.GetData().at(i))) // if we have a valid value we display it

                  {
                    GracePrintf("g0.s0 point %f, %f", i * dt,
                        RecData.GetData().at(i));
                  }
                else //otherwise we show junk to signal bad data without upsetting xmgrace

                  {
                    GracePrintf("g0.s0 point %f, %f", i * dt, 10000.0);
                  }
              }
            double ymax = *max_element(RecData.GetData().begin(),
                RecData.GetData().end());
            double ymin = *min_element(RecData.GetData().begin(),
                RecData.GetData().end());
            GracePrintf("world xmax %f", RecData.GetData().size() * dt);
            GracePrintf("world ymax %f", ymax);
            GracePrintf("world ymin %f", ymin);
            GracePrintf("xaxis tick major %f", RecData.GetData().size() * dt
                / 5.0);
            GracePrintf("xaxis tick minor %f", RecData.GetData().size() * dt
                / 10.0);
            GracePrintf("yaxis tick major %f", ymax / 5);
            GracePrintf("yaxis tick minor %f", ymax / 10);
            GraceCommand(("title \" " + currentname + " \" ").c_str());
            GracePrintf("redraw");
            std::cin >> response;
            if (response == "b")
              fs::rename(currentname, fs::path("bad") / currentname);
            else if (response == "g")
              fs::rename(currentname, fs::path("good") / currentname);
            else
              cout << "Invalid reply, ignoring file !" << endl;
            GracePrintf("KILL g0.s0");
            //GraceFlush();
            std::cout << "Data size: " << RecData.GetData().size() << std::endl;
          }
        //else
        //	std::cout << "Filename: " << dir_itr->leaf() << " " << extension(*dir_itr) <<  std::endl;

      }
    if (GraceIsOpen())
      GraceClose();
  }
