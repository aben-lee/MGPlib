#include "CalcRecConf.h"
#include "SeismicStationList.h"
#include "FatalException.h"
#include "MultiRecCalc.h"
#include "Util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;
using namespace gplib;

string version = "$Id: datarec_multi.cpp 1839 2010-03-05 17:04:34Z mmoorkamp $";

int main()
  {
    cout
        << " This is datarec_multi: Calculate receiver functions simultaneously for several events"
        << endl; // write some info
    cout
        << " Reads in two lists of files with radial and vertical component file names, respectively"
        << endl;
    cout << " Outputs a file multi.rec " << endl;
    cout << " Some behaviour can be configured with the file calcrec.conf"
        << endl;
    cout << " This is Version: " << version << endl << endl;

    CalcRecConf Config;
    SeismicDataComp CurrRadial, CurrVertical;
    SeismicStationList Radial, Vertical;
    string outfilename = "multi.rec";
    try
      {
        Config.GetData("calcrec.conf");
        std::string radlistname = AskFilename(
            "File with list of radial filenames: ");
        std::string verlistname = AskFilename(
            "File with list of vertical filenames: ");

        Radial.ReadList(radlistname);
        Vertical.ReadList(verlistname);

        MultiRecCalc Receiver(Config.shift, Config.sigma, Config.cc);
        SeismicDataComp RecFunc;
        Receiver.CalcRecData(Radial.GetList(), Vertical.GetList(), RecFunc);

        RecFunc.WriteAsSac(outfilename);
      } catch (FatalException &e)
      {
        cerr << e.what() << endl; // if something fails print error
        return -1; // and stop execution
      }
  }
