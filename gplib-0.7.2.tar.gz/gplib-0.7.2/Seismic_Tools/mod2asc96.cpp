#include <iostream>
#include <string>
#include "SurfaceWaveModel.h"
#include "Sdisp96Model.h"

using namespace std;
using namespace gplib;

int main()
  {
    string infilename;
    
    cout << "Input file: ";
    cin >> infilename;
    string outfilename(infilename+".asc96");
    
    SurfaceWaveModel InFormat;
    InFormat.ReadModel(infilename);
    Sdisp96Model OutFormat(InFormat);
    
    OutFormat.WriteModel(outfilename);
  }

