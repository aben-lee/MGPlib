#include "SeismicDataComp.h"
#include "CFatalException.h"
#include <iostream>
#include <string>
#include "Util.h"

using namespace std;
using namespace gplib;

string version = "$Id: printhdr.cpp 1816 2009-09-07 11:28:35Z mmoorkamp $";

int main()
  {
    cout << "This is printhdr: Print sac header information" << endl; // write some info
    cout << " Reads in a file in SAC format and writes header data to stdout"
        << endl;
    cout
        << " Not all header values are displayed, only the ones supported by CSeismicDatacomp"
        << endl;
    cout << " This is Version: " << version << endl << endl;

    string infilename = AskFilename("Input file: ");

    SeismicDataComp Input;

    try
      {
        Input.ReadData(infilename);
      } catch (FatalException &e)
      {
        cerr << e.what() << endl; // if something fails print error
        return -1; // and stop execution
      }
    cout << "Name: " << Input.GetName() << endl;
    cout << "StLA: " << Input.GetStLa() << endl;
    cout << "StLo: " << Input.GetStLo() << endl;
    cout << "StEl: " << Input.GetStEl() << endl;
    cout << "StDp: " << Input.GetStDp() << endl;
    cout << "EvLa: " << Input.GetEvLa() << endl;
    cout << "EvLo: " << Input.GetEvLo() << endl;
    cout << "EvEl: " << Input.GetEvEl() << endl;
    cout << "EvDp: " << Input.GetEvDp() << endl;
    cout << "Mag: " << Input.GetMag() << endl;
    cout << "Dist: " << Input.GetDist() << endl;
    cout << "Az: " << Input.GetAz() << endl;
    cout << "Baz: " << Input.GetBaz() << endl;
    cout << "GcArc: " << Input.GetGcarc() << endl;
    cout << "Dt: " << Input.GetDt() << endl;
    cout << "B: " << Input.GetB() << endl;

  }
