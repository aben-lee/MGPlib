#include "SeismicDataComp.h"
#include "FatalException.h"
#include <iostream>
#include <string>
#include "Util.h"

using namespace std;
using namespace gplib;

string version = "$Id: sac2asc.cpp 1816 2009-09-07 11:28:35Z mmoorkamp $";

int main(int argc, char *argv[])
  {
    cout << " This is sac2asc: Convert sac to plain ascii format" << endl; // write some info
    cout << " Reads in a file in SAC format and writes it as an ascii file"
        << endl;
    cout
        << " Most header values are ignored, only npts, dt and b are written to the output file"
        << endl;
    cout << " This is Version: " << version << endl << endl;

    SeismicDataComp Input;
    string outfilename, infilename;
    try
      {
        if (argc > 1)
          infilename = argv[1];
        else
          {
            infilename = AskFilename("Input file: ");
          }
        outfilename = infilename + ".asc";

        Input.ReadData(infilename);
        Input.WriteAsAscii(outfilename);
      } catch (FatalException &e)
      {
        cerr << e.what() << endl; // if something fails print error
        return -1; // and stop execution
      }

  }
