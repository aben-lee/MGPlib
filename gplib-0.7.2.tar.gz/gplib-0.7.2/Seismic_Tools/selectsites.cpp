#include "SeismicStationList.h"
#include <iostream>
#include <string>
#include <fstream>

using namespace std;
using namespace gplib;

int main(int argc, char* argv[])
  {
    SeismicStationList Stations;
    string listfilename, outfilename;

    string version = "$Id: selectsites.cpp 1816 2009-09-07 11:28:35Z mmoorkamp $";
    cout << endl << endl;
    cout << "Program " << version << endl;
    cout << " Select sites from a given backazimuth and distance range" << endl;
    cout << " Writes out a file with site names for further processing" << endl;
    cout << endl << endl;
    //we can specify the files on the command line or ask interactively
    if (argc > 2)
      {
        listfilename = argv[1];
        outfilename = argv[2];
      }
    else
      {
        cout << "List filename: ";
        cin >> listfilename;
        cout << "Output filename: ";
        cin >> outfilename;
      }
    //read in the data
    Stations.ReadList(listfilename);
    //specify some reasonable default values
    double minbaz = 0;
    double maxbaz = 360;
    double mingcarc = 30;
    double maxgcarc = 130;
    //ask backazimuth and distance information
    cout << "Minimum  Backazimuth: ";
    cin >> minbaz;
    cout << " Maximum Backazimuth: ";
    cin >> maxbaz;
    cout << "Minimum  GcArc: ";
    cin >> mingcarc;
    cout << " Maximum GcArc: ";
    cin >> maxgcarc;
    //this file will contain all the filenames
    ofstream outlist(outfilename.c_str());
    //go through all components in the vector
    for (SeismicStationList::tseiscompvector::iterator CurrentStation =
        Stations.GetList().begin(); CurrentStation != Stations.GetList().end(); CurrentStation++)
      {
        //write out the back azimuth and distance to check
        cout << "Baz: " << CurrentStation->get()->GetBaz() << " Gcarc: "
            << CurrentStation->get()->GetGcarc();
        //apply the selection criteria
        if (minbaz <= CurrentStation->get()->GetBaz() && maxbaz
            >= CurrentStation->get()->GetBaz() && mingcarc
            <= CurrentStation->get()->GetGcarc() && maxgcarc
            >= CurrentStation->get()->GetGcarc())
          {
            outlist << CurrentStation->get()->GetName() << endl;
            cout << " Selected ! ";
          }
        cout << endl;
      }
  }
