#include <iostream>
#include <string>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <boost/random/lagged_fibonacci.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/variate_generator.hpp>
#include <boost/bind.hpp>
#include "SurfaceWaveData.h"
#include "Util.h"

using namespace std;
using namespace gplib;

int main(int argc, char* argv[])
  {
    SurfaceWaveData Data;
    string datafilename, outfilename;
    double noiselevel;

    string version = "$Id: surfnoise.cpp 1816 2009-09-07 11:28:35Z mmoorkamp $";
    cout << endl << endl;
    cout << "Program " << version << endl;
    cout << " Add random noise to surface wave dispersion data" << endl;
    cout
        << " Input is a surface wave dispersion file, output a dispersion file with added noise"
        << endl;
    cout << " The noise level is specified relative to each datapoint" << endl;
    cout << endl << endl;
    if (argc > 3)
      {
        datafilename = argv[1];
        outfilename = argv[2];
        noiselevel = atof(argv[3]);
      }
    else
      {
        datafilename = AskFilename("Input file: ");
        outfilename = AskFilename("Output filename: ");
        cout << "Noise level: ";
        cin >> noiselevel;
      }
    Data.ReadFile(datafilename);
    boost::lagged_fibonacci607
        generator(static_cast<unsigned int>(std::time(0)));

    //add noise to each dispersion value
    const size_t ndata = Data.GetPhaseVelocities().size();
    for (size_t i =0; i < ndata; ++i)
      {
        Data.SetPhaseVelocities().at(i) = boost::variate_generator<boost::lagged_fibonacci607&,
        boost::normal_distribution<> >(generator,
            boost::normal_distribution<>(Data.GetPhaseVelocities().at(i),
                Data.GetPhaseVelocities().at(i)* noiselevel))();
      }
    Data.WriteAscii(outfilename);
  }
