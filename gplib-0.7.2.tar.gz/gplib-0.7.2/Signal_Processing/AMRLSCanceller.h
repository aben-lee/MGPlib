#ifndef AMRLSCANCELLER_H
#define AMRLSCANCELLER_H

#include "RLSCanceller.h"
#include "VecMat.h"
namespace ublas = boost::numeric::ublas;

namespace gplib
  {
    /** \addtogroup sigproc Signal processing methods */
    /* @{ */

    //! An implementation of the Recursive Least Squares filter with adptive memory as described in Hakin, p. 663
    class AMRLSCanceller: public RLSCanceller
      {
    private:
      double Lambdaplus;
      double Lambdaminus;
      gplib::rmat S;
      gplib::rvec Psi;
      double Alpha;
      gplib::rmat factor1;
      gplib::rmat factor2;
      ublas::identity_matrix<double> I;
    public:
      virtual void
      AdaptFilter(const gplib::rvec &Input, const gplib::rvec &Desired);
      AMRLSCanceller(const int inputsize, const double MyDelta,
          const double MyLambda, const double MyAlpha);
      virtual ~AMRLSCanceller();
      };
  /* @} */
  }
#endif // RLSCANCELLER_H
