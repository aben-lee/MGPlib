#ifndef APPLYFILTER_H_
#define APPLYFILTER_H_

#include "AdaptiveFilter.h"
#include "TimeSeriesComponent.h"
#include <boost/shared_ptr.hpp>
#include <vector>

namespace gplib
  {
    /** \addtogroup sigproc Signal processing methods */
    /* @{ */

    //! Apply an adaptive filter to a time-series
    class ApplyFilter
      {
    private:
      bool showprogress;
      bool wanthistory;
      int shift;
      AdaptiveFilter &Filter;
      int weightsaveintervall;
      std::vector<gplib::rvec> WeightHistory;
      std::vector<TimeSeriesComponent*> InputChannels;
      std::vector<TimeSeriesComponent*> RefChannels;
      std::vector<boost::shared_ptr<TimeSeriesComponent> > OutChannels;
      std::vector<std::vector<double> > EpsValues;
    public:
      //! Do we want visual feedback of the progess on the screen, if yes draw a simple progress indicator in text mode
      void ShowProgress(const bool what)
        {
          showprogress = what;
        }
      //! Return a matrix with the values of the weights at iterations specified by weightsaveintervall
      gplib::rmat GetWeightHistory();
      //! Set the distance between iterations at which the weights are saved
      void SetWeightSaveIntervall(const int intervall)
        {
          weightsaveintervall = intervall;
        }
      //! Return the vector of output channels
      const std::vector<boost::shared_ptr<TimeSeriesComponent> > &GetOutChannels()
        {
          return OutChannels;
        }
      //! Return the vector of channel approximation errors
      const std::vector<std::vector<double> > &GetEpsValues()
        {
          return EpsValues;
        }
      //! Set the shift between the input time series and the reference time series
      void SetShift(const int theshift)
        {
          shift = theshift;
        }
      //! Add an input channel to the filter
      void AddInputChannel(TimeSeriesComponent &Channel);
      //! Add a reference channel to the filter, some AdaptiveFilter objects require only one reference
      void AddReferenceChannel(TimeSeriesComponent &Channel);
      //! Filter the input channels with the current settings
      void FilterData();
      //! The constructor takes the AdaptiveFilter object that determines how the filtering is done, if keephistory is true we store the weights
      ApplyFilter(AdaptiveFilter &TheFilter, bool keephistory = false);
      virtual ~ApplyFilter();

      };
  /* @} */
  }
#endif /*APPLYFILTER_H_*/
