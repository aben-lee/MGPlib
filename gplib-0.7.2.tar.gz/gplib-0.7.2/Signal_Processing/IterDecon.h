#ifndef ITERDECON_H_
#define ITERDECON_H_
#include "AdaptiveFilter.h"
#include "TsSpectrum.h"

namespace gplib
  {
    /** \addtogroup sigproc Signal processing methods */
    /* @{ */

    //! The iterative deconvolution algorithm, mainly used for receiver function computation
    /*! Implements iterative deconvolution used for receiver function calculations
     * but it is basically just another adaptive filter
     */
    class IterDecon: public AdaptiveFilter
      {
    private:
      //! The weights are in toeplitz matrix form, so we can store them in a vector
      gplib::rvec Weights;
      TsSpectrum &Spectrum;
    public:
      //! return the Weights as a vector, in this case the same as GetWeights
      virtual const gplib::rvec &GetWeightsAsVector()
        {
          return Weights;
        }
      //! return the Weights
      const gplib::rvec &GetWeights()
        {
          return Weights;
        }
      //! print weights to a file
      virtual void PrintWeights(std::ostream &output);
      virtual void
      AdaptFilter(const gplib::rvec &Input, const gplib::rvec &Desired);
      virtual void CalcOutput(const gplib::rvec &Input, gplib::rvec &Output);
      //! Input and output length have to be the same, so only one parameter for the constructor
      IterDecon(const int inputsize, TsSpectrum &Spec);
      virtual ~IterDecon();
      };
  /* @} */
  }
#endif /*ITERDECON_H_*/
