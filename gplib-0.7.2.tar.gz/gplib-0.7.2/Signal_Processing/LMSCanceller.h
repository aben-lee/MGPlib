/** \addtogroup sigproc Signal processing methods */
/* @{ */

#ifndef LMSCANCELLER_H
#define LMSCANCELLER_H

#include "types.h"
#include "LSSOFilter.h"

namespace gplib
  {
    //! Implements a LMS adaptive filter
    /*!*********************************************
     * LMSCanceller implements the Normalized Adaptive LMS Filter
     * as described in Haykin, p. 324 , it only supports a single
     * output channel an mutliple input channels have to be concatenated
     * at the input side
     */
    class LMSCanceller: public LSSOFilter
      {
    private:
      double mu;
    public:
      void SetMu(const double Mymu)
        {
          mu = Mymu;
        }
      virtual void
      AdaptFilter(const gplib::rvec &Input, const gplib::rvec &Desired);
      LMSCanceller(const int inputsize);
      LMSCanceller(const int inputsize, const double Mymu);
      virtual ~LMSCanceller();
      };
  /* @} */
  }
#endif // LMSCANCELLER_H
