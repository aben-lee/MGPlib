#include "LSSOFilter.h"
#include <iostream>

namespace gplib
  {

    const int maxoutputchannels = 1;

    LSSOFilter::LSSOFilter(const int filterlength) :
      AdaptiveFilter(filterlength, maxoutputchannels), Weights(filterlength)
      {
        //set all weights to zero
        Weights.clear();
      }

    LSSOFilter::~LSSOFilter()
      {
      }

    void LSSOFilter::PrintWeights(std::ostream &output)
      {
        //print all filter weights to a single line
        std::copy(Weights.begin(), Weights.end(),
            std::ostream_iterator<double>(output, " "));
        output << std::endl;
      }

    void LSSOFilter::CalcOutput(const gplib::rvec &Input, gplib::rvec &Output)
      {
        //for a single output value the filter output is
        //simply the inner product of the input with the filter weigths
        Output(0) = ublas::prec_inner_prod(Input, Weights);
        SetOutput(Output);
      }
  }
