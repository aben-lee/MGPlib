#include "RLSCanceller.h"

namespace ublas = boost::numeric::ublas;

#include <boost/numeric/ublas/operation.hpp>
//#include <boost/numeric/bindings/atlas/cblas3.hpp>
//#include <boost/numeric/bindings/atlas/cblas2.hpp>
#include <iostream>

namespace gplib
  {

    //namespace atlas = boost::numeric::bindings::atlas;
    RLSCanceller::RLSCanceller(const int inputsize) :
      LSSOFilter(inputsize), delta(0.9999999), lambda(1), P(inputsize,
          inputsize), pi(inputsize), k(inputsize)
      {
        P = 1. / delta * ublas::identity_matrix<double>(inputsize);
      }

    RLSCanceller::RLSCanceller(const int inputsize, const double MyDelta,
        const double MyLambda) :
      LSSOFilter(inputsize), delta(MyDelta), lambda(MyLambda), P(inputsize,
          inputsize), pi(inputsize), k(inputsize)
      {
        P = 1. / delta * ublas::identity_matrix<double>(inputsize);
      }

    RLSCanceller::~RLSCanceller()
      {
      }

    void RLSCanceller::AdaptFilter(const gplib::rvec &Input,
        const gplib::rvec &Desired)
      {
        SetEpsilon(Desired - GetFilterOutput());
        ublas::axpy_prod(P,Input,pi,true);
        //atlas::gemv(P, Input, pi);
        k = pi / (lambda + ublas::prec_inner_prod(Input, pi));
        SetWeights() += k * GetEpsilon()(0);
        gplib::rmat temp1(P);
        ublas::noalias(temp1) -= ublas::prec_prod(ublas::outer_prod(k,Input),P);
        //gplib::rmat temp1(P);
        //atlas::ger(k,Input,kiouter);  // ublas::outer_prod(k,Input); has replaced this line
        //gplib::rmat temp2(ublas::outer_prod(k, Input));

        //atlas::gemm(-1.0 / lambda, temp2, temp1, 1.0 / lambda, P);
        P = temp1 / lambda;
      }

  }
