#ifndef CWIENERFILTER_H_
#define CWIENERFILTER_H_

#include "AdaptiveFilter.h"
#include "VecMat.h"

namespace gplib
  {

    /** \addtogroup sigproc Signal processing methods */
    /* @{ */
    //! This class is currently broken !!!!!
    class WienerFilter: public AdaptiveFilter
      {
    private:
      gplib::rmat CorrMatrix;
      gplib::rvec Weights;
      double lambda;
    public:
      virtual void PrintWeights(std::ostream &output);
      virtual void
      AdaptFilter(const gplib::rvec &Input, const gplib::rvec &Desired);
      virtual void CalcOutput(const gplib::rvec &Input, gplib::rvec &Output);
      void SetLambda(const double mylambda)
        {
          lambda = mylambda;
        }
      WienerFilter(const int inputsize);
      virtual ~WienerFilter();
      };
  /* @} */
  }
#endif /*CWIENERFILTER_H_*/
