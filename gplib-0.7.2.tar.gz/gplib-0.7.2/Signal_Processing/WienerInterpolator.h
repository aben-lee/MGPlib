#ifndef WIENERINTERPOLATOR_H_
#define WIENERINTERPOLATOR_H_
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include "LSSOFilter.h"

namespace gplib
  {

    /** \addtogroup sigproc Signal processing methods */
    /* @{ */

    /*!*********************************************
     * WienerInterpolator implements a linear prediction filter
     * as described in Numerical Recipes, p. 566 , it uses the autocorrelation
     * structure of the input data to predict the next sample
     * Although it  does not work exactly like the adaptive filters it is part of
     * the class hierachy for now. The prediction coefficients are stored as Weights, but
     * in opposite order to NR memcof, so they can be immediately used for prediction
     */

    class WienerInterpolator: public LSSOFilter
      {
    private:
      //! The prediction error within the window used to calculate the filter coefficients
      double xms;
    public:
      //! Return the prediction error
      double GetXms() const
        {
          return xms;
        }
      //! Calculate the prediction coefficients, the contents of Desired are ignored, this function has to be implemented in the filter class hieraychy
      virtual void
      AdaptFilter(const gplib::rvec &Input, const gplib::rvec &Desired);
      //! A more convenient method to get the prediction coefficients, but unique to this class
      gplib::rvec CalcCoefficients(const gplib::rvec &Input)
        {
          AdaptFilter(Input, Input);
          return GetWeights();
        }
      //! The constructor needs to know the filterlength
      WienerInterpolator(const int filterlength);
      virtual ~WienerInterpolator();
      };
  /* @} */
  }
#endif /*WIENERINTERPOLATOR_H_*/
