#include <iostream>
#include <vector>
#include <fstream>
#include "RLSCanceller.h"
#include "LMSCanceller.h"

using namespace std;
using namespace gplib;

int main()
  {
    const int filterlength = 100; // set the length of the filter
    const double mu = 1e-14; // the stepsize for adaptation
    const double secfactor = 5; // the factor between the value calculated and the value used
    const int shift = filterlength / 4; // the shift in index between the first point in the segment and the value used as reference

    vector<double> input, desired;//declare vectors that hold the input data, the reference data
    // the filter output and the difference to the original time series
    string inputfilename, reffilename, outputfilename; // the names of the input and output files
    ifstream inputfile, reffile; // the file objects for reading
    ofstream outfile, weightfile, epsfile; // and writingy
    double currentnumber; // we have to read in a bunch of numbers and use this a temporary storage

    cout << "Inputfile: ";
    cin >> inputfilename; // read in inputfilename
    cout << "Reference Filename: ";
    cin >> reffilename; // and reference filename

    inputfile.open(inputfilename.c_str()); //open inputfile stream for reading
    reffile.open(reffilename.c_str()); // same for reference file stream
    outfile.open((reffilename + ".clean").c_str()); //open outputfile with an automatically generated name
    weightfile.open((reffilename + ".weight").c_str());
    epsfile.open((reffilename + ".eps").c_str());
    while (inputfile.good()) // while no errors occur
      {
        inputfile >> currentnumber; // read in a number from the input file
        input.push_back(currentnumber); // add it to the end of the input vector
      }

    while (reffile.good()) // while no errors occur
      {
        reffile >> currentnumber; // read in a number from the reference file
        desired.push_back(currentnumber);// add it to the end of the reference vector
      }
    inputfile.close(); //close both files
    reffile.close();
    vector<double> output(input.size()), epsilon(input.size());
    LMSCanceller Canceller(filterlength); // declare a new object of type LMSCanceller
    Canceller.SetMu(mu);

    gplib::rvec currentinput(filterlength), currdesired(1), currout(1);
    copy(input.begin(), input.begin() + filterlength, currentinput.begin());
    //for (int i = filterlength-1; i >= 0; --i)
    //	currentinput(i) = input[filterlength-1-i];
    //currdesired(0) = desired.at(filterlength/2);

    //Canceller.CalcOutput(currentinput,currout);
    //output.at(0) = currout(0);
    //epsilon.at(0) = Canceller.GetEpsilon()(0);
    for (int i = 0; i < input.size() - filterlength - 1; ++i)
      {
        Canceller.CalcOutput(currentinput, currout);
        Canceller.PrintWeights(weightfile);
        currdesired(0) = desired.at(i + shift);
        // Canceller.GetFilterOutput().front();

        Canceller.AdaptFilter(currentinput, currdesired);
        output.at(i + filterlength - 1) = currout(0);
        epsilon.at(i + filterlength - 1) = Canceller.GetEpsilon()(0);
        rotate(currentinput.begin(), currentinput.begin() + 1,
            currentinput.end());
        currentinput(filterlength - 1) = input.at(i + filterlength);
      }

    for (int i = shift; i < output.size(); ++i) //output the output data
      outfile << output.at(i) << endl; //to outputfile
    for (int i = shift; i < epsilon.size(); ++i) //output the difference data
      epsfile << epsilon.at(i) << endl; //to difference file
    //for (int i = 0; i < Canceller.Weights.size(); ++i)
    //	weightfile << Canceller.Weights.at(i) << endl;
    outfile.close(); // close file
    weightfile.close();
    epsfile.close();
  }
