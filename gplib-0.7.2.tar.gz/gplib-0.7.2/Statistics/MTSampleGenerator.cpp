#include "MTSampleGenerator.h"
#include <algorithm>
#include <ctime>

using namespace std;
namespace gplib
  {

    MTSampleGenerator::MTSampleGenerator(boost::function<
        double(const MTTensor*)> f, const MTTensor &Z, const double errorlevel) :
      generator(static_cast<unsigned int> (std::time(0))), Zxxr_dist(
          Z.GetZxx().real(), max(Z.GetdZxx(), Z.GetZxx().real() * errorlevel)),
          Zxxi_dist(Z.GetZxx().imag(), max(Z.GetdZxx(), Z.GetZxx().imag()
              * errorlevel)), Zxyr_dist(Z.GetZxy().real(), max(Z.GetdZxy(),
              Z.GetZxy().real() * errorlevel)), Zxyi_dist(Z.GetZxy().imag(),
              max(Z.GetdZxy(), Z.GetZxy().imag() * errorlevel)), Zyxr_dist(
              Z.GetZyx().real(), max(Z.GetdZyx(), Z.GetZyx().real()
                  * errorlevel)), Zyxi_dist(Z.GetZyx().imag(), max(Z.GetdZyx(),
              Z.GetZyx().imag() * errorlevel)), Zyyr_dist(Z.GetZyy().real(),
              max(Z.GetdZyy(), Z.GetZyy().real() * errorlevel)), Zyyi_dist(
              Z.GetZyy().imag(), max(Z.GetdZyy(), Z.GetZyy().imag()
                  * errorlevel)), Zxxr(generator, Zxxr_dist), Zxxi(generator,
              Zxxi_dist), Zxyr(generator, Zxyr_dist),
          Zxyi(generator, Zxyi_dist), Zyxr(generator, Zyxr_dist), Zyxi(
              generator, Zyxi_dist), Zyyr(generator, Zyyr_dist), Zyyi(
              generator, Zyyi_dist), func(f), Data(Z)
      {
      }

    MTSampleGenerator::~MTSampleGenerator()
      {
      }

    double MTSampleGenerator::operator()()
      {
        MTTensor Point(std::complex<double>(Zxxr(), Zxxi()), std::complex<
            double>(Zxyr(), Zxyi()), std::complex<double>(Zyxr(), Zyxi()),
            std::complex<double>(Zyyr(), Zyyi()), Data.GetFrequency());
        return func(&Point);
      }
  }
