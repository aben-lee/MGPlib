#ifndef TIMESERIESCOMPONENT_H_
#define TIMESERIESCOMPONENT_H_
#include <vector>
#include <string>
#include <algorithm>
#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <boost/operators.hpp>
#include "VecMat.h"

namespace gplib
  {

    /** \addtogroup tstools Time series analysis methods */
    /* @{ */

    //! TimeSeriesComponent is the base storage class for all types of time series data
    /*! This is the base class for both MT and Seismic data, all common functionality will
     * be in this class. Furthermore all functions should be implemented to use this class
     * unless they need functionality specific to the method.
     * We inherit from ring_operators to provide a set of useful mathematical operators with minimum implementation
     */
    class TimeSeriesComponent: public boost::arithmetic<boost::ring_operators<
        TimeSeriesComponent>, double>
      {
    private:
      //! The structure holding the data
      std::vector<double> data;
      //! Samplerate in Hz
      double samplerate;
      //! The name of the data (component or site or both)
      std::string name;
      //! The start of the recording
      boost::posix_time::ptime starttime;
    public:
      typedef std::vector<double>::iterator tdatait;
      //! Access for data vector, for ease of use and efficiency we return a reference
      std::vector<double> &GetData()
        {
          return data;
        }
      const std::vector<double> &GetData() const
        {
          return data;
        }
      //! For some methods we prefer to get the data as a ublas vector, we return a copy
      /*! This function is quite expensive, as the ublas object is generated on the fly and we return a copy.
       */
      gplib::rvec GetUblasData();
      //! Return samplerate in Hz
      double GetSamplerate() const
        {
          return samplerate;
        }
      //! Set sampling rate in Hz
      void SetSamplerate(const double rate)
        {
          samplerate = rate;
        }
      //! Set delta t in s
      void SetDt(const double dt)
        {
          samplerate = 1. / dt;
        }
      //! Return dt in s
      double GetDt() const
        {
          return 1. / samplerate;
        }
      //! Return name of the component
      std::string GetName() const
        {
          return name;
        }
      //! Modify name of the component
      void SetName(const std::string &n)
        {
          name = n;
        }
#ifdef HAVEGSL
      //! resample to a new dt by interpolation, this method only exists when HAVEGSL is defined durign compilation
      void Resample(const double newdt);
#endif
      //! Shift the start of the recording by npts points
      /*! if npts < 0 we cut abs(npts) from the beginning, otherwise we add npts 0s at the beginning
       * this will also adjust the starttime accordingly
       */
      void ShiftStart(const int npts);
      //! Shift the end of the recording by npts points
      /*! if npts < 0 we cut abs(npts) from the end, otherwise we add npts 0s at the end
       */
      void ShiftEnd(const int npts);
      // we declare the operators necessary for boost::ring_operators to generate the rest
      TimeSeriesComponent& operator=(const TimeSeriesComponent& source);
      //! Multiply each element of the time series by a constant factor
      TimeSeriesComponent& operator*=(const double factor);
      //! Devide each element of the time series by a constant number
      TimeSeriesComponent& operator/=(const double numerator);
      //! Add a constant shift to each element of the time series
      TimeSeriesComponent& operator+=(const double shift);
      //! Substract a constant shift from each element of the time series
      TimeSeriesComponent& operator-=(const double shift);
      //! Add two time series point by point and store the result in the current object
      TimeSeriesComponent& operator+=(const TimeSeriesComponent &other);
      //! Substract two time series point by point and store the result in the current object
      TimeSeriesComponent& operator-=(const TimeSeriesComponent &other);
      TimeSeriesComponent(const TimeSeriesComponent& source);
      TimeSeriesComponent();
      virtual ~TimeSeriesComponent();
      };

    //! We want to make this inline, so it appears in the header
    inline gplib::rvec TimeSeriesComponent::GetUblasData()
      {
        gplib::rvec ubvec(data.size());
        std::copy(data.begin(), data.end(), ubvec.begin());
        return ubvec;
      }
  /* @} */
  }
#endif /*TIMESERIESCOMPONENT_H_*/
