#include "TsSpectrum.h"

using namespace std;

namespace gplib
  {

    //The constructor copies the parameter value into MultiCalc and sets everything else to indicate pristine state
    TsSpectrum::TsSpectrum(bool WantMultiCalc)
      {
        MultiCalc = WantMultiCalc;
        ExistsPlanForward = false;
        ExistsPlanReverse = false;
        oldsize = 0;
        timedomain = NULL;
        freqdomain = NULL;
      }

    void TsSpectrum::DestroyMem()
      {
        if (ExistsPlanForward || ExistsPlanReverse) // if we did some calculations before
          {
            if (ExistsPlanForward)
              fftw_destroy_plan(p_forward); // we destroy the old plans
            if (ExistsPlanReverse)
              fftw_destroy_plan(p_reverse);
            fftw_free(timedomain); // and free the memory allocated
            fftw_free(freqdomain);
            ExistsPlanForward = false; // now there is no plan anymore, so we don't double deallocate
            ExistsPlanReverse = false;
          }
      }

    TsSpectrum::~TsSpectrum()
      {
        DestroyMem();
      }

    //The size for AssignMem is the size of the time series
    void TsSpectrum::AssignMem(const int size)
      {
        DestroyMem(); // destroy possible earlier instances
        timedomain = (double *) fftw_malloc(sizeof(double) * size); // reallocate with the required sizes
        freqdomain = (fftw_complex *) fftw_malloc(sizeof(fftw_complex) * (size
            / 2 + 1));
      }

    void TsSpectrum::Finish_Calculation(const int size)
      {
        oldsize = size; // The size of the (next) last calculation is the size of this calculation
      }

    void TsSpectrum::Prepare_Calculation(const int size)
      {
        if (size != oldsize) // if the size changed
          {
            AssignMem(size); //reassign memory

            if (MultiCalc) // generate a new plan
              {
                p_reverse = fftw_plan_dft_c2r_1d(size, freqdomain, timedomain,
                    FFTW_MEASURE);
                p_forward = fftw_plan_dft_r2c_1d(size, timedomain, freqdomain,
                    FFTW_MEASURE);
              }
            else
              {
                p_reverse = fftw_plan_dft_c2r_1d(size, freqdomain, timedomain,
                    FFTW_ESTIMATE);
                p_forward = fftw_plan_dft_r2c_1d(size, timedomain, freqdomain,
                    FFTW_ESTIMATE);
              }
            ExistsPlanReverse = true; // we will have to deallocate at some point
            ExistsPlanForward = true;
          }
      }
  }
