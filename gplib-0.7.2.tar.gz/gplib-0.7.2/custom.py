#commonlibs = ['boost_filesystem', 'boost_date_time', 'boost_program_options']
commonlibs = []
customincludes = ['/usr/local/include' ]
customlibdirs = ['/usr/local/lib']
customlinkflags ='  -fopenmp '
customcompileflags = '   '
antlrcommand = 'runantlr'

buildlevmar = False
buildgrace = True
buildnetcdf = True
buildlapack = True
buildgsl = True
buildantlr = True
